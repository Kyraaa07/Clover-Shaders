#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define GBUFFERS_BLOCK_TRANSLUCENT

#include "/program/gbuffers/gbuffers_translucent.glsl"