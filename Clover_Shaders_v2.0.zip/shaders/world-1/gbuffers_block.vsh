#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define GBUFFERS_BLOCK

#include "/program/gbuffers/gbuffers_solid.glsl"