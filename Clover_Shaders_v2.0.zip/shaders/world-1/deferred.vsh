#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define DEFERRED

#include "/program/deferred/deferred.glsl"