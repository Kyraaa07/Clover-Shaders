#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define GBUFFERS_TEXTURED

#include "/program/gbuffers/gbuffers_translucent.glsl"
