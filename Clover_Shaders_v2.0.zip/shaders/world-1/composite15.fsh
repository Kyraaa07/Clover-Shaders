#version 330 compatibility

#define FRAGMENT_SHADER
#define TILE_INDEX 0

#include "/program/composite/bloomUpsample.glsl"