#version 330 compatibility

#define NO_CUTOUT

#define FRAGMENT_SHADER
#define NETHER
#define GBUFFERS_TERRAIN

#include "/program/gbuffers/gbuffers_solid.glsl"