#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define GBUFFERS_BEACONBEAM

#include "/program/gbuffers/gbuffers_beaconbeam.glsl"