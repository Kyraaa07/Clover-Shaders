#define NETHER
#include "/program/voxy/voxy_translucent.glsl"
