#version 330 compatibility

#define VERTEX_SHADER
#define TILE_INDEX 3

#include "/program/composite/bloomDownsample.glsl"