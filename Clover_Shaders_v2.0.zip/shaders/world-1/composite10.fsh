#version 330 compatibility

#define FRAGMENT_SHADER
#define TILE_INDEX 2

#include "/program/composite/bloomDownsample.glsl"