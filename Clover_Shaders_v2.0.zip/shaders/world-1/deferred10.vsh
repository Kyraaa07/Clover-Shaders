#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define DEFERRED10

#include "/program/deferred/deferred10.glsl"