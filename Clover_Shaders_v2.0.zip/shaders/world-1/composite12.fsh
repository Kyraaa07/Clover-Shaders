#version 330 compatibility

#define FRAGMENT_SHADER
#define TILE_INDEX 3

#include "/program/composite/bloomUpsample.glsl"