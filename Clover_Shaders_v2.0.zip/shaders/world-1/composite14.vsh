#version 330 compatibility

#define VERTEX_SHADER
#define TILE_INDEX 1

#include "/program/composite/bloomUpsample.glsl"