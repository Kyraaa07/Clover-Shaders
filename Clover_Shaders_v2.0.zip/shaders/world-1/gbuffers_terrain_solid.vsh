#version 330 compatibility

#define NO_CUTOUT

#define VERTEX_SHADER
#define NETHER
#define GBUFFERS_TERRAIN

#include "/program/gbuffers/gbuffers_solid.glsl"
