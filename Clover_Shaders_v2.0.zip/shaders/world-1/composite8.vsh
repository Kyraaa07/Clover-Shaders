#version 330 compatibility

#define VERTEX_SHADER
#define TILE_INDEX 0

#include "/program/composite/bloomDownsample.glsl"