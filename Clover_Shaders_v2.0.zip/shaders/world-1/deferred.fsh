#version 330 compatibility

#define FRAGMENT_SHADER
#define NETHER
#define DEFERRED

#include "/program/deferred/deferred.glsl"