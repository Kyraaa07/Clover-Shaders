#version 330 compatibility

#define VERTEX_SHADER
#define NETHER
#define GBUFFERS_PARTICLES

#include "/program/gbuffers/gbuffers_solid.glsl"