#define NETHER
#include "/program/voxy/voxy_opaque.glsl"
