#version 330 compatibility

#define FRAGMENT_SHADER
#define NETHER
#define GBUFFERS_ENTITIES_TRANSLUCENT

#include "/program/gbuffers/gbuffers_translucent.glsl"