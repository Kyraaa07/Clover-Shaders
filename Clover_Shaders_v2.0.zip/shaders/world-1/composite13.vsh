#version 330 compatibility

#define VERTEX_SHADER
#define TILE_INDEX 2

#include "/program/composite/bloomUpsample.glsl"