#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define COMPOSITE5

#include "/program/composite/composite5.glsl"