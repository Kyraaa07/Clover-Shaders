#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define SHADOW

#include "/program/shadow/shadow.glsl"