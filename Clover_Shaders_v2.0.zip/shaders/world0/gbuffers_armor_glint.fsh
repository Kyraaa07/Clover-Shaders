#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define GBUFFERS_ARMOR_GLINT

#include "/program/gbuffers/gbuffers_armor_glint.glsl"