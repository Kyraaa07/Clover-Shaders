#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define GBUFFERS_BEACONBEAM

#include "/program/gbuffers/gbuffers_beaconbeam.glsl"