#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers/gbuffers_skytextured.glsl"