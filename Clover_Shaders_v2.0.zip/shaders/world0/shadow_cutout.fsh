#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define SHADOW_CUTOUT

#include "/program/shadow/shadow_cutout.glsl"