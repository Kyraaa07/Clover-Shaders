#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_WEATHER

#include "/program/gbuffers/gbuffers_weather.glsl"
