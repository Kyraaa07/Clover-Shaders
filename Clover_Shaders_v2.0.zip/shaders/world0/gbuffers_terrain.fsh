#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define GBUFFERS_TERRAIN

#include "/program/gbuffers/gbuffers_solid.glsl"
