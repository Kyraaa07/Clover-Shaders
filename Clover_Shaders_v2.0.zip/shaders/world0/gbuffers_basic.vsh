#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_BASIC

#include "/program/gbuffers/gbuffers_basic.glsl"