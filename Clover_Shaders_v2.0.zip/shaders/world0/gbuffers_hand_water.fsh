#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define GBUFFERS_HAND_WATER

#include "/program/gbuffers/gbuffers_translucent.glsl"