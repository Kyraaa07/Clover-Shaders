#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_WATER

#include "/program/gbuffers/gbuffers_translucent.glsl"
