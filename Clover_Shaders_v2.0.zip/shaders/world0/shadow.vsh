#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define SHADOW

#include "/program/shadow/shadow.glsl"