#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define DEFERRED

#include "/program/deferred/deferred.glsl"