#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define COMPOSITE1

#include "/program/composite/composite1.glsl"