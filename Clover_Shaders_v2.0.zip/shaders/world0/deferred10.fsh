#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define DEFERRED10

#include "/program/deferred/deferred10.glsl"