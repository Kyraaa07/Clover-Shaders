#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_ENTITIES_TRANSLUCENT

#include "/program/gbuffers/gbuffers_translucent.glsl"