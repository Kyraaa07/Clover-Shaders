#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_TEXTURED

#include "/program/gbuffers/gbuffers_translucent.glsl"
