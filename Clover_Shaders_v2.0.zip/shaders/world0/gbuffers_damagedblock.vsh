#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_DAMAGEDBLOCK

#include "/program/gbuffers/gbuffers_damagedblock.glsl"