#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define COMPOSITE2

#include "/program/composite/composite2.glsl"