#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define DEFERRED

#include "/program/deferred/deferred.glsl"