#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define DEFERRED10

#include "/program/deferred/deferred10.glsl"