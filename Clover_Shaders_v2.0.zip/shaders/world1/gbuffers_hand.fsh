#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define GBUFFERS_HAND

#include "/program/gbuffers/gbuffers_solid.glsl"