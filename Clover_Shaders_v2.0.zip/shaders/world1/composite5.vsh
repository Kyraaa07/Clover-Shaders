#version 330 compatibility

#define VERTEX_SHADER
#define END
#define COMPOSITE5

#include "/program/composite/composite5.glsl"