#version 330 compatibility

#define VERTEX_SHADER
#define END
#define GBUFFERS_LIGHTNING

#include "/program/gbuffers/gbuffers_lightning.glsl"