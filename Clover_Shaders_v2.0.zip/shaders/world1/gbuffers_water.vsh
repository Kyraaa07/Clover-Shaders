#version 330 compatibility

#define VERTEX_SHADER
#define END
#define GBUFFERS_WATER

#include "/program/gbuffers/gbuffers_translucent.glsl"
