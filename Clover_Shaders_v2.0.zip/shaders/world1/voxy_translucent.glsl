#define END
#include "/program/voxy/voxy_translucent.glsl"
