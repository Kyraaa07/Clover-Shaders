#version 330 compatibility

#define VERTEX_SHADER
#define END
#define SHADOW

#include "/program/shadow/shadow.glsl"