#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define GBUFFERS_BLOCK

#include "/program/gbuffers/gbuffers_solid.glsl"