#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define DEFERRED10

#include "/program/deferred/deferred10.glsl"