#version 330 compatibility

#define VERTEX_SHADER
#define END
#define DEFERRED

#include "/program/deferred/deferred.glsl"