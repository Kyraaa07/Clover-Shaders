#version 330 compatibility

#define NO_CUTOUT

#define VERTEX_SHADER
#define END
#define GBUFFERS_TERRAIN

#include "/program/gbuffers/gbuffers_solid.glsl"