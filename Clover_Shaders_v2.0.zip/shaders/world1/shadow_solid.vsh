#version 330 compatibility

#define VERTEX_SHADER
#define END
#define SHADOW_SOLID

#include "/program/shadow/shadow_solid.glsl"