#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define GBUFFERS_CLOUDS

#include "/program/gbuffers/gbuffers_clouds.glsl"