#version 330 compatibility

#define VERTEX_SHADER
#define END
#define DEFERRED10

#include "/program/deferred/deferred10.glsl"