#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define SHADOW_SOLID

#include "/program/shadow/shadow_solid.glsl"