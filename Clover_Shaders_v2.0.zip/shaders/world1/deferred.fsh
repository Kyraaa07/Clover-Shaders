#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define DEFERRED

#include "/program/deferred/deferred.glsl"