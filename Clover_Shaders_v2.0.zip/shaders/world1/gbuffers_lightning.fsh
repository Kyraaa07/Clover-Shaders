#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define GBUFFERS_LIGHTNING

#include "/program/gbuffers/gbuffers_lightning.glsl"
