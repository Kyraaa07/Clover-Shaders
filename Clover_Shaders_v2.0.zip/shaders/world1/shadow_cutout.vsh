#version 330 compatibility

#define VERTEX_SHADER
#define END
#define SHADOW_CUTOUT

#include "/program/shadow/shadow_cutout.glsl"