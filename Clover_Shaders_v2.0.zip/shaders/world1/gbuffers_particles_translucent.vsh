#version 330 compatibility

#define VERTEX_SHADER
#define END
#define GBUFFERS_PARTICLES_TRANSLUCENT

#include "/program/gbuffers/gbuffers_translucent.glsl"