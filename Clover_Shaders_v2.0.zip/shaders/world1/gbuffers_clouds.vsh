#version 330 compatibility

#define VERTEX_SHADER
#define END
#define GBUFFERS_CLOUDS

#include "/program/gbuffers/gbuffers_clouds.glsl"