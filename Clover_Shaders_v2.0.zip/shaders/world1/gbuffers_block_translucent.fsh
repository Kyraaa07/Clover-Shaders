#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define GBUFFERS_BLOCK_TRANSLUCENT

#include "/program/gbuffers/gbuffers_translucent.glsl"