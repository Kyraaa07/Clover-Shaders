#version 330 compatibility

#define VERTEX_SHADER
#define END
#define GBUFFERS_SPIDEREYES

#include "/program/gbuffers/gbuffers_spidereyes.glsl"