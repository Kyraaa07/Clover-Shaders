#version 330 compatibility

#define FRAGMENT_SHADER
#define END
#define SHADOW

#include "/program/shadow/shadow.glsl"