	
#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"

in vec2 texcoord;

/* DRAWBUFFERS:6 */
layout (location = 0) out float depth; // 1/4 res depth

const vec2[] offsets = vec2[](vec2(1.0, 1.0), vec2(3.0, 1.0), vec2(1.0, 3.0), vec2(3.0, 3.0));

void main() {
    vec2 base = floor(gl_FragCoord.xy) * 4.0;
    
    depth = 0.0;
    for (int i = 0; i < 4; i++) {
        vec2 uv = (base + offsets[i]) / view;
        depth += textureLod(depthtex0, uv, 0).r;
    }
    depth *= 0.25;
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
