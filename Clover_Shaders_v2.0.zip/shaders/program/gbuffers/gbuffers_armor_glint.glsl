#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform sampler2D gtexture;

in vec2 texcoord;

/* DRAWBUFFERS:8 */
layout (location = 0) out vec4 overlay; // Overlay color

void main() {
	overlay.rgb = SRGBToLinear(texture(gtexture, texcoord).rgb);
	overlay.a = gl_FragCoord.z * 0.5;
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/post/taa.glsl"
#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;

void main() {
	applyVertexTransform();
	
	if (gl_ProjectionMatrix[2][2] > -0.5) // Hand
		gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);
	else // Dropped Items
		gl_Position.z -= 0.001;

	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif