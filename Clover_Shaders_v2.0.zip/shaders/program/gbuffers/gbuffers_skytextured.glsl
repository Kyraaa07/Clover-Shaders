#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/colors/skyColors.glsl"
#include "/lib/settings/atmosphereSettings.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec4 color; // Main scene color

void main() {
	#if SUN_STYLE == 0 && MOON_STYLE == 0
		discard;
	#endif

	vec3 albedo = SRGBToLinear(texture(gtexture, texcoord).rgb);
	float luma = getLuminance(albedo);

	if (luma < 0.022) discard;

	vec3 screenPos = vec3(gl_FragCoord.xy / view, 1.0);
	vec3 viewPos = screenToView(screenPos);

	if (dot(viewPos, sunVec) > 0.0) { // Sun
		#if SUN_STYLE == 0
			discard;
		#endif
		albedo *= sunColor * vec3(1.0, 1.0, 2.5) * 30.0;
	} else { // Moon
		#if MOON_STYLE == 0
			discard;
		#endif
		albedo *= moonCol * luma * vec3(1.25, 1.25, 1.0) * 20.0;
	}

	float VdotU = dot(viewPos, upVec) * inversesqrt(lengthSquared(viewPos));

	color = vec4(albedo, clamp01(pow3(3.0 * VdotU + 0.57)));
}
#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/post/taa.glsl"
#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;

void main() {
	applyVertexTransform();

	gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);

	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif