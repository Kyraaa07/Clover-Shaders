#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"
#include "/lib/colors/lightingColors.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec4 color; // Main scene color

void main() {
	color = texture(gtexture, texcoord);

    if (color.a < alphaTestRef) discard;

    // Rain Detection
    if (color.r + color.g < 1.17) {
        color = vec4(0.16, 0.21, 0.23, 0.15);
    } else { 
        color.rgb = SRGBToLinear(color.rgb);
    }

    color.rgb *= lightColor + ambientColor;
    color.a *= rainFactor;
}
#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;

void main() {
    applyVertexTransform();

	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif