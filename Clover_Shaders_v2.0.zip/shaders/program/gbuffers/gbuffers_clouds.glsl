#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

void main() {
	discard;
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

void main() {
	
}

#endif

