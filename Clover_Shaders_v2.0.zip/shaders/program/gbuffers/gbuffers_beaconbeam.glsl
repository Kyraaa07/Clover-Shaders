#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform sampler2D gtexture;

flat in vec3 geoNormal;

in vec2 texcoord;
in vec4 glColor;

#define DEFAULT_MATERIAL
#define LMCOORD_OVERRIDE
#include "/lib/materials/materialsCommon.glsl"

#include "/lib/util/programIDs.glsl"

/* DRAWBUFFERS:34 */
layout (location = 0) out uvec4 buffer0; // Material attributes
layout (location = 1) out float buffer1; // Program ID

void main() {
    if (glColor.a < 0.5) discard;

	vec3 color = texture(gtexture, texcoord).rgb;
    color *= color * glColor.rgb / maxOf(glColor.rgb);

	mat3 tbnMatrix = mat3(vec3(0.0), vec3(0.0), geoNormal);

	Material material = getMaterial(tbnMatrix, color.rgb);
	material.emission = 0.3;

	packMaterialData(material, buffer0);
    storeProgramID(buffer1);
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/post/taa.glsl"
#include "/lib/util/vertexTransform.glsl"

flat out vec3 geoNormal;

out vec2 texcoord;
out vec4 glColor;

void main() {
	applyVertexTransform();
	
	gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);

	geoNormal = normalize(gl_NormalMatrix * gl_Normal);
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	glColor = gl_Color;
}

#endif