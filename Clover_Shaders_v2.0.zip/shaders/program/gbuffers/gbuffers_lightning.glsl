#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"

in vec3 glColor;

#if MC_VERSION < 260100
	#define DEFAULT_MATERIAL
	#define LMCOORD_OVERRIDE
	#define NORMALS_OVERRIDE
	#include "/lib/materials/materialsCommon.glsl"

	#include "/lib/util/programIDs.glsl"

	/* DRAWBUFFERS:34 */
	layout (location = 0) out uvec4 buffer0; // Material attributes
	layout (location = 1) out float buffer1; // Program ID
#else
	/* DRAWBUFFERS:0 */
	layout (location = 0) out vec3 buffer0; // Main scene color
#endif

void main() {
	vec3 albedo = glColor;

	#if MC_VERSION < 12105 
		#define LIGHTNING_CHECK entityId == 7
	#else
		#define LIGHTNING_CHECK albedo.r < 0.5
	#endif

	float emission = 0.15;
	if (LIGHTNING_CHECK) { // Lightning Bolt
		albedo = linearToSRGB(vec3(0.5, 0.7, 1.0));
		emission = 0.4;
	}

	#if MC_VERSION < 260100
		Material material = getMaterial(mat3(0.0), albedo);
		material.emission = emission;

		packMaterialData(material, buffer0);
		storeProgramID(buffer1);
	#else
		buffer0 = SRGBToLinear(albedo) * emission * 24.0;
	#endif 
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/util/vertexTransform.glsl"

out vec3 glColor;

void main() {	
	applyVertexTransform();

	glColor = gl_Color.rgb;
}

#endif