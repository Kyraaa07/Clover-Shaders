#define GBUFFERS_SOLID
//----------------- Gbuffers Solid -----------------//

#include "/lib/common.glsl"
#include "/lib/settings/natureSettings.glsl"
#include "/lib/settings/materialSettings.glsl"

#ifndef GBUFFERS_ENTITIES
	#include "/lib/post/taa.glsl"
#endif

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D gtexture;

flat in vec3 vertexNormal;
flat in vec4 vertexTangent;

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
	flat in vec3 crystalOriginRel;
#endif 

#ifdef GBUFFERS_ENTITIES
	int matID = currentRenderedItemId > 0 ? currentRenderedItemId : entityId;
#elif defined GBUFFERS_HAND
	int matID = currentRenderedItemId;
#elif defined GBUFFERS_BLOCK
	int matID = blockEntityId;
#else
	flat in int matID;
#endif

in vec2 texcoord;
in vec4 glColor;

#ifdef OVERWORLD
	in vec2 lmcoord;
#else
	in float lmcoordX;
	vec2 lmcoord = vec2(lmcoordX, 1.0);
#endif

// ---- POM varyings (only used when POM is enabled on terrain/block) ----
#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
	in vec3  viewVector;    // view direction in tangent space
	in vec2  vTexCoord;     // tile-local UV (0..1)
	in vec4  vTexCoordAM;   // .st = atlas tile origin, .pq = atlas tile size
	in vec2  signMidCoordPos;

	// dFdx/dFdy of atlas UV for textureGrad (keeps mip level stable under POM shift)
	vec2 dcdx = dFdx(texcoord);
	vec2 dcdy = dFdy(texcoord);

	#include "/lib/materials/materialMethods/pomEffects.glsl"
#endif

#include "/lib/materials/materialsCommon.glsl"
#include "/lib/util/gbuffersScreenPos.glsl"
#include "/lib/util/programIDs.glsl"

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
	#include "/lib/util/endCrystalCapture.glsl"
#endif

/* DRAWBUFFERS:34 */
layout (location = 0) out uvec4 buffer0; // Material attributes
layout (location = 1) out float buffer1; // Program ID

void main() {
	// ----------------------------------------------------------------
	// POM coord offset — must happen before the base texture sample
	// so colour, normals and specular all read from the same shifted UV
	// ----------------------------------------------------------------
	vec2 pomCoord = texcoord; // atlas-space coord, possibly shifted by POM

	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
		float pomDist = length(viewVector); // rough proxy for distance in view space
		// POM_DISTANCE is in blocks; viewVector is in view space (metres ≈ blocks)
		float parallaxFade = clamp((pomDist - float(POM_DISTANCE) * 0.75) /
		                           (float(POM_DISTANCE) * 0.25), 0.0, 1.0);

		if (parallaxFade < 1.0) {
			float dither     = dither_ign; // from /lib/util/dither.glsl via taa.glsl
			vec2  newCoord   = texcoord;
			float texDepth   = 1.0;
			vec3  traceCDepth = vec3(vTexCoord, 1.0);

			vec2 localCoord = GetParallaxCoord(parallaxFade, dither, newCoord, texDepth, traceCDepth);

			// Only shift if we actually traced somewhere meaningful
			if (newCoord != texcoord) {
				pomCoord = newCoord;
			}
		}
	#endif

	vec4 color  = texture(gtexture, pomCoord);
	vec3 colorP = color.rgb;

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		// Healing beam (matID 6): its shape comes from procedural shading, not from the pixel texture
		if (matID == 6) { color = vec4(1.0); colorP = vec3(1.0); }
	#endif
	color.rgb  *= glColor.rgb;

	#ifdef GBUFFERS_ENTITIES
		color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
	#endif
	
	#ifndef NO_CUTOUT
		if (color.a < alphaTestRef) discard;
	#endif

	vec3 screenPos = getGbuffersScreenPos();
	vec3 viewPos   = screenToView(screenPos);
	vec3 playerPos = viewToPlayer(viewPos);

	mat3 tbnMatrix = getTbnMatrix(vertexNormal, vertexTangent);

	// getMaterial reads normals/specular — pass pomCoord so it stays in sync
	// We temporarily remap texcoord via a local override pattern:
	// labpbrMaterials.glsl / defaultMaterial.glsl both read "texcoord" directly,
	// but since we can't easily reroute that include, we do the normal read here
	// for LabPBR mode and patch it into the material.
	Material material = getMaterial(tbnMatrix, color.rgb);

	// ----------------------------------------------------------------
	// POM normal override — replace the flat normal with the parallax one
	// ----------------------------------------------------------------
	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
		if (pomCoord != texcoord) {
			// Re-read normal at the shifted coord
			vec4 pomNormalSample = texture(normals, pomCoord);
			vec3 pomNormal = vec3(pomNormalSample.rg * 2.0 - 1.0, 0.0);
			pomNormal.z    = sqrt(max(1.0 - dot(pomNormal.xy, pomNormal.xy), 0.0));

			#ifdef POM_SLOPE_NORMALS
				float pomDist2 = length(viewVector);
				float pFade2   = clamp((pomDist2 - float(POM_DISTANCE) * 0.75) /
				                       (float(POM_DISTANCE) * 0.25), 0.0, 1.0);
				if (pFade2 < 1.0) {
					// Recompute localCoord for slope normals (cheap second trace omitted;
					// approximate from the vTexCoord offset)
					vec2 localCoordApprox = (pomCoord - vTexCoordAM.st) / vTexCoordAM.pq;
					vec3 slopeN = GetParallaxSlopeNormal(localCoordApprox, 1.0 - pomNormalSample.a, viewVector);
					if (length(slopeN) > 0.5) pomNormal = slopeN;
				}
			#endif

			material.normalM = tbnMatrix * pomNormal;
		}

		// ---- Parallax self-shadow ----
		#ifdef POM_SHADOW
		{
			float pomDist3 = length(viewVector);
			float pFade3   = clamp((pomDist3 - float(POM_DISTANCE) * 0.75) /
			                       (float(POM_DISTANCE) * 0.25), 0.0, 1.0);
			if (pFade3 < 1.0 && pomCoord != texcoord) {
				vec2  localCoordS = (pomCoord - vTexCoordAM.st) / vTexCoordAM.pq;
				float heightS     = texture(normals, pomCoord).a;
				vec3  sunVecTS    = tbnMatrix * sunVec; // sunVec from common.glsl

				float pShadow = GetParallaxShadow(pFade3, dither_ign, heightS,
				                                   localCoordS, sunVecTS, tbnMatrix);
				// Darken emission/albedo slightly in self-shadowed areas
				material.albedo *= mix(1.0, pShadow, 0.6);
			}
		}
		#endif
	#endif

	applyHardcodedMaterials(material, color.a, colorP, tbnMatrix, screenPos, viewPos, playerPos, matID);

	packMaterialData(material, buffer0);
	storeProgramID(buffer1);

	#if defined GBUFFERS_BLOCK && PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1
		if (matID == 3) buffer1 = float(GBUFFERS_END_PORTAL_ID) / 255.0;
	#endif

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		if (matID == 4002) buffer1 = float(GBUFFERS_END_CRYSTAL_ID) / 255.0;
	#endif

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		if (matID == 4002) CaptureEndCrystal(playerPos + cameraPosition);
	#endif
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/util/vertexTransform.glsl"

flat out vec3 vertexNormal;
flat out vec4 vertexTangent;

#if !defined GBUFFERS_ENTITIES && !defined GBUFFERS_BLOCK && !defined GBUFFERS_HAND
	flat out int matID;
#endif

out vec2 texcoord;
out vec4 glColor;

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
	flat out vec3 crystalOriginRel;
#endif

#ifdef OVERWORLD
	out vec2 lmcoord;
#else
	out float lmcoordX;
#endif

// ---- POM varyings out ----
#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
	out vec3 viewVector;
	out vec2 vTexCoord;
	out vec4 vTexCoordAM;
	out vec2 signMidCoordPos;
#endif

attribute vec4  at_tangent;
attribute float mc_Entity;
attribute vec2 mc_midTexCoord; // centre of the tile in atlas UV (waving + POM)

#if WAVING_TEXTURES == 1 && defined GBUFFERS_TERRAIN && !defined VT_COMPATIBILITY_MODE
    attribute vec3 at_midBlock;

    // Port of Complementary Unbound lib/materials/materialMethods/wavingBlocks.glsl
    float lmCoord = 1.0;
    #define WAVING_I (WAVING_STRENGTH * 0.1)
    #define WAVING_SPEED_M (WAVING_SPEED * 0.1)

    vec3 GetRawWave(in vec3 pos, float wind) {
        float magnitude = sin(wind * 0.0027 + pos.x + pos.y) * 0.04 + 0.04;
        float d0 = sin(wind * 0.0127);
        float d1 = sin(wind * 0.0089);
        float d2 = sin(wind * 0.0114);
        vec3 wave;
        wave.x = magnitude * sin(wind*0.0224 + d1 + d2 + pos.x - pos.z + pos.y);
        wave.y = magnitude * sin(wind*0.0015 + d2 + d0 + pos.x);
        wave.z = magnitude * sin(wind*0.0063 + d0 + d1 - pos.x + pos.z + pos.y);

        return wave;
    }

    vec3 GetWave(in vec3 pos, float waveSpeed) {
        float wind = frameTimeCounter * waveSpeed * WAVING_SPEED_M;
        vec3 wave = GetRawWave(pos, wind);

        return wave * WAVING_I;
    }

    void DoWave_Foliage(inout vec3 playerPos, vec3 worldPos, float waveMult) {
        worldPos.y *= 0.5;

        vec3 wave = GetWave(worldPos, 170.0);
        wave.x = wave.x * 3.0;
        wave.y = 0.0;
        wave.z = wave.z * 8.0 + wave.y * 4.0;

        wave *= clamp(lmCoord - 0.87, 0.0, 0.1);

        playerPos.xyz += wave * waveMult;
    }

    void DoWave_Leaves(inout vec3 playerPos, vec3 worldPos, float waveMult) {
        worldPos *= vec3(0.75, 0.375, 0.75);

        vec3 wave = GetWave(worldPos, 170.0);
        wave *= vec3(4.0, 3.0, 8.0);

        wave *= clamp(lmCoord - 0.87, 0.0, 0.1);

        playerPos.xyz += wave * waveMult;
    }

    void DoWave(inout vec3 playerPos, int mat) {
        vec3 worldPos = playerPos.xyz + cameraPosition.xyz;

        if (mat == 2) { // Foliage (block.2)
            if (gl_MultiTexCoord0.t < mc_midTexCoord.t || fract(worldPos.y + 0.21) > 0.26)
                DoWave_Foliage(playerPos.xyz, worldPos, 1.0);
        } else if (mat == 1) { // Leaves (block.1)
            DoWave_Leaves(playerPos.xyz, worldPos, 1.0);
        }
    }

    void applyWavingVertex() {
        vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

        lmCoord = clamp((gl_TextureMatrix[1] * gl_MultiTexCoord1).y - 0.03125, 0.0, 1.0) * 1.06667;
        int mat = int(mc_Entity + 0.5);

        DoWave(position.xyz, mat);

        gl_Position = gl_ProjectionMatrix * gbufferModelView * position;
    }
#endif


void main() {
	#if defined GBUFFERS_ENTITIES && MC_VERSION < 260100 
		// Name tag background, Entity shadows
		if (
			// Entity Ids for name tags and entity shadows seem to be broken on Iris 1.21.9+
			#if MC_VERSION >= 12109
				gl_Color.a < 0.38
			#else
				(entityId == 4000 && gl_Color.a < 0.5) || entityId == 4001
			#endif
		) {
			gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
			return;
		}
	#endif

#if WAVING_TEXTURES == 1 && defined GBUFFERS_TERRAIN && !defined VT_COMPATIBILITY_MODE
		applyWavingVertex();
	#else
		applyVertexTransform();

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		crystalOriginRel = (gbufferModelViewInverse * vec4(gl_ModelViewMatrix[3].xyz, 1.0)).xyz;
	#endif
	#endif
	
	#ifndef GBUFFERS_ENTITIES
		gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);
	#endif

	#ifdef GBUFFERS_ENTITIES
		gl_Position.z -= 0.001; // Fixes Z fighting with certain entities
	#endif

	vertexNormal  = normalize(gl_NormalMatrix * gl_Normal);
	vertexTangent = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);

	// Pre 1.20.6 End Portal normal & tangent precision issues workaround
	#if defined GBUFFERS_BLOCK && MC_VERSION < 12006
		if (blockEntityId == 3) {
			float NdotU = dot(vertexNormal, upVec);
			float NdotE = dot(vertexNormal, eastVec);
			float NdotS = dot(vertexNormal, southVec);

			if (abs(NdotU) > 0.9) {
				vertexNormal = sign(NdotU) * upVec;
				vertexTangent = vec4(-southVec, 1.0);
			} else if (abs(NdotE) > 0.9) {
				vertexNormal = sign(NdotE) * eastVec;
				vertexTangent = vec4(-upVec, 1.0);
			} else if (abs(NdotS) > 0.9) {
				vertexNormal = sign(NdotS) * southVec;
				vertexTangent = vec4(-upVec, 1.0);
			}
		}
	#endif

	// Post 26.1 End Portal non existent tangent workaround
	#if defined GBUFFERS_BLOCK && MC_VERSION >= 260100
        if (at_tangent.xyz == vec3(0.0)) {
			if (abs(dot(vertexNormal, upVec)) > 0.99)
				vertexTangent = vec4(-southVec, 1.0);
			else
				vertexTangent = vec4(-upVec, 1.0);
        }
    #endif

	#if !defined GBUFFERS_ENTITIES && !defined GBUFFERS_BLOCK && !defined GBUFFERS_HAND
		matID = int(mc_Entity);
	#endif
	
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	#ifdef OVERWORLD
		lmcoord = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
	#else
		lmcoordX = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).x - 0.03125) * 1.06667);
	#endif

	glColor = gl_Color;

	// ---- POM vertex data ----
	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
	{
		// Build TBN in view space to transform view direction into tangent space
		vec3 vNorm = vertexNormal;
		vec3 vTang = vertexTangent.xyz;
		vec3 vBino = cross(vNorm, vTang) * sign(vertexTangent.w);
		// tbnMatrix: transforms view-space vectors into tangent space
		// (transpose of the TBN columns = inverse for orthonormal bases)
		mat3 tbnT = mat3(vTang.x, vBino.x, vNorm.x,
		                 vTang.y, vBino.y, vNorm.y,
		                 vTang.z, vBino.z, vNorm.z);

		vec3 viewPos = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;
		viewVector   = tbnT * viewPos; // tangent-space view direction (not normalised on purpose)

		// Atlas tile extents: mc_midTexCoord is the texel centre of the tile
		vec2 rawTexcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		vec2 midCoord    = (gl_TextureMatrix[0] * vec4(mc_midTexCoord, 0.0, 1.0)).xy;
		vec2 texMinMid   = rawTexcoord - midCoord;

		signMidCoordPos = sign(texMinMid);
		vTexCoordAM.st  = min(rawTexcoord, midCoord - texMinMid); // tile min corner
		vTexCoordAM.pq  = abs(texMinMid) * 2.0;                   // tile size in atlas UV
		vTexCoord       = signMidCoordPos * 0.5 + 0.5;            // local 0..1 UV
	}
	#endif
}

#endif
