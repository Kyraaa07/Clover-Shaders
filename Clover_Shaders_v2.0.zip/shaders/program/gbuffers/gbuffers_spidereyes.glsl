#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec3 glColor;

#if MC_VERSION < 260100
	flat in vec3 geoNormal;

	#define DEFAULT_MATERIAL
	#define LMCOORD_OVERRIDE
	#include "/lib/materials/materialsCommon.glsl"

	/* DRAWBUFFERS:3 */
	layout (location = 0) out uvec4 buffer0; // Material attributes
#else
	/* DRAWBUFFERS:0 */
	layout (location = 0) out vec3 buffer0; // Main scene color
#endif

void main() {
	vec4 color = texture(gtexture, texcoord) * vec4(glColor, 1.0);
	if (color.a < alphaTestRef) discard;

	const float eyeEmission = 0.2;

	#if MC_VERSION < 260100
		mat3 tbnMatrix = mat3(vec3(0.0), vec3(0.0), geoNormal);

		Material material = getMaterial(tbnMatrix, color.rgb);
		material.emission = eyeEmission;

		packMaterialData(material, buffer0);
	#else
		vec3 albedo = SRGBToLinear(color.rgb);

		buffer0 = albedo * eyeEmission * 24.0;
	#endif 
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;
out vec3 glColor;

#if MC_VERSION < 260100
	flat out vec3 geoNormal;
#endif

void main() {	
	applyVertexTransform();
	gl_Position.z -= 0.0011; // Fixes Z fighting

	#if MC_VERSION < 260100
		geoNormal = normalize(gl_NormalMatrix * gl_Normal);
	#endif

	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	glColor = gl_Color.rgb;
}

#endif