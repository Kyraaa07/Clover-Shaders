#include "/lib/common.glsl"

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

flat in vec4 glColor;

#ifdef OVERWORLD
	flat in vec2 lmcoord;
#else
	flat in float lmcoordX;
	vec2 lmcoord = vec2(lmcoordX, 1.0);
#endif

#include "/lib/util/programIDs.glsl"
#include "/lib/colors/lightingColors.glsl"
#include "/lib/settings/materialSettings.glsl"

/* DRAWBUFFERS:04 */
layout (location = 0) out vec4  buffer0; // Main color
layout (location = 1) out float buffer1; // Program ID

void main() {
	if (glColor.a < 0.1) discard;

	float emission = 0.0;
	buffer0 = vec4(SRGBToLinear(glColor.rgb), glColor.a);

	if (renderStage == MC_RENDER_STAGE_OUTLINE) {
		emission = 0.5; buffer0.a = 1.0;

		#if SELECTION_OUTLINE == 1 // Rainbow
			vec3 screenPos = vec3(gl_FragCoord.xy / view, gl_FragCoord.z);

    		vec3 viewPos  = screenToView(screenPos);
    		vec3 worldPos = viewToPlayer(viewPos) + cameraPosition; 

			// Complementary Unbound rainbow selection outline
			float posFactor = worldPos.x + worldPos.y + worldPos.z;
			buffer0.rgb = clamp(abs(mod(fract(frameTimeCounter * 0.25 + posFactor * 0.2) * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0,
			                    0.0, 1.0) * vec3(3.0, 2.0, 3.0);
		#elif SELECTION_OUTLINE == 2 // White
			buffer0.rgb = vec3(0.5);
		#endif
	}

	vec2 lightMap = pow2(lmcoord);
	vec3 blockLight = (lightMap.x + heldLight) * blocklightColor * 0.5;

	#ifndef NETHER
		vec3 sceneLight = mix(minLightColor, ambientColor + lightColor, lightMap.y);
	#else
		vec3 sceneLight = ambientColor;
	#endif

	buffer0.rgb *= sceneLight + blockLight + emission;

	storeProgramID(buffer1);
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/post/taa.glsl"
#include "/lib/util/vertexTransform.glsl"

flat out vec4 glColor;

#ifdef OVERWORLD
	flat out vec2 lmcoord;
#else
	flat out float lmcoordX;
#endif

void main() {
	applyVertexTransform();

	gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);
	gl_Position.z -= 0.0001;

	#ifdef OVERWORLD
		lmcoord = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
	#else
		lmcoordX = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).x - 0.03125) * 1.06667);
	#endif

	glColor = gl_Color;
}

#endif