#define GBUFFERS_TRANSLUCENT
//----------------- Gbuffers Translucent -----------------//

#include "/lib/common.glsl"

#ifndef GBUFFERS_ENTITIES_TRANSLUCENT
	#include "/lib/post/taa.glsl"
#endif

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D gtexture;

flat in vec3 vertexNormal;
flat in vec4 vertexTangent;

#ifdef GBUFFERS_ENTITIES_TRANSLUCENT
	int matID = currentRenderedItemId > 0 ? currentRenderedItemId : entityId;
#elif defined GBUFFERS_HAND_WATER
	int matID = currentRenderedItemId;
#elif defined GBUFFERS_BLOCK_TRANSLUCENT
	int matID = blockEntityId;
#else
	flat in int matID;
#endif

in vec2 texcoord;

#ifdef OVERWORLD
	in vec2 lmcoord;
#else
	in float lmcoordX;
	vec2 lmcoord = vec2(lmcoordX, 1.0);
#endif

#ifdef GBUFFERS_WATER
	in vec3 glColor;
#else
	in vec4 glColor;
#endif

#include "/lib/util/gbuffersScreenPos.glsl"
#include "/lib/util/programIDs.glsl"
#include "/lib/util/dither.glsl"

#include "/lib/materials/materialsCommon.glsl"
#include "/lib/lighting/mainLighting.glsl"

#include "/lib/settings/atmosphereSettings.glsl"
#ifdef NETHER_SMOKE_INTERNAL
    #include "/lib/atmospherics/netherSmoke.glsl"
#endif

/* DRAWBUFFERS:0 */
layout (location = 0) out vec4 color; // Main scene color

#if defined GBUFFERS_ENTITIES_TRANSLUCENT || (defined GBUFFERS_WATER && defined IS_IRIS && (WATER_DISTORTION > 0 || (PORTAL_ENHANCE == 1 && PORTAL_LIGHT == 1)))
    /* DRAWBUFFERS:04 */
    layout (location = 1) out float programID; // Program ID
#endif

void main() {	
	#if defined VL_CLOUDS_INTERNAL && !defined GBUFFERS_HAND_WATER
		float cloudDepth = textureLod(colortex5, gl_FragCoord.xy / view, 0).r;
		if (cloudDepth < 1.0) {
			cloudDepth -= dither_ign * 0.99 / 255.0; // Subtruct round dither

			float ndcZ = gl_FragCoord.z * 2.0 - 1.0;
			float rcpComp = ndcZ * gbufferProjectionInverse[2][3] + 
							       gbufferProjectionInverse[3][3];

			if (1.0 / rcpComp > 1.3333 * cloudDepth * far) discard;
		}
	#endif

	color = texture(gtexture, texcoord);
	vec3 colorP = color.rgb; color.rgb *= glColor.rgb;

	#ifndef GBUFFERS_WATER
		color.a *= glColor.a;
	#endif

	#ifdef GBUFFERS_ENTITIES_TRANSLUCENT
		color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
	#endif

	if (color.a < alphaTestRef) discard;

	vec3 screenPos = getGbuffersScreenPos();
	vec3 viewPos   = screenToView(screenPos);
	vec3 playerPos = viewToPlayer(viewPos);

	mat3 tbnMatrix = getTbnMatrix(vertexNormal, vertexTangent);

	Material material = getMaterial(tbnMatrix, color.rgb);
	applyHardcodedMaterials(material, color.a, colorP, tbnMatrix, screenPos, viewPos, playerPos, matID);

	color.rgb = computeMainLighting(material, screenPos, viewPos, playerPos, UNKNOWN_PROGRAM_ID);

	#ifdef NETHER_SMOKE_INTERNAL
		float wsdistP = length(playerPos);
        vec3 nPlayerPos = playerPos / wsdistP;

		DoNetherSmoke(color.rgb, nPlayerPos, wsdistP);
	#endif

	#ifdef GBUFFERS_ENTITIES_TRANSLUCENT
		storeProgramID(programID);
	#elif defined GBUFFERS_WATER && defined IS_IRIS && (WATER_DISTORTION > 0 || (PORTAL_ENHANCE == 1 && PORTAL_LIGHT == 1))
		storeProgramID(programID);
		#if PORTAL_ENHANCE == 1 && PORTAL_LIGHT == 1
			if (matID == 4) programID = float(GBUFFERS_NETHER_PORTAL_ID) / 255.0; // lets composite2 find portals
		#endif
	#endif
}     

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/util/vertexTransform.glsl"

flat out vec3 vertexNormal;
flat out vec4 vertexTangent;

#if !defined GBUFFERS_ENTITIES_TRANSLUCENT && !defined GBUFFERS_BLOCK_TRANSLUCENT && !defined GBUFFERS_HAND_WATER
	flat out int matID;
#endif

out vec2 texcoord;

#ifdef OVERWORLD
	out vec2 lmcoord;
#else
	out float lmcoordX;
#endif

#ifdef GBUFFERS_WATER
	out vec3 glColor;
#else
	out vec4 glColor;
#endif

attribute vec4 at_tangent;
attribute float mc_Entity;

void main() {
	applyVertexTransform();

	#ifndef GBUFFERS_ENTITIES_TRANSLUCENT
		gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);
	#endif

	#ifdef GBUFFERS_ENTITIES_TRANSLUCENT
		gl_Position.z -= 0.001; // Fixes Z fighting with certain entities
	#endif

	vertexNormal  = 	 normalize(gl_NormalMatrix * gl_Normal);
	vertexTangent = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);

	// Post 26.2 Sign Text non existent tangent workaround
	#if defined GBUFFERS_BLOCK_TRANSLUCENT && MC_VERSION >= 260200
		if (at_tangent.xyz == vec3(0.0)) {
			if (abs(dot(vertexNormal, upVec)) > 0.99)
				vertexTangent = vec4(-southVec, 1.0);
			else
				vertexTangent = vec4(-upVec, 1.0);
        }
	#endif

	#if !defined GBUFFERS_ENTITIES_TRANSLUCENT && !defined GBUFFERS_BLOCK_TRANSLUCENT && !defined GBUFFERS_HAND_WATER
		matID = int(mc_Entity);
	#endif

	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	#ifdef OVERWORLD
		lmcoord = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
	#else
		lmcoordX = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).x - 0.03125) * 1.06667);
	#endif

	#ifdef GBUFFERS_WATER
		glColor = gl_Color.rgb;
	#else
		glColor = gl_Color;
	#endif
}

#endif