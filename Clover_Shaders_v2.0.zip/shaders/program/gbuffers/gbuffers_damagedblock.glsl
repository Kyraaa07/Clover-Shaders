#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;

/* DRAWBUFFERS:8 */
layout (location = 0) out vec4 overlay; // Overlay color

void main() {
	overlay = texture(gtexture, texcoord);
	if (overlay.a < alphaTestRef) discard;

	overlay.rgb = SRGBToLinear(overlay.rgb);
	overlay.a = gl_FragCoord.z * 0.5 + 0.5;
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;

void main() {
	applyVertexTransform();

	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif