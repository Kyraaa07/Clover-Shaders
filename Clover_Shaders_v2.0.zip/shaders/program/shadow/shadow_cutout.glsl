#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform float alphaTestRef;
uniform sampler2D gtexture;

in vec2 texcoord;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Shadow color

void main() {
    if (texture(gtexture, texcoord).a < alphaTestRef) discard;
    color = vec3(0.0);
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"
#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;

void main() {
    applyVertexTransform();
    #if SHADOWS == 0
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    #endif
    
    gl_Position.xyz = getDistortedPos(gl_Position.xyz);
    
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif 