#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec3 glColor;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Shadow color

void main() {
    vec4 albedo = texture(gtexture, texcoord);

    if (albedo.a < alphaTestRef) discard;

    color = SRGBToLinear(albedo.rgb) * (1.0 - albedo.a);

    if (glColor.r > 0.0) { // Water
        vec3 shadowScreen = vec3(gl_FragCoord.xy / float(SHADOW_RESOLUTION), gl_FragCoord.z);
        vec3 shadowNdc  = getUndistortedPos(shadowScreen * 2.0 - 1.0);
        vec3 shadowView = diag(shadowProjectionInverse) * shadowNdc + shadowProjectionInverse[3].xyz;
        
        vec3 playerPos = mat3(shadowModelViewInverse) * shadowView + shadowModelViewInverse[3].xyz;
        vec3 worldPos  = cameraPosition + playerPos;    

        vec2 p0 = vec2(dot(worldPos.xz, vec2(0.10, 0.03)), dot(worldPos.xz, vec2(0.03, 0.06))) + 0.02 * frameTimeCounter;
        vec2 p1 = vec2(dot(worldPos.xz, vec2(0.04, 0.02)), dot(worldPos.xz, vec2(0.02, 0.08))) - 0.02 * frameTimeCounter;

        float caustics = textureLod(noisetex, p0, 0).a + 
                         textureLod(noisetex, p1, 0).a;
        caustics = min1(caustics * 0.9 + 0.25); 

        vec3 causticsColor = glColor.rgb * vec3(0.2, 1.0, 1.0);
        causticsColor.g = min(causticsColor.g, 0.25);

        float z1 = texelFetch(shadowtex1, ivec2(gl_FragCoord.xy), 0).r;
        float dist = z1 - gl_FragCoord.z;

        vec3 factor = pow(causticsColor, vec3(min(1.0, 0.4 + 125.0 * dist)));

        color = 3.5 * caustics * factor;
    }
    color /= shadowColorRange;
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"
#include "/lib/util/vertexTransform.glsl"

out vec2 texcoord;
out vec3 glColor;

attribute float mc_Entity;

void main() {
    applyVertexTransform();
    #if SHADOWS == 0
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0); // discard everything: shadow map is not used
        return;
    #endif
    
    gl_Position.xyz = getDistortedPos(gl_Position.xyz);
    
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glColor = int(mc_Entity) == 5 ? gl_Color.rgb : vec3(-1.0);
}

#endif 