#include "/program/voxy/voxyCommon.glsl"

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    // v1: only water is kept (as an opaque lit surface). Glass/ice etc. are skipped at LOD distance.
    if (int(parameters.customId) != 5) discard;
    ethEmitLOD(parameters, true);
}
