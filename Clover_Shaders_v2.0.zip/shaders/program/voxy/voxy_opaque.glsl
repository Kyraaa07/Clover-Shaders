#include "/program/voxy/voxyCommon.glsl"

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    if (parameters.sampledColour.a < ETH_LOD_ALPHA_CUTOFF) discard;
    ethEmitLOD(parameters, false);
}
