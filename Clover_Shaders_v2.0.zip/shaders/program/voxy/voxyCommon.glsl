//----------------- Clover x Voxy: shared LOD -> G-buffer writer -----------------//
// This file is pasted INTO Voxy's own fragment shader (as a patch).
// Do NOT declare uniforms/samplers here: Voxy injects the ones listed in voxy.json.
// Output layout matches Clover's gbuffers_solid (colortex3 = material, colortex4 = program ID).

layout (location = 0) out uvec4 ethBuffer0; // colortex3: packed material attributes
layout (location = 1) out float ethBuffer1; // colortex4: gbuffers program ID

// Must match lib/materials/materialsCommon.glsl (LOD_MAX_DIST) and lib/util/programIDs.glsl (GBUFFERS_VOXY_ID)
#define LOD_MAX_DIST 32768.0
#define GBUFFERS_VOXY_ID 14

// Puddle settings (RAIN_PUDDLES, PUDDLE_*) live in the material settings
#ifndef RAIN_PUDDLES
    #include "/lib/settings/materialSettings.glsl"
#endif

// ---- Tunables ----
#define ETH_LOD_PUDDLES 0 // 1 = rain puddles on Voxy LODs (off: lighter on performance)
#define ETH_LOD_ALPHA_CUTOFF 0.1
#define ETH_LOD_AO 1.0 // LODs have no vertex AO, so use a neutral value
#define ETH_LOD_SKY_FLOOR 0.9  // Min skylight for LOD land, side faces of voxels often sample 0 skylight and turn pitch black

// Same IGN dither as lib/util/dither.glsl (needed so packing rounds the same way)
float ethDither() {
    return fract(52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y + 0.40764916503 * float(frameCounter & 63)));
}

// Same packing as lib/util/packing.glsl
uvec4 ethPack4x8b(vec4 u, vec4 v, vec4 w, vec4 q, float d) {
    uvec4 uP = uvec4(u * 255.0 + d);
    uvec4 vP = uvec4(v * 255.0 + d);
    uvec4 wP = uvec4(w * 255.0 + d);
    uvec4 qP = uvec4(q * 255.0 + d);
    return uP | (vP << 8u) | (wP << 16u) | (qP << 24u);
}

vec2 ethOctaEncode(vec3 v) {
    vec2 octa = v.xy / (abs(v.x) + abs(v.y) + abs(v.z));
    if (v.z < 0.0) {
        vec2 s = vec2(octa.x > 0.0 ? 1.0 : -1.0, octa.y > 0.0 ? 1.0 : -1.0);
        octa = (1.0 - abs(octa.yx)) * s;
    }
    return octa * 0.5 + 0.5;
}

// Planar view-space depth of this fragment, rebuilt from Voxy's own projection (vxProj).
// This is independent of the vanilla far plane, so LODs far away can still be positioned in deferred.
float ethViewDepth() {
    float ndcZ = gl_FragCoord.z * 2.0 - 1.0;
    float d = vxProj[3][2] / (vxProj[2][2] + ndcZ);
    return clamp(d, 0.0, LOD_MAX_DIST);
}

// ---- Rain puddles on LOD (same look as lib/materials/puddles.glsl) ----
// Uses only the uniforms listed in voxy.json. Noise is computed here because
// noisetex is not available to Voxy's shader, so the pattern closely matches
// vanilla puddles but not pixel-for-pixel.
#define ETH_LOD_PUDDLE_ROUGH 0.02 // Not 0: exact 0 is reserved for LOD water

float ethLinearStep(float e0, float e1, float x) {
    return clamp((x - e0) / (e1 - e0), 0.0, 1.0);
}

float ethHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float ethValueNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = ethHash(i);
    float b = ethHash(i + vec2(1.0, 0.0));
    float c = ethHash(i + vec2(0.0, 1.0));
    float d = ethHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// World position of this LOD fragment, rebuilt from its view depth and Voxy's projection
vec3 ethWorldPos(float viewDepth) {
    vec2 ndc = gl_FragCoord.xy / vec2(viewWidth, viewHeight) * 2.0 - 1.0;
    vec3 viewPos = vec3(ndc * viewDepth / vec2(vxProj[0][0], vxProj[1][1]), -viewDepth);
    vec3 playerPos = transpose(mat3(gbufferModelView)) * (viewPos - gbufferModelView[3].xyz);
    return playerPos + cameraPosition;
}

void ethApplyPuddles(inout vec3 albedo, inout float roughness, inout float f0,
                     inout vec3 normalM, vec3 faceNormalP, float skyRaw, float viewDepth) {
#if RAIN_PUDDLES > 0 && defined OVERWORLD
    #if RAIN_PUDDLES == 2
        float puddleWet = max(PUDDLE_PERMANENT_AMOUNT, wetness); // always there, rain only adds more
    #else
        float puddleWet = wetness;
    #endif
    if (puddleWet <= 0.01) return;

    float upFacing = ethLinearStep(0.9, 0.99, faceNormalP.y);
    float openSky  = ethLinearStep(0.80, 0.95, skyRaw);

    // General damp ground (real rain only)
    float wetSurf = wetness * openSky * mix(0.5, 1.0, upFacing);
    albedo    = clamp(mix(albedo, albedo * 0.96, 0.5 * wetSurf), 0.0, 1.0);
    roughness = mix(roughness, 0.12, 0.5 * wetSurf);

    // Puddle blobs, same coordinates as the terrain version
    vec3 wPos = ethWorldPos(viewDepth);
    vec2 pCoord = (wPos.xz + 13.0 * floor(wPos.y + 0.01)) / (PUDDLE_SCALE * 40.0);
    float blob = ethValueNoise(pCoord) * 0.7 + ethValueNoise(pCoord * 2.7 + 0.37) * 0.3;

    float edge   = mix(0.78, 1.0 - PUDDLE_COVERAGE, clamp(puddleWet * 1.5, 0.0, 1.0));
    float puddle = smoothstep(edge, edge + 0.09, blob) * upFacing * openSky
                   * ethLinearStep(0.02, 0.25, puddleWet);
    if (puddle <= 0.001) return;

    float depthF  = ethLinearStep(edge, edge + 0.2, blob);
    float wetDark = 0.94 + 0.03 * (1.0 - depthF);
    vec3 filmTint = mix(vec3(1.0), vec3(0.92, 0.96, 1.0), 0.6);
    albedo    = clamp(mix(albedo, albedo * wetDark * filmTint, puddle), 0.0, 1.0);
    roughness = mix(roughness, ETH_LOD_PUDDLE_ROUGH, puddle * (0.6 + 0.4 * depthF));
    f0        = mix(f0, 0.045, puddle);

    // Ripples (only while it's actually raining, subtle)
    vec3 nWorld = vec3(0.0, 1.0, 0.0);
    #if PUDDLE_RIPPLES == 1
    float rainF = min(1.0, 2.0 * wetness);
    if (rainF > 0.01) {
        vec2 grad = vec2(0.0);
        for (int i = 0; i < 2; i++) {
            vec2 q = wPos.xz * (1.7 + 0.9 * float(i)) + 17.3 * float(i);
            vec2 cell = floor(q);
            vec2 f = fract(q) - 0.5;

            float h1 = fract(sin(dot(cell, vec2(127.1, 311.7))) * 43758.5453);
            float h2 = fract(sin(dot(cell, vec2(269.5, 183.3))) * 43758.5453);
            float h3 = fract(sin(dot(cell, vec2(419.2, 371.9))) * 43758.5453);

            vec2 d = f - (vec2(h2, h3) - 0.5) * 0.5;
            float dist  = length(d);
            float phase = fract(frameTimeCounter * (0.7 + 0.4 * h1) + h1 * 7.0);
            float ring  = dist - phase * 0.48;
            float env   = exp(-(ring * 14.0) * (ring * 14.0)) * (1.0 - phase) * (1.0 - phase);

            grad += (d / (dist + 1e-4)) * cos(ring * 45.0) * env;
        }
        nWorld = normalize(vec3(-0.09 * rainF * grad.x, 1.0, -0.09 * rainF * grad.y));
    }
    #endif

    vec3 nView = mat3(gbufferModelView) * nWorld;
    normalM = normalize(mix(normalM, nView, puddle));
#endif
}

// Face normal in world/player-aligned space (formula from Voxy shader-dev docs)
vec3 ethFaceNormal(uint face) {
    return vec3(uint((face >> 1) == 2), uint((face >> 1) == 0), uint((face >> 1) == 1))
           * (float(int(face) & 1) * 2.0 - 1.0);
}

void ethEmitLOD(VoxyFragmentParameters p, bool isWater) {
    vec3 albedo = p.sampledColour.rgb * p.tinting.rgb;

    float roughness = 1.0;
    float sss       = 0.0;
    float f0        = 0.02;
    float emission  = 0.0;

    int id = int(p.customId); // = mc_Entity / block.properties ID

    if (isWater) {
        // Distant water is drawn as an opaque lit surface (no blending on integer buffers)
        f0        = 0.05;
        roughness = 0.0;
        albedo    = p.tinting.rgb * vec3(0.06, 0.16, 0.13);
        albedo.g  = min(albedo.g, 0.048);
    } else {
        albedo = pow(albedo, vec3(2.2)); // SRGBToLinear, same as defaultMaterial.glsl

        if (id == 1) {                  // leaves
            sss = 0.4;
            roughness = 0.4;
        } else if (id == 2) {           // foliage
            sss = 0.4;
        } else if (id == 1018) {        // lava
            emission = 0.5;
        } else if (id == 1010 || id == 1013 || id == 1014) { // glowstone/shroomlight, sea lantern, magma
            emission = 0.35;
        }
    }

    vec3 nView = normalize(mat3(gbufferModelView) * ethFaceNormal(p.face));
    vec3 nMat  = nView; // normalM: lighting normal, can be perturbed by puddles

    vec2 lm = clamp(p.lightMap, 0.0, 1.0); // x = blocklight, y = skylight
    float skyRaw = lm.y;                    // raw skylight, used for "not under a roof"
    lm.y = isWater ? max(lm.y, 0.95) : max(lm.y, ETH_LOD_SKY_FLOOR);

    float viewDepth = ethViewDepth();

    // Rain puddles on LOD ground (not water, leaves, foliage or emitters)
#if ETH_LOD_PUDDLES == 1
    if (!isWater && id != 1 && id != 2 && emission < 0.01) {
        // skyRaw is not used for the roof test: Voxy's raw skylight on LOD faces is often low,
        // which wrongly removed puddles in patches. Up-facing faces are enough here.
        ethApplyPuddles(albedo, roughness, f0, nMat, ethFaceNormal(p.face), 1.0, viewDepth);
    }
#endif

    // 16-bit view depth stored in the two spare bytes (b1.a = low, b3.a = high)
    uint q = uint(viewDepth * (65535.0 / LOD_MAX_DIST) + 0.5);
    float depthLo = float(q & 255u) / 255.0;
    float depthHi = float((q >> 8u) & 255u) / 255.0;

    vec4 b1 = vec4(albedo, depthLo);
    vec4 b2 = vec4(ethOctaEncode(nMat), ethOctaEncode(nView)); // normalM, geoNormal
    vec4 b3 = vec4(roughness, sss, f0, depthHi);
    vec4 b4 = vec4(lm.x, lm.y, emission, ETH_LOD_AO);

    ethBuffer0 = ethPack4x8b(b1, b2, b3, b4, ethDither());

    // Write the depth bytes exactly (no dither) so they can never flip by +-1 between frames
    ethBuffer0.w = (ethBuffer0.w & 0xFF00FF00u) | (q & 255u) | (((q >> 8u) & 255u) << 16u);
    ethBuffer1 = float(GBUFFERS_VOXY_ID) / 255.0;
}
