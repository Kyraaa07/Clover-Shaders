#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

in vec2 texcoord;

#include "/lib/common.glsl"
#include "/lib/post/taa.glsl"

/* DRAWBUFFERS:07 */
layout (location = 0) out vec3 buffer0; // Main scene color
layout (location = 1) out vec4 buffer1; // History color & linear depth

void main() {
    float linearDepth;
    buffer0 = sampleTAAFilteredColor(ivec2(gl_FragCoord.xy), linearDepth);
    buffer1 = vec4(buffer0, linearDepth);
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
