uniform float viewWidth;
uniform float viewHeight;

#include "/lib/util/bloomTileSpace.glsl"

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

in vec2 texcoord;

#if TILE_INDEX == 0
    uniform sampler2D colortex0;
    #define tex colortex0
#else
    uniform sampler2D colortex2;
    #define tex colortex2
#endif

// Adapted from https://learnopengl.com/Guest-Articles/2022/Phys.-Based-Bloom
vec3 downsample() {
    #if TILE_INDEX == 0
        vec2 tilePos = texcoord;
        vec4 bu = vec4(0.0, 0.0, 1.0, 1.0);
    #else
        vec4 bu;
        vec2 tilePos = tileToScreen(texcoord, 0, bu);
    #endif

    vec3 a = textureLod(tex, cvec2(tilePos.x - 2 * x, tilePos.y + 2 * y, bu), 0).rgb;
    vec3 b = textureLod(tex, cvec2(tilePos.x,         tilePos.y + 2 * y, bu), 0).rgb;
    vec3 c = textureLod(tex, cvec2(tilePos.x + 2 * x, tilePos.y + 2 * y, bu), 0).rgb;

    vec3 d = textureLod(tex, cvec2(tilePos.x - 2 * x, tilePos.y, bu), 0).rgb;
    vec3 e = textureLod(tex, cvec2(tilePos.x,         tilePos.y, bu), 0).rgb;
    vec3 f = textureLod(tex, cvec2(tilePos.x + 2 * x, tilePos.y, bu), 0).rgb;

    vec3 g = textureLod(tex, cvec2(tilePos.x - 2 * x, tilePos.y - 2 * y, bu), 0).rgb;
    vec3 h = textureLod(tex, cvec2(tilePos.x,         tilePos.y - 2 * y, bu), 0).rgb;
    vec3 i = textureLod(tex, cvec2(tilePos.x + 2 * x, tilePos.y - 2 * y, bu), 0).rgb;

    vec3 j = textureLod(tex, cvec2(tilePos.x - x, tilePos.y + y, bu), 0).rgb;
    vec3 k = textureLod(tex, cvec2(tilePos.x + x, tilePos.y + y, bu), 0).rgb;
    vec3 l = textureLod(tex, cvec2(tilePos.x - x, tilePos.y - y, bu), 0).rgb;
    vec3 m = textureLod(tex, cvec2(tilePos.x + x, tilePos.y - y, bu), 0).rgb;

    vec3 downsample = e * 0.125;
    downsample += (a + c + g + i) * 0.03125;
    downsample += (b + d + f + h) * 0.0625;
    downsample += (j + k + l + m) * 0.125;
    return max(downsample, 0.001);
}

/* DRAWBUFFERS:2 */
layout (location = 0) out vec3 bloomColor; // Bloom color

void main() {
    bloomColor = downsample();
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    #if TILE_INDEX == 0
        gl_Position.xy = gl_Position.xy * 0.5 - 0.5;
    #else
        vec4 bu;
        gl_Position.xy = gl_Position.xy * 0.5 + 0.5;
        gl_Position.xy = tileToScreen(gl_Position.xy, 1, bu);
        gl_Position.xy = gl_Position.xy * 2.0 - 1.0;
    #endif
}

#endif