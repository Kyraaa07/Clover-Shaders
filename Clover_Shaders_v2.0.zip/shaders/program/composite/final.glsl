
#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/directives.glsl"
#include "/lib/common.glsl"

#include "/lib/settings/postSettings.glsl"
#include "/lib/settings/natureSettings.glsl"
#include "/lib/settings/effectsSettings.glsl"
#include "/lib/util/programIDs.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/util/vogelDiscSampling.glsl"
#include "/lib/post/gameplayEffects.glsl"
#include "/lib/post/displayColor.glsl"

in vec2 texcoordBase;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Main scene color

#if MOTION_BLUR == 1
    // Blurs each pixel along its screen-space motion caused by camera movement.
    // The previous frame position is found with the same reprojection matrix TAA uses.
    vec3 getMotionBlur(vec2 uv) {
        float depth = textureLod(depthtex0, uv, 0).r;
        if (depth < 0.56) return textureLod(colortex0, uv, 0).rgb; // Skip the first-person hand

        vec3 viewPos = screenToView(vec3(uv, depth));
        vec2 velocity = (uv - viewToPrvScreenXY(viewPos)) * (MOTION_BLUR_STRENGTH * 0.01);

        float velocityLength = length(velocity);
        if (velocityLength > 0.04) velocity *= 0.04 / velocityLength; // Avoid huge streaks after teleports

        vec3 blurred = vec3(0.0);
        for (int i = 0; i < 8; i++) {
            float t = (float(i) + 0.5) / 8.0 - 0.5;
            blurred += textureLod(colortex0, uv + velocity * t, 0).rgb;
        }
        return blurred / 8.0;
    }
#endif

#if LENS_FLARE == 1
    // Sun glow plus a few ghosts along the line from the sun through the screen centre.
    // Only drawn while the sun is above the horizon, visible (not behind terrain) and on screen.
    vec3 getLensFlare(vec2 uv) {
        vec4 clipPos = gbufferProjection * vec4(sunVec, 1.0);
        if (clipPos.w < 0.01) return vec3(0.0); // Sun is behind the camera

        vec2 sunUV = clipPos.xy / clipPos.w * 0.5 + 0.5;

        float sunHeight = dot(sunVec, upVec);
        float sunFade   = smoothstep(-0.02, 0.10, sunHeight) * (1.0 - rainFactor) * skylightFactor;
        float edgeDist  = max(abs(sunUV.x - 0.5), abs(sunUV.y - 0.5));
        sunFade *= 1.0 - smoothstep(0.5, 0.9, edgeDist);
        if (sunFade <= 0.0) return vec3(0.0);

        // Visibility from a few depth taps (sky has depth 1.0)
        vec2 s = clamp(sunUV, 0.001, 0.999);
        float vis = 0.0;
        vis += step(0.99999, textureLod(depthtex0, s, 0).r);
        vis += step(0.99999, textureLod(depthtex0, clamp(s + vec2( 0.01,  0.0), 0.001, 0.999), 0).r);
        vis += step(0.99999, textureLod(depthtex0, clamp(s + vec2(-0.01,  0.0), 0.001, 0.999), 0).r);
        vis += step(0.99999, textureLod(depthtex0, clamp(s + vec2( 0.0,  0.01), 0.001, 0.999), 0).r);
        vis += step(0.99999, textureLod(depthtex0, clamp(s + vec2( 0.0, -0.01), 0.001, 0.999), 0).r);
        vis *= 0.2;
        if (vis <= 0.0) return vec3(0.0);

        vec2 aspect   = vec2(view.x / view.y, 1.0);
        vec2 toCenter = vec2(0.5) - sunUV;

        // Sun glow
        float glowDist = length((uv - sunUV) * aspect);
        vec3 flare = vec3(1.0, 0.86, 0.62) * exp(-glowDist * 14.0) * 0.20;

        // Ghosts
        const float ghostT[4] = float[4](0.45, 1.25, 1.60, 2.10);
        const float ghostR[4] = float[4](0.030, 0.055, 0.018, 0.085);
        const vec3  ghostC[4] = vec3[4](vec3(0.9, 0.6, 0.3), vec3(0.3, 0.6, 1.0), vec3(0.5, 1.0, 0.4), vec3(0.8, 0.4, 1.0));

        for (int i = 0; i < 4; i++) {
            vec2 ghostPos   = sunUV + toCenter * ghostT[i];
            float ghostDist = length((uv - ghostPos) * aspect);
            flare += ghostC[i] * (1.0 - smoothstep(ghostR[i] * 0.4, ghostR[i], ghostDist)) * 0.12;
        }

        return flare * vis * sunFade * (LENS_FLARE_STRENGTH * 0.02);
    }
#endif

#if DOF == 1
    // Depth of field ported from Derivative (program/Post/DoF.glsl).
    // Thin-lens circle of confusion, spread over a golden-angle spiral with a per-pixel rotation
    // from dither_ign to hide banding. Runs on the HDR scene before bloom.
    float dofLinearDepth(float d) {
        return (near * far) / (d * (near - far) + far);
    }

    float dofCoC(float p, float z, float a, float f) {
        return (1.0 - p / z) * a * f / (p - f);
    }

    vec3 getDepthOfField(vec3 sceneColor, vec2 uv) {
        float depth = textureLod(depthtex0, uv, 0).r;
        if (depth < 0.56) return sceneColor; // first-person hand

        #if FOCUS_MODE == 0
            float focusDist = dofLinearDepth(textureLod(depthtex0, vec2(0.5), 0).r);
        #else
            float focusDist = float(MANUAL_FOCUS);
        #endif
        focusDist = max(focusDist, 0.5);

        float dist = dofLinearDepth(depth);

        float focalLength = 0.5 * 0.035 * gbufferProjection[1][1];
        float aperture = focalLength / CAMERA_APERTURE;
        float aspect = view.x / view.y;

        vec2 CoC = dofCoC(focusDist, dist, aperture, focalLength) * vec2(DOF_ANAMORPHIC_RATIO, aspect);
        CoC *= view * DOF_INTENSITY * 1e3 * tau;
        if (length(CoC) < 0.5) return sceneColor; // in focus, nothing to blur

        const float goldenAngleDOF = tau / (1.61803398874 + 1.0);
        mat2 goldenRotate = mat2(cos(goldenAngleDOF), -sin(goldenAngleDOF), sin(goldenAngleDOF), cos(goldenAngleDOF));

        float noise = dither_ign;
        vec2 rot = vec2(cos(noise * tau), sin(noise * tau)) * CoC;
        const float rSteps = 1.0 / float(DOF_SAMPLES);

        vec2 px = uv * view;
        #if DOF_CHROMA_DISPERSION == 1
            vec2 chromaPx = normalize(uv - 0.5) * 0.5 * CoC;
        #endif

        vec3 scene = vec3(0.0);
        for (int i = 0; i < DOF_SAMPLES; i++) {
            vec2 sampleOffset = rot * sqrt((noise + float(i)) * rSteps);
            #if DOF_CHROMA_DISPERSION == 1
                scene.r += textureLod(colortex0, (px + sampleOffset + chromaPx) / view, 0).r;
                scene.g += textureLod(colortex0, (px + sampleOffset) / view, 0).g;
                scene.b += textureLod(colortex0, (px + sampleOffset - chromaPx) / view, 0).b;
            #else
                scene += textureLod(colortex0, (px + sampleOffset) / view, 0).rgb;
            #endif
            rot *= goldenRotate;
        }

        return scene * rSteps;
    }
#endif

void main() {
    vec2 texcoord = texcoordBase;

    #if UNDERWATER_DISTORTION != -1 && !defined NETHER
        if (isCamInWater) {
            float uvCoordSum = texcoord.x + texcoord.y;

            float value = 32.0 * uvCoordSum + frameTimeCounter * 2.0;
            float shift = 1e-5 * sin(value) * UNDERWATER_DISTORTION;

            texcoord += shift;
        }
    #endif

    // Water distortion: wobble the scene behind water pixels.
    // Water pixels are tagged with their program ID in gbuffers_translucent (Iris).
    #if WATER_DISTORTION > 0
        if (getProgramIDAt(texcoordBase) == GBUFFERS_WATER_ID) {
            float wt = frameTimeCounter;
            vec2 n1 = textureLod(noisetex, texcoordBase * 1.5 + vec2( 0.031,  0.017) * wt, 0).rg - 0.5;
            vec2 n2 = textureLod(noisetex, texcoordBase * 3.7 + vec2(-0.023,  0.029) * wt, 0).rg - 0.5;
            texcoord += (n1 + 0.5 * n2) * (WATER_DISTORTION * 0.0003);
        }
    #endif

    #if MOTION_BLUR == 1
        color = getMotionBlur(texcoord);
    #else
        color = textureLod(colortex0, texcoord, 0).rgb;
    #endif
    
    #if IMAGE_SHARPENING != -1
        // 3x3 Tent Kernel
        // | 1 2 1 |           
        // | 2 4 2 | * 0.0625
        // | 1 2 1 |
        
        vec3 blur = (
            textureLod(colortex0, texcoord + vec2( 0.5,  0.5) / view, 0).rgb +
            textureLod(colortex0, texcoord + vec2(-0.5,  0.5) / view, 0).rgb +
            textureLod(colortex0, texcoord + vec2( 0.5, -0.5) / view, 0).rgb +
            textureLod(colortex0, texcoord + vec2(-0.5, -0.5) / view, 0).rgb
        ) * 0.25;

        vec3 sharpCol = max0(mix(blur, color, IMAGE_SHARPENING  * 0.01 + 1.0));        
        float unsharp = min1(abs(getLuminance(sharpCol - color) * 4.0));

        color = mix(sharpCol, color, unsharp);
    #endif

    #if DOF == 1
        color = getDepthOfField(color, texcoord);
    #endif

    #if BLOOM_STRENGTH != -1
        vec3 bloom = textureLod(colortex2, texcoord, 0).rgb;
        color = mix(color, bloom, BLOOM_STRENGTH * 25e-5);
    #endif

    #if LENS_FLARE == 1
        color += getLensFlare(texcoordBase);
    #endif

    #if VIGNETTE == 1
        vec2 aspect = vec2(view.x / view.y, 1.0);
        vec2 vigPos = (texcoordBase - 0.5) * aspect;
        float vigDist = length(vigPos) / length(aspect * 0.5); // 0 at centre, 1 at the corners
        float vig = smoothstep(VIGNETTE_RADIUS * 0.01, 1.0, vigDist);
        color *= 1.0 - VIGNETTE_STRENGTH * 0.01 * vig;
    #endif
    
    applyGameplayEffects(color, texcoordBase, dither_ign, view);

    color = getDisplayColor(color);
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoordBase;

void main() {
    gl_Position = ftransform();
    texcoordBase = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
