uniform float viewWidth;
uniform float viewHeight;

#include "/lib/util/bloomTileSpace.glsl"

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

in vec2 texcoord;

uniform sampler2D colortex2;

#if TILE_INDEX == 0
    uniform sampler2D colortex0;
#endif

// Adapted from https://learnopengl.com/Guest-Articles/2022/Phys.-Based-Bloom
vec3 upsample() {
    vec4 bu;
    vec2 prvTilePos = tileToScreen(texcoord, 1, bu);

    vec3 a = textureLod(colortex2, cvec2(prvTilePos.x - x, prvTilePos.y + y, bu), 0).rgb;
    vec3 b = textureLod(colortex2, cvec2(prvTilePos.x,     prvTilePos.y + y, bu), 0).rgb;
    vec3 c = textureLod(colortex2, cvec2(prvTilePos.x + x, prvTilePos.y + y, bu), 0).rgb;

    vec3 d = textureLod(colortex2, cvec2(prvTilePos.x - x, prvTilePos.y, bu), 0).rgb;
    vec3 e = textureLod(colortex2, cvec2(prvTilePos.x,     prvTilePos.y, bu), 0).rgb;
    vec3 f = textureLod(colortex2, cvec2(prvTilePos.x + x, prvTilePos.y, bu), 0).rgb;

    vec3 g = textureLod(colortex2, cvec2(prvTilePos.x - x, prvTilePos.y - y, bu), 0).rgb;
    vec3 h = textureLod(colortex2, cvec2(prvTilePos.x,     prvTilePos.y - y, bu), 0).rgb;
    vec3 i = textureLod(colortex2, cvec2(prvTilePos.x + x, prvTilePos.y - y, bu), 0).rgb;

    vec3 upsample = e * 4.0;
    upsample += (b + d + f + h) * 2.0;
    upsample += (a + c + g + i);
    upsample *= 0.0625;

    #if TILE_INDEX == 0
        upsample += textureLod(colortex0, texcoord, 0).rgb;
    #endif

    return upsample;
}

/* DRAWBUFFERS:2 */
layout (location = 0) out vec3 bloomColor; // Bloom color

void main() {
    bloomColor = upsample();
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    #if TILE_INDEX != 0
        vec4 bu;
        gl_Position.xy = gl_Position.xy * 0.5 + 0.5;
        gl_Position.xy = tileToScreen(gl_Position.xy, 0, bu);
        gl_Position.xy = gl_Position.xy * 2.0 - 1.0;
    #endif
}

#endif