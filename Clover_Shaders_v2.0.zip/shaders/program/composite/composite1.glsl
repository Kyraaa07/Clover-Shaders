#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

in vec2 texcoord;

#include "/lib/common.glsl"
#include "/lib/settings/lightingSettings.glsl"
#include "/lib/util/packing.glsl"

/* DRAWBUFFERS:1 */
layout (location = 0) out uvec3 shadowMap; // Packed shadowmap

void main() {
    float vlStrength = pow3(min1(20.0 * abs(pSunVec.y)));

    if (!isCamInWater) {
        float caveFactor   = 0.5 - 0.5 * skylightFactor;
        float sunsetFactor = pow2(invNoonFactor - nightFactor);

        vlStrength *= max(caveFactor, sunsetFactor);
    }

    if (vlStrength < 0.02) {shadowMap = uvec3(0); return;}

    ivec2 shadowCoord = ivec2(texcoord * float(SHADOW_RESOLUTION));

    float z0 = texelFetch(shadowtex0, shadowCoord, 0).r;
    float z1 = texelFetch(shadowtex1, shadowCoord, 0).r;

    vec3 shadowCol = texelFetch(shadowcolor0, shadowCoord, 0).rgb;

    shadowMap = uvec3(max0(z0 * 65535.0 - 8.0), max0(z1 * 65535.0 - 8.0), pack1_2x5b_6b(shadowCol));
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
