#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

in vec2 texcoord;

#include "/lib/common.glsl"
#include "/lib/post/taa.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/util/programIDs.glsl"
#include "/lib/settings/effectsSettings.glsl"
#include "/lib/atmospherics/plankton.glsl"

#include "/lib/atmospherics/submergedFog.glsl"
#include "/lib/atmospherics/darknessEffect.glsl"

#include "/lib/settings/materialSettings.glsl"
#if PORTAL_ENHANCE == 1 && PORTAL_LIGHT == 1 && defined IS_IRIS
    #include "/lib/post/portalGlow.glsl"
#endif

#if END_CRYSTAL_VORTEX == 1 && defined END
    #include "/lib/post/endCrystalVortex.glsl"
#endif

#ifdef OVERWORLD
    #include "/lib/settings/atmosphereSettings.glsl"
    #if LIGHTSHAFTS == 1
        #include "/lib/atmospherics/lightshafts.glsl"
    #endif
#endif

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Main scene color

void main() {
    color = textureLod(colortex0, texcoord, 0).rgb;

    vec3 screenPos = vec3(taaJitter(texcoord, -0.5), textureLod(depthtex0, texcoord, 0).r);
    vec3 viewPos   = screenToView(screenPos);
    vec3 playerPos = viewToPlayer(viewPos);
   
    float wsdist = length(playerPos); 

    vec4 overlay = textureLod(colortex8, texcoord, 0);
    if (fract(2.0 * overlay.a) < screenPos.z + 1.0 / 65535.0) {
        if (overlay.a > 0.5)
            color *= 4.6 * overlay.rgb; // block damage overlay
        else
            color += 0.1 * overlay.rgb; // enchantment glint 
    }

    #if PORTAL_ENHANCE == 1 && PORTAL_LIGHT == 1 && defined IS_IRIS
        doPortalGlow(color, screenPos, viewPos);
    #endif

    #if END_CRYSTAL_VORTEX == 1 && END_CRYSTAL_BEAM == 1 && defined END
        doEndCrystalVortex(color, playerPos, dither_ign);
    #endif

    DoSubmergedFog(color, wsdist);

    #if PLANKTON == 1 && defined OVERWORLD
        if (screenPos.z < 1.0)
            DoPlankton(color, playerPos, getProgramIDAt(texcoord) == GBUFFERS_WATER_ID);
    #endif
    
    #if LIGHTSHAFTS == 1 && defined OVERWORLD
        DoLightshafts(color, playerPos / wsdist, wsdist);
    #endif

    DoDarknessEffect(color, screenPos.xy);
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
