#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

in vec2 texcoord;

#include "/lib/common.glsl"
#include "/lib/post/fxaa.glsl"

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Main scene color

void main() {
    color = FXAA311();
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
