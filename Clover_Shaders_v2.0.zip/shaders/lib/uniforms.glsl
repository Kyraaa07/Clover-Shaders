uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowProjectionInverse;
uniform mat4 shadowModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 shadowProjection;
uniform mat4 gbufferModelView;
uniform mat4 shadowModelView;

uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;

uniform  sampler2D colortex0;
uniform usampler2D colortex1;
uniform  sampler2D colortex2;
uniform usampler2D colortex3;
uniform  sampler2D colortex4;
uniform  sampler2D colortex5;
uniform  sampler2D colortex6;
uniform  sampler2D colortex7;
uniform  sampler2D colortex8;

#if defined DEFERRED || defined GBUFFERS_TRANSLUCENT
    uniform sampler2DShadow shadowtex0;
    uniform sampler2DShadow shadowtex1;
#else
    uniform sampler2D shadowtex0;
    uniform sampler2D shadowtex1;
#endif

uniform sampler2D shadowcolor0;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D depthtex2;
uniform sampler2D noisetex;

uniform int blockEntityId;
uniform int isEyeInWater;
uniform int frameCounter;
uniform int renderStage;
uniform int worldTime;
uniform int worldDay;
uniform int entityId;

uniform float frameTimeCounter;
uniform float darknessFactor;
uniform float wetness;
uniform float nightVision;
uniform float viewHeight;
uniform float viewWidth;
uniform float blindness;
uniform float frameTime;
uniform float sunAngle;
uniform float near;
uniform float far;
uniform int vxRenderDistance; // Provided by Voxy (0 when Voxy is not active)

#if MC_VERSION >= 11700
    uniform float alphaTestRef;
#else
    float alphaTestRef = 0.1;
#endif

uniform vec3 previousCameraPosition;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;

uniform vec4 entityColor;

uniform ivec2 atlasSize;

uniform bool firstPersonCamera;

// Iris Exclusive Uniforms
uniform vec3 playerLookVector;
uniform vec3 relativeEyePosition;
uniform int currentRenderedItemId;

// Custom Uniforms
uniform float heldLight;
uniform float rainFactor;
uniform float invRainFactor;
uniform float skylightFactor;

uniform vec3 sunVec;
uniform vec3 pSunVec;
uniform vec3 vsCameraPosition;

uniform vec4 viewToPrvScreen0;
uniform vec4 viewToPrvScreen1;
uniform vec4 viewToPrvScreen2;
uniform vec4 viewToPrvScreen3;
mat4 viewToPrvScreenMatrix = mat4(viewToPrvScreen0, viewToPrvScreen1, viewToPrvScreen2, viewToPrvScreen3);

vec2 view = vec2(viewWidth, viewHeight);