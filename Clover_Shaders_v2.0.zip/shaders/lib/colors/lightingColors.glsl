#ifndef LIGHTING_COLORS_GLSL
#define LIGHTING_COLORS_GLSL

#include "/lib/settings/colorMultsSettings.glsl"

const vec3 blocklightColor = vec3(3.48, 2.1, 1.62) * BLOCKLIGHT_MULT;
const vec3 minLightColor = vec3(0.008, 0.008, 0.01);

#ifdef OVERWORLD
    uniform vec3 lightColor;
    uniform vec3 ambientColor;
#elif defined END
    // Purple / magenta End (Complementary + Euphoria style)
    const vec3 endLightColor   = vec3(0.62, 0.27, 0.95) * END_LIGHT_MULT;
    const vec3 endAmbientColor = vec3(0.030, 0.0105, 0.075) * END_SKY_MULT;
    
    const vec3 lightColor   = endLightColor;
    const vec3 ambientColor = endAmbientColor;
#elif defined NETHER
    #include "/lib/colors/altSkyColors.glsl"
    
    vec3 ambientColor = altSkyColor * 1.6 + 0.018;
#endif

#endif