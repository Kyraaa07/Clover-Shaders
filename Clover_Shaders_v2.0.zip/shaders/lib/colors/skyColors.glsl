#ifndef SKY_COLORS_GLSL
#define SKY_COLORS_GLSL

#include "/lib/settings/colorMultsSettings.glsl"

// -------- Sky Colors --------
uniform vec3 topSkyColor;
uniform vec3 middleSkyColor;
uniform vec3 bottomSkyColor;

// -------- Celestial Colors --------
uniform vec3 sunColor;
uniform vec3 sunGlareColor;

const vec3 moonCol = vec3(0.6, 0.7, 1.0);
const vec3 moonGlareColor = vec3(0.006, 0.012, 0.018) * NIGHT_SKY_MULT * moonCol;

const vec3 dawnScattColor = vec3(0.9, 0.4, 0.3);

#endif