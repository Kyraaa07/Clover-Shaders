#ifndef ALT_SKY_COLORS_GLSL
#define ALT_SKY_COLORS_GLSL

#include "/lib/settings/colorMultsSettings.glsl"

#ifdef NETHER
    vec3 fogColor2 = fogColor * fogColor + 1e-6;

    // Vanilla's fog colour already blends smoothly between Nether biomes, so it tells us where we are:
    //   Soul Sand Valley: teal fog (green > red)   Warped Forest: dark purple fog (blue > green, dark)
    //   Nether Wastes / Crimson Forest: red fog    Basalt Deltas: bright grey fog (left alone)
    float netherSoulBiome() {
        return smoothstep(0.02, 0.12, fogColor.g - fogColor.r);
    }

    float netherWarpedBiome() {
        float fogLuma = dot(fogColor, vec3(0.2126, 0.7152, 0.0722));
        return smoothstep(0.03, 0.07, fogColor.b - fogColor.g) * (1.0 - smoothstep(0.22, 0.32, fogLuma))
               * (1.0 - netherSoulBiome());
    }

    vec3 getNetherAltSky() {
        vec3 base = fogColor2 / dot(fogColor2, vec3(13.333, 8.333, 8.333)) * NETHER_SKY_MULT;

        #if NETHER_BIOME_COLORS == 1
            // Shift the hue of ambient light / fog, keep the brightness
            float altLuma = dot(base, vec3(0.2126, 0.7152, 0.0722));
            vec3 soulTint   = vec3(0.30, 1.00, 0.45);
            vec3 warpedTint = vec3(0.20, 0.85, 1.00);
            soulTint   *= altLuma / dot(soulTint,   vec3(0.2126, 0.7152, 0.0722));
            warpedTint *= altLuma / dot(warpedTint, vec3(0.2126, 0.7152, 0.0722));

            base = mix(base, soulTint,   netherSoulBiome()   * 0.75 * NETHER_BIOME_STRENGTH);
            base = mix(base, warpedTint, netherWarpedBiome() * 0.60 * NETHER_BIOME_STRENGTH);
        #endif

        return base;
    }

    // Lava glow used by the Nether smoke: red by default, green (Soul Sand Valley) / cyan (Warped Forest) per biome
    vec3 getNetherLavaGlow() {
        vec3 glow = vec3(1.3, 0.26, 0.06);

        #if NETHER_BIOME_COLORS == 1
            glow = mix(glow, vec3(0.16, 0.62, 0.28), netherSoulBiome()   * NETHER_BIOME_STRENGTH);
            glow = mix(glow, vec3(0.10, 0.52, 0.80), netherWarpedBiome() * NETHER_BIOME_STRENGTH);
        #endif

        return glow;
    }

    vec3 altSkyColor    = getNetherAltSky();
    vec3 netherLavaGlow = getNetherLavaGlow();
#elif defined END
    const vec3 altSkyColor = vec3(0.0050, 0.0016, 0.0100) * END_SKY_MULT; // Purple End fog / reflections
#endif

#endif