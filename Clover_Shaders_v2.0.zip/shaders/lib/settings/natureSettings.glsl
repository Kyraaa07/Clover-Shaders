#ifndef NATURE_SETTINGS_GLSL
#define NATURE_SETTINGS_GLSL

// ==================== WATER ====================
// Water colour presets: 0 Default (Clover), 1 Turquoise, 2 Tropical, 3 Murky, 4 Deep Ocean, 5 Custom
#define WATER_TEXTURE 0 //[0 1] 0 = shader waves + foam, 1 = vanilla water texture (flat, same colours)
#define WATER_COLOR 2 //[0 1 2 3 4 5]
#define WATER_CUSTOM_R 0.06 //[0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00] Custom water colour, red (used when WATER_COLOR is 5)
#define WATER_CUSTOM_G 0.16 //[0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00] Custom water colour, green (used when WATER_COLOR is 5)
#define WATER_CUSTOM_B 0.13 //[0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00] Custom water colour, blue (used when WATER_COLOR is 5)
#define WATER_OPACITY 20 //[0 5 10 15 20 25 30 35 40 45 50 60 70 80 90 100] Opacity of the water surface when viewed up close (%)
#define WATER_FOAM 100 //[0 25 50 75 100 125 150 175 200] Foam strength (%), 0 = off
#define WATER_DISTORTION 10 //[0 2 4 6 8 10 12 14 16 18 20] Refraction wobble strength, 0 = off (requires Iris)

#if WATER_COLOR == 1
    #define WATER_TINT vec3(0.04, 0.22, 0.22)
    #define WATER_GREEN_CAP 1.0
    #define WATER_FOG_COLOR vec3(0.004, 0.024, 0.026)
#elif WATER_COLOR == 2
    #define WATER_TINT vec3(0.10, 0.30, 0.32)
    #define WATER_GREEN_CAP 1.0
    #define WATER_FOG_COLOR vec3(0.010, 0.030, 0.034)
#elif WATER_COLOR == 3
    #define WATER_TINT vec3(0.12, 0.13, 0.05)
    #define WATER_GREEN_CAP 1.0
    #define WATER_FOG_COLOR vec3(0.016, 0.014, 0.005)
#elif WATER_COLOR == 4
    #define WATER_TINT vec3(0.02, 0.07, 0.16)
    #define WATER_GREEN_CAP 1.0
    #define WATER_FOG_COLOR vec3(0.002, 0.005, 0.018)
#elif WATER_COLOR == 5
    #define WATER_TINT vec3(WATER_CUSTOM_R, WATER_CUSTOM_G, WATER_CUSTOM_B)
    #define WATER_GREEN_CAP 1.0
    #define WATER_FOG_COLOR (vec3(WATER_CUSTOM_R, WATER_CUSTOM_G, WATER_CUSTOM_B) * 0.12)
#else
    #define WATER_TINT vec3(0.06, 0.16, 0.13)
    #define WATER_GREEN_CAP 0.048
    #define WATER_FOG_COLOR vec3(0.03, 0.17, 0.20)
#endif

// Deep water colour: the surface fades from the preset colour (shallow) to this blue (deep)
#define WATER_DEEP_TINT vec3(0.03, 0.10, 0.26)
// Middle stop: blue-green water a few blocks deep
#define WATER_MID_TINT vec3(0.04, 0.20, 0.28)

// ==================== WAVING TEXTURES ====================
// Wind movement for leaves and plants (block.properties: 1 = leaves, 2 = plants)
#define WAVING_TEXTURES 1 //[0 1]
#define WAVING_STRENGTH 10 //[0 2 4 6 8 10 12 14 16 18 20 25 30] Amount of movement
#define WAVING_SPEED 10 //[1 2 3 4 5 6 7 8 9 10 12 14 16 18 20] Speed of the wind

#endif
