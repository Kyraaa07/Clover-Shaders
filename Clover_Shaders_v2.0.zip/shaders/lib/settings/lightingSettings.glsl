#define SHADOW_SOFTNESS 1.00 //[0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
#define SHADOW_DISTANCE 160 //[64 96 128 160 192 224 256 288 320]
#define SHADOW_RESOLUTION 1024 //[256 512 1024 2048] Shadow map size. Lower = faster, blurrier shadows
#define HANDHELD_LIGHTING 1 //[0 1]
#define SHADOWS 1 //[0 1]
#define PLAYER_SHADOW 1 //[0 1]
#define ENTITY_SHADOWS 1 //[0 1]
#define SUN_ANGLE -40 //[-60 -50 -40 -30 -20 -10 0 10 20 30 40 50 60]
#define SSAO 1 //[0 1]
#define COLORED_LIGHT 1 //[0 1]
#define COLORED_LIGHT_STRENGTH 1.50 //[0.25 0.50 0.75 1.00 1.25 1.50 2.00]
#define COLORED_LIGHT_SATURATION 1.25 //[0.50 0.75 1.00 1.25 1.50 2.00]
#define COLORED_LIGHT_RADIUS 12.0 //[4.0 6.0 8.0 10.0 12.0 16.0]
#define COLORED_LIGHT_ORE_GLOW 0 //[0 1]
#define COLORED_LIGHT_QUALITY 2 //[1 2 3]

// ==================== BEAUTY NIGHT ====================
#define BEAUTY_NIGHT 1 //[0 1]
#define FIREFLY_AMOUNT 10 //[6 10 16 24 32]
#define FIREFLY_BRIGHTNESS 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define FIREFLY_LIGHT 1.0 //[0.0 0.5 1.0 1.5 2.0]
#define FIREFLY_SPEED 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define FIREFLY_COLORS 1 //[0 1]
#define CAVE_FIREFLIES 1 //[0 1]
#define CAVE_FIREFLY_AMOUNT 16 //[6 10 16 24 32]

const float shadowOffset = 0.0576 / SHADOW_DISTANCE * SHADOW_SOFTNESS;
const float shadowOffsetSSS = 0.32 / SHADOW_DISTANCE;
const float shadowColorRange = 4.0;