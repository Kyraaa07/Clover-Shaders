#ifndef EFFECTS_SETTINGS_GLSL
#define EFFECTS_SETTINGS_GLSL

// ==================== MOTION BLUR ====================
#define MOTION_BLUR 0 //[0 1]
#define MOTION_BLUR_STRENGTH 50 //[10 20 30 40 50 60 70 80 90 100] Length of the blur trail (%)

// ==================== LENS FLARE ====================
#define LENS_FLARE 1 //[0 1]
#define LENS_FLARE_STRENGTH 50 //[10 20 30 40 50 60 70 80 90 100] Brightness of the flare (%)

// ==================== VIGNETTE ====================
#define VIGNETTE 1 //[0 1]
#define VIGNETTE_STRENGTH 40 //[0 10 20 30 40 50 60 70 80 90 100] How dark the screen corners get (%)
#define VIGNETTE_RADIUS 70 //[30 40 50 60 70 80 90] Distance from the centre where darkening starts (%)

// ==================== DEPTH OF FIELD ====================
#define DOF 0 //[0 1]
#define DOF_SAMPLES 48 //[8 16 24 32 36 48 56 64 128] Number of blur samples. More is smoother but slower
#define DOF_INTENSITY 0.02 //[0.001 0.003 0.005 0.007 0.01 0.015 0.02 0.03 0.05 0.07 0.1] Overall blur amount
#define DOF_ANAMORPHIC_RATIO 1.0 //[0.5 0.6 0.8 0.9 1.0 1.1 1.2 1.3 1.5] Horizontal vs vertical blur ratio
#define DOF_CHROMA_DISPERSION 1 //[0 1] Splits colour channels slightly for a lens-like fringe
#define FOCUS_MODE 0 //[0 1] 0 = autofocus on screen centre, 1 = fixed distance
#define MANUAL_FOCUS 5.0 //[1.0 2.0 3.0 5.0 8.0 10.0 15.0 20.0 30.0 50.0 100.0] Fixed focus distance in blocks (FOCUS_MODE 1)
#define CAMERA_APERTURE 2.8 //[0.8 1.0 1.2 1.4 1.8 2.8 4.0 5.6 8.0 11.0 16.0 22.0] Lens f-stop. Lower = more blur

// ==================== PLANKTON (Ambience) ====================
#define PLANKTON 1 //[0 1] Glowing plankton inside the water
#define PLANKTON_COLOR 0 //[0 1 2] 0 = cyan, 1 = green, 2 = blue
#define PLANKTON_DENSITY 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0] How many plankton are visible
#define PLANKTON_BRIGHTNESS 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0] Strength of the glow
#define PLANKTON_REACTIVE 1 //[0 1] Plankton flare up when moving quickly through the water
#define PLANKTON_NIGHT_ONLY 1 //[0 1] Keep plankton almost invisible during the day
#define PLANKTON_SURFACE_GLOW 0 //[0 1] Faint glow on the water surface at night

// ==================== GAMEPLAY EFFECTS ====================
#define WATER_ON_CAMERA_EFFECT 1 //[0 1] Water drops and distortion when you enter or leave water
#define DAMAGE_TAKEN_EFFECT 1 //[0 1] Red tint and distortion when you take damage
#define LOW_HEALTH_EFFECT 1 //[0 1] Red edges and heartbeat distortion at low health
#define MOTION_AMOUNT 0.25 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] How strong the damage distortion is

#endif
