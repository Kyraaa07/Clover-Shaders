#ifndef FRESNEL_GLSL
#define FRESNEL_GLSL

vec3 getFresnel(float cosTheta, vec3 f0) {
    return mix(f0, vec3(1.0), pow5(1.0 - cosTheta));
}

#endif