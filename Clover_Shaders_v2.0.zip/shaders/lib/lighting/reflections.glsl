#include "/lib/lighting/fresnel.glsl"

#ifdef OVERWORLD
    #include "/lib/atmospherics/sky.glsl"
#else 
    #include "/lib/colors/altSkyColors.glsl"
#endif

#ifndef NETHER
    #include "/lib/atmospherics/submergedFog.glsl"
#endif

#include "/lib/settings/materialSettings.glsl"
#if REFLECTION_QUALITY > 0
    #include "/lib/util/raytracer.glsl"
#endif

void DoReflection(inout vec3 color, vec3 screenPos, vec3 viewPos, vec3 nViewPos, vec3 normalR, vec3 f0, float skylight) {
    float NdotVn = -dot(nViewPos, normalR);

    vec3 rayDir = 2.0 * NdotVn * normalR + nViewPos;

    float RdotU = dot(rayDir, upVec);
    float RdotS = dot(rayDir, sunVec);
    
    float skyFade = pow4(min1(RdotU + 1.0) * 
                         min1(skylight + 0.05));

    #ifdef OVERWORLD
        vec3 skyRef = getSky(RdotU, RdotS);
    #else
        // RdotS isn't used at all in this case, but I'm 
        // pretty sure the compiler automatically gets rid of it
        vec3 skyRef = altSkyColor;
    #endif
    #ifndef NETHER
        if (isCamInWater) skyRef = mix(waterFogColor, skyRef, clamp01(4.0 * RdotU));
    #endif
    vec3 envRef = skyRef * skyFade;

    vec3 finalRef = envRef;

    #if REFLECTION_QUALITY > 0
        const int stepcount = int(exp2(float(REFLECTION_QUALITY) + 2.0)); // 8, 16, 32

        vec3 hitPos;
        int rtHit = raytrace(hitPos, screenPos, viewPos, rayDir, stepcount);
    
        if (rtHit == RT_HIT_GEO) {
            // TODO: use a current frame color buffer for this
            vec2 uv  = viewToPrvScreenXY(screenToView(hitPos));
            finalRef = textureLod(colortex7, uv, 0).rgb;
        } else if (rtHit == RT_HIT_SKY)
            finalRef = skyRef;
    
        // Limit reflected brightness: bright emissive / lava pixels otherwise reflect as blown-out white blobs
        finalRef = min(finalRef, vec3(REFLECTION_CLAMP));

        // Blend towards env ref near screen edges
        float dist = maxOf(abs(0.5 - hitPos.xy));
        float edge = linearStep(0.45, 0.5, dist);

        finalRef = mix(finalRef, envRef, edge);
    #endif

    color = mix(color, finalRef, getFresnel(NdotVn, f0));
}