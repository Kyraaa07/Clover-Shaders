#ifndef LOD_SCREEN_SPACE_GLSL
#define LOD_SCREEN_SPACE_GLSL
// Screen-space shadows + AO for Voxy LODs (no shadow map exists out there).
// Works on "scene view depth": vanilla depthtex0 where available, otherwise the LOD view depth stored in colortex3.

#define LOD_SHADOW_STEPS 24      // Ray steps per LOD pixel
#define LOD_SHADOW_STRENGTH 0.85 // 0.0 = no LOD shadows
#define LOD_AO_STRENGTH 0.65     // 0.0 = no LOD AO

#include "/lib/materials/helpers/waterNormals.glsl"

// Same wave normals as vanilla water (gbuffers_water), rebuilt from world position since LODs have no texcoords.
// Fades out far away to avoid noise aliasing.
vec3 getLodWaterNormal(vec3 playerPos, vec3 geoNormal, vec3 nViewPos, float dist) {
    if (dot(geoNormal, upVec) < 0.9) return geoNormal;

    vec2 coord     = playerPos.xz + cameraPosition.xz;
    vec3 tangent   = mat3(gbufferModelView) * vec3(1.0, 0.0, 0.0);
    vec3 bitangent = mat3(gbufferModelView) * vec3(0.0, 0.0, 1.0);

    vec3 n = getWaterNormal(coord, mat3(tangent, bitangent, geoNormal), nViewPos);
    return normalize(mix(n, geoNormal, linearStep(250.0, 1200.0, dist)));
}

float getSceneViewDepth(vec2 uv) {
    float d = textureLod(depthtex0, uv, 0).r;
    if (d < 0.56) return 1e9; // hand
    if (d < 1.0) return -screenToView(vec3(uv, d)).z;

    ivec2 px = ivec2(uv * view);
    if (int(texelFetch(colortex4, px, 0).r * 255.1) == GBUFFERS_VOXY_ID)
        return getLodDepthAt(px);

    return 1e9; // sky
}

float getLodScreenShadow(vec3 viewPos, vec3 geoNormal, vec3 lightVec, float dither) {
    float dist = -viewPos.z;

    vec3 origin = viewPos + geoNormal * (0.15 + 0.004 * dist);
    float stepLen = 0.5 + 0.012 * dist;
    float t = stepLen * dither;

    float occ = 0.0;
    for (int i = 0; i < LOD_SHADOW_STEPS; i++) {
        t += stepLen;
        stepLen *= 1.2;

        vec3 p = origin + lightVec * t;
        if (p.z > -0.1) break;

        vec2 uv = viewToScreen(p).xy;
        if (isOutOfBounds(uv)) break;

        float pd   = -p.z;
        float diff = pd - getSceneViewDepth(uv);

        if (diff > 0.6 + 0.006 * pd && diff < 6.0 + 0.2 * pd) {
            occ = 1.0;
            break;
        }
    }

    return 1.0 - occ * LOD_SHADOW_STRENGTH;
}

float getLodAO(vec3 viewPos, vec3 geoNormal, float dither) {
    const int samples = 6;
    float dist = -viewPos.z;
    float r = 0.7 + 0.01 * dist;

    vec3 tangent   = normalize(cross(geoNormal, vec3(0.61941461212, 0.71587440337, 0.32225669412)));
    vec3 bitangent = cross(geoNormal, tangent);
    vec3 origin    = viewPos + geoNormal * 0.25 * r;

    float occ = 0.0;
    for (int i = 0; i < samples; i++) {
        float a   = (float(i) + dither) * 2.39996;
        float rad = sqrt((float(i) + 0.5) / float(samples)) * r;

        vec3 p = origin + (tangent * cos(a) + bitangent * sin(a)) * rad;
        if (p.z > -0.1) continue;

        vec2 uv = viewToScreen(p).xy;
        if (isOutOfBounds(uv)) continue;

        float diff = -p.z - getSceneViewDepth(uv);
        occ += step(max(0.25 * r, 0.6), diff) * step(diff, 3.0 * r);
    }

    return 1.0 - LOD_AO_STRENGTH * occ / float(samples);
}

#endif
