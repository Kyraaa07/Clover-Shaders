#include "/lib/util/vogelDiscSampling.glsl"

const vec3 irraVec = vec3(0.61941461212, 0.71587440337, 0.32225669412);

float getAmbientOcclusion(vec3 viewPos, vec3 nViewPos, vec3 geoNormal) {
    const int samplecount = 4;

    float hueristic = -dot(geoNormal, nViewPos) * lengthSquared(diag2(gbufferProjection) * view) / pow2(viewPos.z) * 17e-3;

    if (hueristic < 1.0) {
        return 1.0;
    }

    // We don't want to use the unjittered viewPos for ssao
    viewPos.xy += (diag2(gbufferProjectionInverse) * taaOffsets[frameCounter % 3] / view) * -viewPos.z;

    viewPos += 0.1 * geoNormal;

    vec3 tangent = normalize(cross(geoNormal, irraVec));
    mat2x3 tb = mat2x3(tangent, cross(geoNormal, tangent));

    float weightSum = 0.0;
    float occlusion = 0.0;
    for (int i = 0; i < samplecount; i++) {
        vec2 offset = vogelDisc(i, samplecount, dither_ign);
        vec3 screenPos = viewToScreen(viewPos + 0.4 * tb * offset);
    
        if (isOutOfBounds(screenPos.xy)) continue;

        float sampleDepth = textureLod(depthtex0, screenPos.xy, 0).r;
        if (sampleDepth < 0.56) continue;

        float linZ0 = linearizeDepth(sampleDepth);
        float linZ1 = linearizeDepth(screenPos.z);

        occlusion += step(linZ0 + 1e-7, linZ1) * linearStep(1.5, 0.5, (linZ1 - linZ0) * far);
        weightSum += 1.0;
    }

    if (weightSum < 1e-6) return 1.0;

    return 1.0 - occlusion / weightSum * linearStep(1.0, 2.0, hueristic);
}