// ---------------- Colored Blocklight (screen space) ----------------
// Light colour is taken from the glowing pixels around the shaded pixel, so it always matches the
// emitter: soul torch -> blue, redstone torch -> red, glowstone -> yellow, froglights, lanterns, etc.
// An emitter is any pixel that wrote emission > COLORED_LIGHT_EMISSION_MIN into the material buffer
// (colortex3), its colour is its own albedo. Noise from the sparse sampling is resolved by TAA.

#if COLORED_LIGHT_QUALITY == 1
    #define COLORED_LIGHT_SAMPLES 10
#elif COLORED_LIGHT_QUALITY == 2
    #define COLORED_LIGHT_SAMPLES 16
#else
    #define COLORED_LIGHT_SAMPLES 24
#endif

#if PBR_MODE == 0
    #define COLORED_LIGHT_EMISSION_MIN 0.04 // LabPBR emission is stored on a smaller scale (max 0.15)
#else
    #define COLORED_LIGHT_EMISSION_MIN 0.06 // Above this = proper light source (torch, lantern...), below = weak glow (ores)
#endif
#define COLORED_LIGHT_WEAK_MIN     0.012 // Below this nothing is emitted at all

// Returns the blocklight colour to use for this pixel (falls back to `defaultColor`).
// `glow` is extra coloured light radiated by weak emitters such as glowing ores (they have no vanilla light level).
vec3 getColoredBlocklight(vec3 defaultColor, vec3 viewPos, float blocklight, out vec3 glow) {
    glow = vec3(0.0);

    float dist = length(viewPos);
    if (dist < 0.01 || dist > 96.0) return defaultColor;

    float radius = COLORED_LIGHT_RADIUS; // in blocks

    // Radius of the world space search sphere, projected to pixels
    float radiusPx = radius * gbufferProjection[1][1] * 0.5 * viewHeight / dist;
          radiusPx = clamp(radiusPx, 6.0, 0.3 * viewHeight);

    vec2 pxCenter = gl_FragCoord.xy;

    vec3  colorSum  = vec3(0.0);
    float weightSum = 0.0;
    vec3  glowSum   = vec3(0.0);

    for (int i = 0; i < COLORED_LIGHT_SAMPLES; i++) {
        vec2 offset = vogelDisc(float(i), float(COLORED_LIGHT_SAMPLES), dither_ign) * radiusPx;
        ivec2 px = ivec2(pxCenter + offset);

        if (px.x < 0 || px.y < 0 || px.x >= int(viewWidth) || px.y >= int(viewHeight)) continue;

        float sampleDepth = texelFetch(depthtex0, px, 0).r;
        if (sampleDepth >= 1.0) continue; // Sky / Voxy LOD: no valid vanilla material data here

        vec4 b1, b2, b3, b4;
        unpack4_4x8b(texelFetch(colortex3, px, 0), b1, b2, b3, b4);

        float emission = b4.b;
        #if COLORED_LIGHT_ORE_GLOW == 1
        if (emission < COLORED_LIGHT_WEAK_MIN) continue;
        #else
        if (emission < COLORED_LIGHT_EMISSION_MIN) continue; // weak emitters (ores) glow only on their own texture, no light spill
        #endif

        vec3 samplePos = screenToView(vec3((vec2(px) + 0.5) / view, sampleDepth));
        float d = length(samplePos - viewPos);
        if (d > radius) continue;

        // Closer emitters count more
        float falloff = pow2(1.0 - d / radius);
        falloff /= 1.0 + 0.35 * d * d;

        // Emitter colour: keep hue / saturation, normalise brightness
        vec3 emitterColor = b1.rgb / max(0.05, maxOf(b1.rgb));

        if (emission >= COLORED_LIGHT_EMISSION_MIN) {
            float w = clamp01(emission * 4.0) * falloff;
            colorSum  += emitterColor * w;
            weightSum += w;
        } else {
            // Weak emitter (glowing ores): radiates its own colour, no vanilla light involved
            glowSum += emitterColor * (clamp01(emission * 10.0) * falloff);
        }
    }

    #if COLORED_LIGHT_ORE_GLOW == 1
        glow = glowSum * (5.0 / float(COLORED_LIGHT_SAMPLES) * 8.0) * COLORED_LIGHT_STRENGTH;
    #endif

    if (weightSum < 1e-4) return defaultColor;

    vec3 avgColor = colorSum / weightSum;
         avgColor = mix(vec3(getLuminance(avgColor)), avgColor, COLORED_LIGHT_SATURATION); // saturation control
         avgColor = pow(max(avgColor, vec3(0.0)), vec3(1.5));                               // sharpen the hue: red stays red
         avgColor /= max(1e-3, getLuminance(avgColor));                                     // luminance neutral

    // Keep the original brightness, only swap the hue
    vec3 coloredLight = avgColor * getLuminance(defaultColor);

    // How sure we are that an emitter is close by (saturates quickly so the colour is strong)
    float confidence = clamp01(weightSum * 25.0 * COLORED_LIGHT_STRENGTH);

    return mix(defaultColor, coloredLight, confidence);
}
