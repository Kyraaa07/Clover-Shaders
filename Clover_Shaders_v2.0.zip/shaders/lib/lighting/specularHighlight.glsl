#include "/lib/lighting/fresnel.glsl"

float TrowbridgeReitzGGX(float NdotH, float roughness) {
    float a2 = pow4(roughness);
    float denominator = pi * pow2(NdotH * NdotH * (a2 - 1.0) + 1.0);
    return a2 / denominator;
}

float GeometrySmith(float NdotV, float NdotL, float roughness) {
    float k = pow2(roughness + 1.0) / 8.0;
    float denom = (NdotL * (1.0 - k) + k) * (NdotV * (1.0 - k) + k);
    return NdotL * NdotV / denom;
}

vec3 getSpecularHighlight(vec3 V, vec3 N, vec3 L, float roughness, vec3 f0) {
    roughness = roughness * 0.9 + 0.08;   
    vec3 H = normalize(L + V);
    
    float NdotL = max0(dot(N, L));
    float NdotV = max0(dot(N, V));
    float NdotHA = mix(-dot(L, reflect(V, N)), 1.0, 0.94);
    float NdotHB = mix(dot(N, H), 1.0, 0.98 - 0.04 * sqrtApprox(NdotV * (1.0 - 0.9 * NdotL)));
    float NdotH  = mix(NdotHA, NdotHB, NdotL * 0.5 + 0.5);

    float D = TrowbridgeReitzGGX(NdotH, roughness);
    float G = GeometrySmith(NdotV, NdotL, roughness);

    vec3 F = getFresnel(dot(V, H), f0);
    vec3 specular = F * (F * 0.8 + 0.2) * D * G / (4.0 * NdotV + 1e-6);  

    return min(vec3(25.0), specular);
}