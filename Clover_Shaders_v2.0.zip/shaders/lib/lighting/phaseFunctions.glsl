#ifndef PHASE_FUNCTIONS
#define PHASE_FUNCTIONS

float henyeyGreenstein(float cosTheta, float g) {
    float g2 = pow2(g);
    float denom = (1.0 + g2 - 2.0 * g * cosTheta);
          denom *= 4.0 * pi * sqrt(denom);
    return (1.0 - g2) / denom;
}

const float isotropicPhase = 0.25 / pi;

#endif