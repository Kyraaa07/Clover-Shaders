
#ifdef COMPOSITE4
    #include "/lib/util/programIDs.glsl"

    // https://research.activision.com/publications/archives/filmic-smaasharp-morphological-and-temporal-antialiasing
    vec4 textureCatmullRom(sampler2D colortex, vec2 texcoord) {
        vec2 position = texcoord * vec2(viewWidth, viewHeight);
        vec2 centerPosition = floor(position - 0.5) + 0.5;
        vec2 f = position - centerPosition;
        vec2 f2 = f * f;
        vec2 f3 = f * f2;

        float c = 0.7;
        vec2 w0 =        -c  * f3 +  2.0 * c         * f2 - c * f;
        vec2 w1 =  (2.0 - c) * f3 - (3.0 - c)        * f2         + 1.0;
        vec2 w2 = -(2.0 - c) * f3 + (3.0 -  2.0 * c) * f2 + c * f;
        vec2 w3 =         c  * f3 -                c * f2;

        vec2 w12 = w1 + w2;
        vec2 tc12 = (centerPosition + w2 / w12) / vec2(viewWidth, viewHeight);

        vec2 tc0 = (centerPosition - 1.0) / vec2(viewWidth, viewHeight);
        vec2 tc3 = (centerPosition + 2.0) / vec2(viewWidth, viewHeight);

        float fw0 = (w12.x * w0.y );
        float fw1 = (w0.x  * w12.y);
        float fw2 = (w12.x * w12.y);
        float fw3 = (w3.x  * w12.y);
        float fw4 = (w12.x * w3.y );

        vec4 color = textureLod(colortex, vec2(tc12.x, tc0.y ), 0) * fw0 +
                     textureLod(colortex, vec2(tc0.x,  tc12.y), 0) * fw1 +
                     textureLod(colortex, vec2(tc12.x, tc12.y), 0) * fw2 +
                     textureLod(colortex, vec2(tc3.x,  tc12.y), 0) * fw3 +
                     textureLod(colortex, vec2(tc12.x, tc3.y ), 0) * fw4;
        return color / (fw0 + fw1 + fw2 + fw3 + fw4);
    }

    // https://gdcvault.com/play/1022970/Temporal-Reprojection-Anti-Aliasing-in
    vec3 clip_aabb(vec3 aabb_min, vec3 aabb_max, vec3 q) {
        aabb_max += getLuminance(aabb_max) * 16e-3;

        vec3 p_clip = 0.5 * (aabb_max + aabb_min);
        vec3 e_clip = 0.5 * (aabb_max - aabb_min);

        vec3 v_clip = q - p_clip;
        vec3 a_unit = abs(v_clip / e_clip);
        float ma_unit = maxOf(a_unit);

        return ma_unit > 1.0 ? p_clip + v_clip / ma_unit : q;
    }

    void DoColorClipping(vec3 centerColor, inout vec3 accumulatedColor, ivec2 texelCoord) {
        vec3 col0 = texelFetch(colortex0, texelCoord + ivec2( 0,  1), 0).rgb;       
        vec3 col1 = texelFetch(colortex0, texelCoord + ivec2( 1,  0), 0).rgb;     
        vec3 col2 = texelFetch(colortex0, texelCoord + ivec2( 0, -1), 0).rgb;
        vec3 col3 = texelFetch(colortex0, texelCoord + ivec2(-1,  0), 0).rgb;  
        vec3 col4 = texelFetch(colortex0, texelCoord + ivec2( 1,  1), 0).rgb;
        vec3 col5 = texelFetch(colortex0, texelCoord + ivec2(-1, -1), 0).rgb;
        vec3 col6 = texelFetch(colortex0, texelCoord + ivec2(-1,  1), 0).rgb;
        vec3 col7 = texelFetch(colortex0, texelCoord + ivec2( 1, -1), 0).rgb; 

        vec3 minColM = min(centerColor, min(col0, min(col1, min(col2, col3))));
        vec3 maxColM = max(centerColor, max(col0, max(col1, max(col2, col3))));

        vec3 minCol = 0.5 * (min(minColM, min(col4, min(col5, min(col6, col7)))) + minColM);
        vec3 maxCol = 0.5 * (max(maxColM, max(col4, max(col5, max(col6, col7)))) + maxColM);
        
        accumulatedColor = clip_aabb(minCol, maxCol, accumulatedColor);
    }

    // As recommended in https://gdcvault.com/play/1022970/Temporal-Reprojection-Anti-Aliasing-in
    // Reprojecting the closest fragment guarantees a background fragment will travel with its occluder
    vec3 getClosestFragment(ivec2 coord0) {
	    ivec2 coord1 = coord0 + ivec2(-2, -2);
	    ivec2 coord2 = coord0 + ivec2( 2, -2);
	    ivec2 coord3 = coord0 + ivec2(-2,  2);
	    ivec2 coord4 = coord0 + ivec2( 2,  2);

	    vec3 p0 = vec3(coord0, texelFetch(depthtex0, coord0, 0).r);
	    vec3 p1 = vec3(coord1, texelFetch(depthtex0, coord1, 0).r);
	    vec3 p2 = vec3(coord2, texelFetch(depthtex0, coord2, 0).r);
	    vec3 p3 = vec3(coord3, texelFetch(depthtex0, coord3, 0).r);
	    vec3 p4 = vec3(coord4, texelFetch(depthtex0, coord4, 0).r);

        vec3 pm = p0.z < p1.z ? p0 : p1;
             pm = pm.z < p2.z ? pm : p2;
             pm = pm.z < p3.z ? pm : p3;
             pm = pm.z < p4.z ? pm : p4;

	    return vec3((pm.xy + 0.5) / view, pm.z);
    }

    vec3 sampleTAAFilteredColor(ivec2 texelCoord, out float linearDepth) {
        vec3 centerColor = texelFetch(colortex0, texelCoord, 0).rgb;
    
        vec2 prvPos  = texcoord;
        vec3 closest = getClosestFragment(texelCoord);

        linearDepth = linearizeDepth(closest.z);

        if (closest.z > 0.56) {
            prvPos += viewToPrvScreenXY(screenToView(closest)) - closest.xy;
            if (isOutOfBounds(prvPos)) return centerColor;
        }

        vec4 historyColor = textureCatmullRom(colortex7, prvPos);
        if (any(isnan(historyColor))) return centerColor;

        float nonLinearDepth = (far + near - 2.0 * near / historyColor.a) / (far - near);
        if (closest.z > 0.56 && nonLinearDepth < 0.56) return centerColor;

        DoColorClipping(centerColor, historyColor.rgb, texelCoord);
        
	    vec2 centerFactor = 1.0 - 2.0 * abs(fract(vec2(viewWidth, viewHeight) * prvPos) - 0.5);
        float depthRejection  = 1.0 - min1(0.1 * far * abs(linearDepth - historyColor.a));
	    float centerRejection = centerFactor.x * centerFactor.y * 0.25 + 0.75;
        
        float blend = 0.95 * centerRejection * depthRejection;

        float fovFactor = abs(gbufferProjection[0][0] - gbufferPreviousProjection[0][0]);
        if (fovFactor > 0.01) blend *= 0.3;

        // We check at closest.xy in case the fragment reprojected with an entity
        if (closest.z < 1.0 && getProgramIDAt(closest.xy) == GBUFFERS_ENTITIES_ID)
            blend *= 0.5 * float(lengthSquared(cameraPosition - previousCameraPosition) < 1e-6) + 0.4;
        
        // Sky has no geometry (depth 1.0) and its stars move, so temporal history would
        // smear shooting stars into long, thick trails. Check this pixel's own depth, not the
        // nearest one: at the Voxy / vanilla chunk border the nearest depth can come from geometry.
        float centerDepth = texelFetch(depthtex0, texelCoord, 0).r;
        if (centerDepth > 0.99999) blend = 0.0;

        return mix(centerColor, historyColor.rgb, blend);
    }
#else
    vec2 taaOffsets[3] = vec2[3](vec2(0.5, 0.0), vec2(-0.25, 0.4330127), vec2(-0.25, -0.4330127));

    vec2 taaJitter(vec2 coord, float w) {
        vec2 offset = taaOffsets[frameCounter % 3] * (w / view);
        return coord + offset;
    }
#endif
