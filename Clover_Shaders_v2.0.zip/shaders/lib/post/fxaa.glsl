// https://blog.simonrodriguez.fr/articles/2016/07/implementing_fxaa.html
vec3 FXAA311() {
    const float SUBPIXEL_QUALITY = 0.75;
    const int ITERATIONS = 12;
    const float QUALITY[] = float[](1.5, 2.0, 2.0, 2.0, 2.0, 4.0, 8.0);

    vec2 inverseScreenSize = 1.0 / view;

    vec3 centerColor = textureLod(colortex0, texcoord, 0).rgb;
    float lumaCenter = getLuminance(centerColor);

    float lumaUp = getLuminance(textureOffset(colortex0, texcoord, ivec2(0, 1)).rgb);
    float lumaDown = getLuminance(textureOffset(colortex0, texcoord, ivec2(0, -1)).rgb);
    float lumaLeft = getLuminance(textureOffset(colortex0, texcoord, ivec2(-1, 0)).rgb);
    float lumaRight = getLuminance(textureOffset(colortex0, texcoord, ivec2(1, 0)).rgb);

    float absDiffUp    = abs(lumaCenter - lumaUp  );
    float absDiffDown  = abs(lumaCenter - lumaDown);
    float absDiffLeft  = abs(lumaCenter - lumaLeft);
    float absDiffRight = abs(lumaCenter - lumaRight);

    float rMax = max(max(absDiffUp, absDiffDown), max(absDiffLeft, absDiffRight));
    float rMin = min(min(absDiffUp, absDiffDown), min(absDiffLeft, absDiffRight));

    if (rMax - rMin < 0.15) return centerColor;

    float lumaUpLeft = getLuminance(textureOffset(colortex0, texcoord, ivec2(-1, 1)).rgb);
    float lumaUpRight = getLuminance(textureOffset(colortex0, texcoord, ivec2(1, 1)).rgb);
    float lumaDownLeft = getLuminance(textureOffset(colortex0, texcoord, ivec2(-1, -1)).rgb);
    float lumaDownRight = getLuminance(textureOffset(colortex0, texcoord, ivec2(1, -1)).rgb);

    float lumaMin = min(lumaCenter, min(min(lumaDown, lumaUp), min(lumaLeft, lumaRight)));
    float lumaMax = max(lumaCenter, max(max(lumaDown, lumaUp), max(lumaLeft, lumaRight)));
    float lumaRange = lumaMax - lumaMin;

    float lumaDownUp = lumaDown + lumaUp;
    float lumaLeftRight = lumaLeft + lumaRight;

    float lumaUpCorners = lumaUpRight + lumaUpLeft;
    float lumaDownCorners = lumaDownLeft + lumaDownRight;
    float lumaLeftCorners = lumaDownLeft + lumaUpLeft;
    float lumaRightCorners = lumaDownRight + lumaUpRight;

    float edgeHorizontal = abs(-2.0 * lumaLeft + lumaLeftCorners) + abs(-2.0 * lumaCenter + lumaDownUp ) * 2.0 + abs(-2.0 * lumaRight + lumaRightCorners);
    float edgeVertical = abs(-2.0 * lumaUp + lumaUpCorners) + abs(-2.0 * lumaCenter + lumaLeftRight) * 2.0 + abs(-2.0 * lumaDown + lumaDownCorners);

    bool isHorizontal = (edgeHorizontal >= edgeVertical);

    float luma1 = isHorizontal ? lumaDown : lumaLeft;
    float luma2 = isHorizontal ? lumaUp : lumaRight;

    float gradient1 = luma1 - lumaCenter;
    float gradient2 = luma2 - lumaCenter;

    bool is1Steepest = abs(gradient1) >= abs(gradient2);
    float gradientScaled = 0.25 * max(abs(gradient1), abs(gradient2));

    float stepLength = isHorizontal ? inverseScreenSize.y : inverseScreenSize.x;

    float lumaLocalAverage = 0.0;

    if (is1Steepest) {
        stepLength = -stepLength;
        lumaLocalAverage = 0.5 * (luma1 + lumaCenter);
    } else
        lumaLocalAverage = 0.5 * (luma2 + lumaCenter);

    vec2 currentUv = texcoord;
    if (isHorizontal)
        currentUv.y += stepLength * 0.5;
    else
        currentUv.x += stepLength * 0.5;

    vec2 offset = isHorizontal ? vec2(inverseScreenSize.x, 0.0) : vec2(0.0, inverseScreenSize.y);
    vec2 uv1 = currentUv - offset;
    vec2 uv2 = currentUv + offset;

    float lumaEnd1 = getLuminance(textureLod(colortex0, uv1, 0).rgb);
    float lumaEnd2 = getLuminance(textureLod(colortex0, uv2, 0).rgb);
    lumaEnd1 -= lumaLocalAverage;
    lumaEnd2 -= lumaLocalAverage;

    bool reached1 = abs(lumaEnd1) >= gradientScaled;
    bool reached2 = abs(lumaEnd2) >= gradientScaled;
    bool reachedBoth = reached1 && reached2;

    if (!reached1) uv1 -= offset;
    if (!reached2) uv2 += offset;

    if (!reachedBoth) {
        for (int i = 2; i < ITERATIONS; i++){
            if (!reached1){
                lumaEnd1 = getLuminance(textureLod(colortex0, uv1, 0).rgb);
                lumaEnd1 = lumaEnd1 - lumaLocalAverage;
            }
            if (!reached2){
                lumaEnd2 = getLuminance(textureLod(colortex0, uv2, 0).rgb);
                lumaEnd2 = lumaEnd2 - lumaLocalAverage;
            }
            reached1 = abs(lumaEnd1) >= gradientScaled;
            reached2 = abs(lumaEnd2) >= gradientScaled;
            reachedBoth = reached1 && reached2;

            if (!reached1){
                uv1 -= offset * QUALITY[min(i, 6)];
            }
            if (!reached2){
                uv2 += offset * QUALITY[min(i, 6)];
            }

            if (reachedBoth) break;
        }
    }

    float distance1 = isHorizontal ? (texcoord.x - uv1.x) : (texcoord.y - uv1.y);
    float distance2 = isHorizontal ? (uv2.x - texcoord.x) : (uv2.y - texcoord.y);

    bool isDirection1 = distance1 < distance2;
    float distanceFinal = min(distance1, distance2);

    float edgeThickness = (distance1 + distance2);

    float pixelOffset = - distanceFinal / edgeThickness + 0.5;

    bool isLumaCenterSmaller = lumaCenter < lumaLocalAverage;

    bool correctVariation = ((isDirection1 ? lumaEnd1 : lumaEnd2) < 0.0) != isLumaCenterSmaller;

    float finalOffset = correctVariation ? pixelOffset : 0.0;

    float lumaAverage = (1.0 / 12.0) * (2.0 * (lumaDownUp + lumaLeftRight) + lumaLeftCorners + lumaRightCorners);
    float subPixelOffset1 = clamp01(abs(lumaAverage - lumaCenter) / lumaRange);
    float subPixelOffset2 = (-2.0 * subPixelOffset1 + 3.0) * subPixelOffset1 * subPixelOffset1;
    float subPixelOffsetFinal = subPixelOffset2 * subPixelOffset2 * SUBPIXEL_QUALITY;

    finalOffset = max(finalOffset, subPixelOffsetFinal);

    vec2 finalUv = texcoord;
    if (isHorizontal)
        finalUv.y += finalOffset * stepLength;
    else
        finalUv.x += finalOffset * stepLength;

    return textureLod(colortex0, finalUv, 0).rgb;
}