#ifndef PORTAL_GLOW_GLSL
#define PORTAL_GLOW_GLSL

#include "/lib/settings/materialSettings.glsl"
#include "/lib/util/programIDs.glsl"
#include "/lib/util/vogelDiscSampling.glsl"

// Nether Portal light: the portal is a translucent surface (drawn after the deferred pass), so it cannot
// feed the normal coloured light. Instead its pixels are tagged in colortex4 and every other pixel
// gathers purple light from the tagged pixels around it (screen space, resolved by TAA).
void doPortalGlow(inout vec3 color, vec3 screenPos, vec3 viewPos) {
    if (screenPos.z >= 1.0) return;

    ivec2 px0 = ivec2(gl_FragCoord.xy);
    if (int(texelFetch(colortex4, px0, 0).r * 255.1) == GBUFFERS_NETHER_PORTAL_ID) return;

    float dist = max(length(viewPos), 0.1);
    float radius = PORTAL_LIGHT_RADIUS;

    float radiusPx = radius * gbufferProjection[1][1] * 0.5 * viewHeight / dist;
          radiusPx = clamp(radiusPx, 6.0, 0.3 * viewHeight);

    const int samples = 16;
    float glow = 0.0;

    for (int i = 0; i < samples; i++) {
        vec2 offset = vogelDisc(float(i), float(samples), dither_ign) * radiusPx;
        ivec2 px = ivec2(gl_FragCoord.xy + offset);

        if (px.x < 0 || px.y < 0 || px.x >= int(viewWidth) || px.y >= int(viewHeight)) continue;
        if (int(texelFetch(colortex4, px, 0).r * 255.1) != GBUFFERS_NETHER_PORTAL_ID) continue;

        float d = texelFetch(depthtex0, px, 0).r;
        vec3 samplePos = screenToView(vec3((vec2(px) + 0.5) / view, d));

        float dd = length(samplePos - viewPos);
        if (dd > radius) continue;

        float f = pow2(1.0 - dd / radius);
        f /= 1.0 + 0.35 * dd * dd;

        glow += f;
    }

    float g = min(glow * (6.0 / float(samples)) * PORTAL_LIGHT_STRENGTH, 2.0);

    color += (color * 1.2 + vec3(0.02)) * NETHER_PORTAL_LIGHT_COLOR * g;
}

#endif
