#ifndef GAMEPLAY_EFFECTS_GLSL
#define GAMEPLAY_EFFECTS_GLSL

#include "/lib/settings/effectsSettings.glsl"

// Gameplay post effects: water drops when entering or leaving water, red damage tint,
// low-health red edges and a heartbeat distortion. Ported from Bliss (lib/gameplay_effects.glsl).
// The values come from uniform.float lines in shaders.properties (smooth() of player state).

uniform float exitWater;
uniform float enterWater;
uniform float oneHeart;
uniform float threeHeart;
uniform float CriticalDamageTaken;
uniform float MinorDamageTaken;
uniform float currentPlayerHealth;
uniform float maxPlayerHealth;

void applyGameplayEffects(inout vec3 color, vec2 texcoord, float noise, vec2 res) {
    bool isDead = false;
    #ifdef IS_IRIS
        isDead = currentPlayerHealth * maxPlayerHealth <= 0.0 && currentPlayerHealth > -1.0;
    #endif

    float aspect = res.x / res.y;
    float distortmask = 0.0;
    float vignette = sqrt(clamp(dot(texcoord * 2.0 - 1.0, texcoord * 2.0 - 1.0) * 0.5, 0.0, 1.0));

    //////////////////////// DAMAGE DISTORTION /////////////////////
    #if defined LOW_HEALTH_EFFECT || defined DAMAGE_TAKEN_EFFECT
        float heartBeat = pow(sin(frameTimeCounter * 15.0) * 0.5 + 0.5, 2.0) * 0.2 + 0.1;

        float damageDistortion = vignette * noise * heartBeat * threeHeart;
        damageDistortion = mix(damageDistortion, vignette * (0.5 + noise), CriticalDamageTaken) * MOTION_AMOUNT;

        distortmask = isDead ? vignette * (0.7 + noise * 0.3) : damageDistortion;
    #endif

    //////////////////////// WATER DISTORTION /////////////////////
    float waterStrength = 0.0;      // seberapa kuat efek air saat ini (0..1)
    float splash = 0.0;             // burst saat masuk air
    float wetFade = 0.0;            // fade halus saat keluar air
    float dropsHighlight = 0.0;
    vec2 waterWobble = vec2(0.0);
    #if defined WATER_ON_CAMERA_EFFECT
        vec2 asp = vec2(aspect, 1.0);
        splash = enterWater * enterWater * (3.0 - 2.0 * enterWater);
        wetFade = smoothstep(0.0, 0.3, exitWater);

        if (isCamInWater) {
            // di dalam air: distorsi halus + splash dramatis di awal masuk
            float nUnder = textureLod(noisetex, texcoord * asp * 0.3, 0).r;
            float under = nUnder * nUnder * 0.3;

            if (splash > 0.001) {
                float nSplash = textureLod(noisetex, (texcoord + vec2(0.0, (1.0 - splash) * 0.5)) * asp * vec2(0.9, 0.6), 0).r;
                float bubbles = smoothstep(0.4, 0.85, nSplash) * splash;
                float punch = splash * (0.14 + vignette * 0.3);        // zoom-punch, lebih kuat di tepi layar
                under = max(under, punch + bubbles * 0.3);

                vec2 w1 = textureLod(noisetex, texcoord * asp * 1.7 + vec2(0.0, frameTimeCounter * 0.35), 0).rg - 0.5;
                waterWobble = w1 * 0.05 * splash;
            }
            distortmask = max(distortmask, under);
            waterStrength = max(splash, 0.0);
        } else if (exitWater > 0.0005) {
            // keluar air: tetesan meluncur turun, mengecil & memudar pelan
            float ex = exitWater;
            float slide = (1.0 - ex) * 0.6;
            vec2 sc = vec2(0.5, 0.25 + ex * ex * 0.25) * asp;
            float n = textureLod(noisetex, (texcoord + vec2(0.0, slide)) * sc, 0).r;

            float thr = mix(1.0, 0.3, sqrt(ex));                      // makin sedikit tetesan seiring waktu
            float drops = smoothstep(thr, thr + 0.25, n) * wetFade;
            dropsHighlight = drops;

            // lapisan air tipis yang bergoyang di seluruh layar
            vec2 w2 = textureLod(noisetex, texcoord * asp * 1.3 + vec2(0.0, slide * 1.5), 0).rg - 0.5;
            waterWobble = w2 * 0.045 * ex * wetFade;

            distortmask = max(distortmask, drops * 0.42 + ex * wetFade * vignette * 0.12);
            waterStrength = wetFade * (0.3 + 0.7 * ex);
        }
    #endif

    //////////////////////// APPLY DISTORTION /////////////////////
    vec2 zoomUV = 0.5 + (texcoord - 0.5) * (1.0 - distortmask) + waterWobble;
    vec3 distortedColor = textureLod(colortex0, zoomUV, 0).rgb;

    #if defined WATER_ON_CAMERA_EFFECT
        if (waterStrength > 0.0005) {
            // chromatic aberration tipis biar kerasa lensa basah
            float ca = 0.1 * waterStrength;
            vec2 uvR = 0.5 + (texcoord - 0.5) * (1.0 - distortmask * (1.0 + ca)) + waterWobble;
            vec2 uvB = 0.5 + (texcoord - 0.5) * (1.0 - distortmask * (1.0 - ca)) + waterWobble;
            distortedColor.r = textureLod(colortex0, uvR, 0).r;
            distortedColor.b = textureLod(colortex0, uvB, 0).b;
        }
        if (waterStrength > 0.0005 || distortmask > 0.0005) color = distortedColor;

        // tint biru + busa putih di tepi saat splash masuk air
        color = mix(color, color * vec3(0.7, 0.92, 1.1) + vec3(0.02, 0.05, 0.07), splash * 0.55);
        color = mix(color, vec3(0.85, 0.95, 1.0), splash * vignette * vignette * 0.3);
        // kilau tetesan saat keluar air
        color += dropsHighlight * 0.04;
    #endif

    //////////////////////// COLOR EFFECTS /////////////////////
    #if defined LOW_HEALTH_EFFECT || defined DAMAGE_TAKEN_EFFECT
        vec3 distortedColorLuma = vec3(1.0, 0.0, 0.0) * dot(distortedColor, vec3(0.21, 0.72, 0.07));

        #ifdef LOW_HEALTH_EFFECT
            float colorLuma = dot(color, vec3(0.21, 0.72, 0.07));
            vec3 LumaRedEdges = mix(vec3(colorLuma), vec3(1.0, 0.3, 0.3) * distortedColorLuma.r, vignette);
            color = mix(color, LumaRedEdges, mix(vignette * threeHeart, oneHeart, oneHeart));
        #endif

        #ifdef DAMAGE_TAKEN_EFFECT
            color = mix(color, distortedColorLuma, vignette * sqrt(min(MinorDamageTaken, 1.0)));
            color = mix(color, distortedColorLuma, sqrt(CriticalDamageTaken));
        #endif

        if (isDead) color = distortedColorLuma * 0.35;
    #endif
}

#endif
