#ifndef END_CRYSTAL_VORTEX_GLSL
#define END_CRYSTAL_VORTEX_GLSL

// World-space End Crystal vortex, rewritten from scratch.
// Crystal positions come from endcrystal_sampler (filled by lib/util/endCrystalCapture.glsl).
// For each pixel the view ray runs from the camera to the scene surface. Every crystal near that ray
// is raymarched in world space, so the beams stay fixed when the camera moves or turns.

#if END_CRYSTAL_VORTEX == 1 && defined END

uniform isampler2D endcrystal_sampler;

const float VX_BALL_R = 3.5;   // radius of the bulb at the crystal's centre (max width ~7 blocks)
const float VX_CYL_R  = 2.2;   // radius of the column above it (~4.4 blocks)
const float VX_MAX_H  = 120.0; // hard limit on how far a column may rise

// Same clock as the capture side: ms, wrapped to an hour
int EndCrystalNowMs() {
    return int(mod(frameTimeCounter, 3600.0) * 1000.0);
}

// 0 while the crystal is visible or was seen recently, rising to 1 by END_CRYSTAL_FADE_END_MS.
// 1 also means "no crystal in this slot".
float EndCrystalSlotProgress(int k) {
    if (texelFetch(endcrystal_sampler, ivec2(k, 0), 0).r == 0) return 1.0;
    int age = EndCrystalNowMs() - texelFetch(endcrystal_sampler, ivec2(k, 4), 0).r;
    if (age < 0) age += 3600000;
    return clamp((float(age) - float(END_CRYSTAL_FADE_START_MS)) / float(END_CRYSTAL_FADE_END_MS - END_CRYSTAL_FADE_START_MS), 0.0, 1.0);
}

vec3 EndCrystalPosRel(int k) {
    ivec3 p = ivec3(
        texelFetch(endcrystal_sampler, ivec2(k, 1), 0).r,
        texelFetch(endcrystal_sampler, ivec2(k, 2), 0).r,
        texelFetch(endcrystal_sampler, ivec2(k, 3), 0).r
    );
    return vec3(p) * 0.1 - cameraPosition;
}

// Cross-section radius of the vortex at height h above the crystal centre
float VxWidth(float h) {
    if (h < 0.0) return sqrt(max(VX_BALL_R * VX_BALL_R - h * h, 0.0));
    return VX_CYL_R + (VX_BALL_R - VX_CYL_R) * exp(-0.35 * h);
}

// Colour and density of the vortex at a point relative to the crystal centre
vec4 VxSample(vec3 rel, float time, float cutoff) {
    float h = rel.y;
    if (h < -VX_BALL_R || h > VX_MAX_H) return vec4(0.0);
    float w = VxWidth(h);
    float r = length(rel.xz);
    if (w <= 0.0 || r > w) return vec4(0.0);

    float q     = r / w;                                  // 0 at the axis, 1 at the edge
    float above = smoothstep(-VX_BALL_R, VX_BALL_R, h);
    float fade  = exp(-max(h, 0.0) / (40.0 * END_CRYSTAL_BEAM_HEIGHT));

    // Fade from the top: everything above 'cutoff' is gone, with a soft edge
    float topMask = 1.0 - smoothstep(cutoff - 6.0, cutoff, h);

    float core = (1.0 - q * q) * above * fade * topMask;

    // Helix streaks: phase moves with time, so they climb the column
    float theta = atan(rel.z, rel.x);
    float phase = 2.0 * theta - 0.5 * h + 3.0 * time;
    float helix = pow(0.5 + 0.5 * sin(phase), 3.0) * smoothstep(0.35, 1.0, q) * above * fade * topMask;
    float noise = textureLod(noisetex, vec2(theta * 0.159 + 0.5, h * 0.02 - time * 0.05), 0.0).r;
    helix *= 0.5 + noise;

    const vec3 purple = vec3(0.55, 0.30, 1.00);
    const vec3 orange = vec3(1.00, 0.62, 0.22);
    vec3 col = purple * core * 0.6 + orange * helix * 1.4;
    return vec4(col, core + helix);
}

// March the view ray through one crystal's vortex, only over the part of the ray that is near it
void VxCrystal(inout vec3 acc, vec3 dir, float maxS, vec3 c, float time, float cutoff, float dither) {
    vec2  d2   = dir.xz;
    float d2sq = dot(d2, d2);
    if (d2sq < 1e-6) return;                        // looking straight along the axis

    float sStar  = dot(c.xz, d2) / d2sq;            // ray distance of closest approach in XZ
    vec2  closest = sStar * d2 - c.xz;
    float dist2  = dot(closest, closest);
    float R      = VX_BALL_R;
    if (dist2 > R * R) return;

    float halfLen = sqrt(R * R - dist2) / sqrt(d2sq);
    float s0 = max(0.0, sStar - halfLen);
    float s1 = min(maxS, sStar + halfLen);
    if (s1 <= s0) return;

    float y0 = dir.y * s0 - c.y;
    float y1 = dir.y * s1 - c.y;
    if (max(y0, y1) < -R || min(y0, y1) > cutoff) return;

    int   n  = int(clamp(ceil((s1 - s0) / 0.6), 1.0, 48.0));
    float ds = (s1 - s0) / float(n);
    for (int i = 0; i < n; i++) {
        float s = s0 + (float(i) + dither) * ds;
        vec4 smp = VxSample(dir * s - c, time, cutoff);
        acc += smp.rgb * ds;
    }
}

void doEndCrystalVortex(inout vec3 color, vec3 playerPos, float dither) {
    float maxS = length(playerPos);
    if (maxS < 1e-3) return;
    vec3  dir  = playerPos / maxS;
    float time = frameTimeCounter * 0.5;

    vec3 acc = vec3(0.0);
    for (int k = 0; k < END_CRYSTAL_SLOTS; k++) {
        float p = EndCrystalSlotProgress(k);
        if (p >= 1.0) continue;
        // Top edge sinks from the column's full height down to just under the bulb
        // Fade on destruction: the top edge sinks from the top down
        float sinking = mix(VX_MAX_H, -VX_BALL_R - 1.0, pow(p, 0.6));
        float cutoff = sinking;
        vec3 local = vec3(0.0);
        VxCrystal(local, dir, maxS, EndCrystalPosRel(k), time, cutoff, dither);
        acc += local;
    }
    color += acc * END_CRYSTAL_VORTEX_STRENGTH * 0.08;
}

#endif
#endif
