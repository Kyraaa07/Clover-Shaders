#define SHADOW_Z_MULT 0.2

const float smBias = 25.6 / SHADOW_DISTANCE;

vec3 getDistortedPos(vec3 pos) {
    float factor = mix(length(pos.xy), 1.0, smBias); 
    return vec3(pos.xy / factor, pos.z * SHADOW_Z_MULT);
}

vec2 getShadowScreenXY(vec2 pos) {
    float factor = mix(length(pos), 1.0, smBias); 
    return pos / factor * 0.5 + 0.5;
}

 vec3 getUndistortedPos(vec3 distortedPos) {
    float R = length(distortedPos.xy);      
    float r = smBias * R / (1.0 + R * (smBias - 1.0));

    distortedPos.xy *= mix(r, 1.0, smBias);
    distortedPos.z  *= 1.0 / SHADOW_Z_MULT;
    
    return distortedPos;
}