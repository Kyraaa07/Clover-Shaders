#ifndef PACKING_GLSL
#define PACKING_GLSL

#include "/lib/util/dither.glsl"

uint pack1_2x5b_6b(vec3 u) {
    uvec3 uPrime = uvec3(u * vec3(31.0, 63.0, 31.0) + dither_ign);
    return uPrime.x | (uPrime.y << 5u) | (uPrime.z << 11u);
} 

vec3 unpack1_2x5b_6b(uint data) {
    uvec3 uPrime = uvec3(data, data >> 5u, data >> 11u) & uvec3(31u, 63u, 31u);
    return vec3(uPrime) / vec3(31.0, 63.0, 31.0); 
}

uvec4 pack4_4x8b(vec4 u, vec4 v, vec4 w, vec4 q) {
    uvec4 uPrime = uvec4(u * 255.0 + dither_ign);
    uvec4 vPrime = uvec4(v * 255.0 + dither_ign);
    uvec4 wPrime = uvec4(w * 255.0 + dither_ign);
    uvec4 qPrime = uvec4(q * 255.0 + dither_ign);

    return uPrime | (vPrime << 8u) | (wPrime << 16u) | (qPrime << 24u);
}

void unpack4_4x8b(uvec4 data, out vec4 u, out vec4 v, out vec4 w, out vec4 q) {
    uvec4 uPrime =  data         & 255u;
    uvec4 vPrime = (data >> 8u ) & 255u;
    uvec4 wPrime = (data >> 16u) & 255u;
    uvec4 qPrime = (data >> 24u) & 255u;

    u = vec4(uPrime) / 255.0;
    v = vec4(vPrime) / 255.0;
    w = vec4(wPrime) / 255.0;
    q = vec4(qPrime) / 255.0;
}

void octaFold(inout vec2 octa) {
    vec2 octaSign = vec2(octa.x > 0.0 ? 1.0 : -1.0, 
                         octa.y > 0.0 ? 1.0 : -1.0);

    octa = (1.0 - abs(octa.yx)) * octaSign;
}

vec2 octaEncode(vec3 v) {
    vec2 octa = v.xy / (abs(v.x) + abs(v.y) + abs(v.z));

    if (v.z < 0.0) octaFold(octa);

    return octa * 0.5 + 0.5;
}

vec3 octaDecode(vec2 octa) {
    octa = octa * 2.0 - 1.0;

    float z = 1.0 - abs(octa.x) - abs(octa.y);
    if (z < 0.0) octaFold(octa);

    return normalize(vec3(octa, z));
}

#endif