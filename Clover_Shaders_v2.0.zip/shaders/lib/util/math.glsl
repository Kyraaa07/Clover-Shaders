const float tau         = 6.28318530718;
const float pi          = 3.14159265358;
const float goldenRatio = 1.61803398874;
const float goldenAngle = 2.39996322976;

float pow0_75(float x) { x = sqrt(x); return x * sqrt(x); }
float pow1_5(float x)  { return x * sqrt(x);              }
float pow2(float x)    { return x * x;                    }
float pow3(float x)    { return x * x * x;                }
float pow4(float x)    { x *= x; return x * x;            }
float pow5(float x)    { return pow4(x) * x;              }
float pow64(float x)   { return pow4(pow4(pow4(x)));      }
float pow256(float x)  { return pow4(pow4(pow4(pow4(x))));}

vec2 pow0_75(vec2 x)  { x = sqrt(x); return x * sqrt(x); }
vec2 pow1_5(vec2 x)   { return x * sqrt(x);              }
vec2 pow2(vec2 x)     { return x * x;                    }
vec2 pow3(vec2 x)     { return x * x * x;                }
vec2 pow4(vec2 x)     { x *= x; return x * x;            }
vec2 pow5(vec2 x)     { return pow4(x) * x;              }
vec2 pow64(vec2 x)    { return pow4(pow4(pow4(x)));      }
vec2 pow256(vec2 x)   { return pow4(pow4(pow4(pow4(x))));}

vec3 pow0_75(vec3 x)  { x = sqrt(x); return x * sqrt(x); }
vec3 pow1_5(vec3 x)   { return x * sqrt(x);              }
vec3 pow2(vec3 x)     { return x * x;                    }
vec3 pow3(vec3 x)     { return x * x * x;                }
vec3 pow4(vec3 x)     { x *= x; return x * x;            }
vec3 pow5(vec3 x)     { return pow4(x) * x;              }
vec3 pow64(vec3 x)    { return pow4(pow4(pow4(x)));      }
vec3 pow256(vec3 x)   { return pow4(pow4(pow4(pow4(x))));}

vec4 pow0_75(vec4 x)  { x = sqrt(x); return x * sqrt(x); }
vec4 pow1_5(vec4 x)   { return x * sqrt(x);              }
vec4 pow2(vec4 x)     { return x * x;                    }
vec4 pow3(vec4 x)     { return x * x * x;                }
vec4 pow4(vec4 x)     { x *= x; return x * x;            }
vec4 pow5(vec4 x)     { return pow4(x) * x;              }
vec4 pow64(vec4 x)    { return pow4(pow4(pow4(x)));      }
vec4 pow256(vec4 x)   { return pow4(pow4(pow4(pow4(x))));}

float clamp01(float x) { return clamp(x, 0.0, 1.0); }
vec2  clamp01(vec2 x)  { return clamp(x, 0.0, 1.0); }
vec3  clamp01(vec3 x)  { return clamp(x, 0.0, 1.0); }
vec4  clamp01(vec4 x)  { return clamp(x, 0.0, 1.0); }

float max0(float x) { return max(0.0, x);       }
vec2  max0(vec2 x)  { return max(vec2(0.0), x); }
vec3  max0(vec3 x)  { return max(vec3(0.0), x); }
vec4  max0(vec4 x)  { return max(vec4(0.0), x); }

float max1(float x) { return max(1.0, x);       }
vec2  max1(vec2 x)  { return max(vec2(1.0), x); }
vec3  max1(vec3 x)  { return max(vec3(1.0), x); }
vec4  max1(vec4 x)  { return max(vec4(1.0), x); }

float min0(float x) { return min(0.0, x);       }
vec2  min0(vec2 x)  { return min(vec2(0.0), x); }
vec3  min0(vec3 x)  { return min(vec3(0.0), x); }
vec4  min0(vec4 x)  { return min(vec4(0.0), x); }

float min1(float x) { return min(1.0, x);       }
vec2  min1(vec2 x)  { return min(vec2(1.0), x); }
vec3  min1(vec3 x)  { return min(vec3(1.0), x); }
vec4  min1(vec4 x)  { return min(vec4(1.0), x); }

float maxOf(vec2 values) { return max(values.x, values.y);                }
float maxOf(vec3 values) { return max(values.x, max(values.y, values.z)); }

float minOf(vec2 values) { return min(values.x, values.y);                }
float minOf(vec3 values) { return min(values.x, min(values.y, values.z)); }

float sqrtApprox(float x) { return x * (2.0 - x); }
vec3  sqrtApprox(vec3 x)  { return x * (2.0 - x); }

float lengthSquared(vec2 p) { return dot(p, p); }
float lengthSquared(vec3 p) { return dot(p, p); }

float linearStep(float e0, float e1, float x) { return clamp01((x - e0) / (e1 - e0)); }
vec3  linearStep(float e0, float e1, vec3 x)  { return clamp01((x - e0) / (e1 - e0)); }

float bellCurve(float val ,float coeff) {
    return coeff / (pow2(val) + coeff);
}

float customFunc(vec2 zeroPoints, vec2 maxPoint, float x) {
    float a = x < maxPoint.x ? (x - zeroPoints.x) / (maxPoint.x - zeroPoints.x) : 
                               (x - zeroPoints.y) / (maxPoint.x - zeroPoints.y);
    return maxPoint.y * a * (2.0 - a);
}

bool isOutOfBounds(vec2 p) {
    return p.x > 1.0 || p.y > 1.0 || p.x < 0.0 || p.y < 0.0;
}

// Fast Inverse Trig Functions
// https://seblagarde.wordpress.com/2014/12/01/inverse-trigonometric-functions-gpu-optimization-for-amd-gcn-architecture/#more-3316

const float C0 = 1.57018;
const float C1 = -0.201877;
const float C2 = 0.0464619;

float acosFast(float x) {
    float absX = abs(x);
	float res = ((C2 * absX + C1) * absX + C0) * sqrt(1.0 - absX);

	return x > 0 ? res : pi - res;
}

// Not specified in the article. Derived from acosFast using inverse trig identities
float atanFast(float x) {
    float Xm = inversesqrt(pow2(x) + 1.0);
	float res = ((C2 * Xm + C1) * Xm + C0) * sqrt(1.0 - Xm);

	return (Xm > 0 ? res : pi - res) * sign(x);
}

float asinFast(float x) {
    return 0.5 * pi - acosFast(x);
}