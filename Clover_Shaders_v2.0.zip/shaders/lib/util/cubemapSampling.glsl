// Format - ivec2(texOffset, faceSize) 
const ivec2 milkywayTex = ivec2(0, 200);
const ivec2 earthTex = ivec2(1200, 10);

vec3 sampleCubemap(vec3 viewDir, ivec2 cTexture) {
    vec3 nDir = viewDir / maxOf(abs(viewDir));

    vec3 normal = trunc(nDir * 1.00001); // trick to find cube normal
    vec3 absNormal = abs(normal);

    float signAdd = (normal.x + normal.y + normal.z) * 0.5 + 0.5;
    int faceIndex = int(2.0 * absNormal.y + 4.0 * absNormal.z + signAdd);

    vec2 faceUV = (absNormal.x * nDir.yz  + 
                   absNormal.y * nDir.xz  + 
                   absNormal.z * nDir.xy) * 0.5 + 0.5;

    ivec2 base  = ivec2(cTexture.y * faceIndex + cTexture.x, 0);
    ivec2 coord = ivec2(cTexture.y *  faceUV ) + base;

    return SRGBToLinear(texelFetch(colortex8, coord, 0).rgb);
}