const float[2] scales = float[](exp2(-TILE_INDEX), exp2(-TILE_INDEX - 1.0));

vec2 texSize = vec2(viewWidth, viewHeight) * 0.5;

float x = 1.0 / texSize.x;
float y = 1.0 / texSize.y;

vec2 cvec2(float t, float k, vec4 bounds) {
    return clamp(vec2(t, k), bounds.xy, bounds.zw);
}

vec2 tileToScreen(vec2 tilePos, int si, out vec4 bounds) {
    float offset = 1.0 - 2.0 * scales[si];

    vec2 start = vec2(offset, 0.0);
    vec2 delta = vec2(scales[si]);

    start = (floor(start * texSize)) / texSize;
    delta = (floor(delta * texSize)) / texSize;

    bounds = vec4(start, start + delta) + 0.5 * vec4(x, y, -x, -y);

    return start + delta * tilePos;
}