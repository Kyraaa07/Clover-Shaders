vec2 R2(int i) {
    const float g = 1.32471795724474602596;

    const float a1 = 1.0 / g;
    const float a2 = a1 * a1;

    return fract(0.5 + vec2(a1, a2) * i);
}