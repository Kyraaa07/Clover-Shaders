#ifndef DITHER_GLSL
#define DITHER_GLSL
// https://blog.demofox.org/2022/01/01/interleaved-gradient-noise-a-different-kind-of-low-discrepancy-sequence/

float interleavedGradientNoise(vec2 pos) {
	return fract(52.9829189 * fract(0.06711056 * pos.x + 0.00583715 * pos.y));
}

float interleavedGradientNoise(vec2 pos, int frame) {
	return interleavedGradientNoise(pos + 5.588238 * (frame & 63));
}

#ifdef FRAGMENT_SHADER
	float dither_ign = fract(52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y + 0.40764916503 * (frameCounter & 63)));
#endif

#endif