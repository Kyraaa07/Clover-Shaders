#ifndef PROGRAMIDS_GLSL
#define PROGRAMIDS_GLSL

#define GBUFFERS_ARMOR_GLINT_ID 0
#define GBUFFERS_HAND_WATER_ID 1
#define GBUFFERS_BEACONBEAM_ID 2
#define GBUFFERS_SPIDEREYES_ID 3
#define GBUFFERS_PARTICLES_ID 4
#define GBUFFERS_ENTITIES_ID 5
#define GBUFFERS_TEXTURED_ID 6
#define GBUFFERS_WEATHER_ID 7
#define GBUFFERS_TERRAIN_ID 8
#define GBUFFERS_CLOUDS_ID 9
#define GBUFFERS_BLOCK_ID 10
#define GBUFFERS_BASIC_ID 11
#define GBUFFERS_WATER_ID 12
#define GBUFFERS_HAND_ID 13
#define GBUFFERS_VOXY_ID 14
#define GBUFFERS_END_PORTAL_ID 15
#define GBUFFERS_NETHER_PORTAL_ID 16
#define GBUFFERS_END_CRYSTAL_ID 17

#define UNKNOWN_PROGRAM_ID 255

void storeProgramID(out float programID) {
    programID = 
    #ifdef GBUFFERS_ARMOR_GLINT 
        GBUFFERS_ARMOR_GLINT_ID
    #elif defined GBUFFERS_HAND_WATER
        GBUFFERS_HAND_WATER_ID
    #elif defined GBUFFERS_BEACONBEAM
        GBUFFERS_BEACONBEAM_ID
    #elif defined GBUFFERS_SPIDEREYES
        GBUFFERS_SPIDEREYES_ID
    #elif defined GBUFFERS_PARTICLES || defined GBUFFERS_PARTICLES_TRANSLUCENT
        GBUFFERS_PARTICLES_ID
    #elif defined GBUFFERS_ENTITIES || defined GBUFFERS_ENTITIES_TRANSLUCENT
        GBUFFERS_ENTITIES_ID
    #elif defined GBUFFERS_TEXTURED
        GBUFFERS_TEXTURED_ID
    #elif defined GBUFFERS_WEATHER
        GBUFFERS_WEATHER_ID
    #elif defined GBUFFERS_TERRAIN
        GBUFFERS_TERRAIN_ID
    #elif defined GBUFFERS_CLOUDS
        GBUFFERS_CLOUDS_ID
    #elif defined GBUFFERS_BLOCK || defined GBUFFERS_BLOCK_TRANSLUCENT
        GBUFFERS_BLOCK_ID
    #elif defined GBUFFERS_BASIC
        GBUFFERS_BASIC_ID
    #elif defined GBUFFERS_WATER
        GBUFFERS_WATER_ID
    #elif defined GBUFFERS_HAND
        GBUFFERS_HAND_ID
    #else
        UNKNOWN_PROGRAM_ID
    #endif
    / 255.0;
}

int getProgramIDAt(vec2 uv) {
    return int(textureLod(colortex4, uv, 0).r * 255.1);
}
#endif