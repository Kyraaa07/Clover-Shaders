
#ifndef SPACE_CONVERSION_GLSL
#define SPACE_CONVERSION_GLSL

#define upVec gbufferModelView[1].xyz
#define eastVec gbufferModelView[0].xyz
#define southVec gbufferModelView[2].xyz

#define row(mat, n) vec3(mat[0][n], mat[1][n], mat[2][n])

#define diag(mat)  vec3(mat[0][0], mat[1][1], mat[2][2])
#define diag2(mat) vec2(mat[0][0], mat[1][1])

vec3 playerToShadow(vec3 playerPos) {
    vec3 shadowPos = mat3(shadowModelView) * playerPos + shadowModelView[3].xyz;
    return diag(shadowProjection) * shadowPos + shadowProjection[3].xyz;
}

vec3 viewToPlayer(vec3 viewPos) {
    return mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
}

vec3 playerToView(vec3 playerPos) {
    return mat3(gbufferModelView) * playerPos + gbufferModelView[3].xyz;
}

vec3 screenToView(vec3 screenPos) {
    vec3 ndc = screenPos * 2.0 - 1.0;
    float w = gbufferProjectionInverse[2][3] * ndc.z + gbufferProjectionInverse[3][3];
    return vec3(ndc.xy * diag2(gbufferProjectionInverse), -1.0) / w;
}

vec3 viewToScreen(vec3 viewPos) {
    vec3 pos = diag(gbufferProjection) * viewPos;
    return vec3(pos.xy, pos.z + gbufferProjection[3][2]) / -viewPos.z * 0.5 + 0.5; 
}

vec3 viewToPrvScreen(vec3 viewPos) {
    vec4 pos = viewToPrvScreenMatrix * vec4(viewPos, 1.0);
    return pos.xyz / pos.w * 0.5 + 0.5;
}

vec2 viewToPrvScreenXY(vec3 viewPos) {
    vec3 pos = viewToPrvScreenMatrix[0].xyw * viewPos.x + 
               viewToPrvScreenMatrix[1].xyw * viewPos.y + 
               viewToPrvScreenMatrix[2].xyw * viewPos.z + 
               viewToPrvScreenMatrix[3].xyw; 
    return pos.xy / pos.z * 0.5 + 0.5;
}

vec2 viewToFace(vec3 viewPos, mat3 tbn) {
    return vec2(dot(viewPos, tbn[0]), dot(viewPos, tbn[1]));
}

void fixHandDepth(inout float depth) {
    depth = (depth - 0.5) / MC_HAND_DEPTH + 0.5;
}

#ifdef FRAGMENT_SHADER
    mat3 getTbnMatrix(vec3 vertexNormal, vec4 vertexTangent) {
        mat3 tbn;
        tbn[2] = gl_FrontFacing ? vertexNormal : -vertexNormal; // bye bye inverted normals
	    tbn[0] = vertexTangent.xyz;
	    tbn[1] = cross(tbn[0], tbn[2]) * sign(vertexTangent.w);
        return tbn;
    }
#endif

#endif