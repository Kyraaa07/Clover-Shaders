#ifndef VOGEL_DISC_SAMPLING
#define VOGEL_DISC_SAMPLING

vec2 vogelDisc(float index, float maxSteps, float dither) {
    float angle = dither * tau + index * goldenAngle;
    return vec2(cos(angle), sin(angle)) * sqrt((index + 0.5) / maxSteps);
}

#endif