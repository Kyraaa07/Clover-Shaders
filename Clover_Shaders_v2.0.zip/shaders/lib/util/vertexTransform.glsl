#ifdef VT_COMPATIBILITY_MODE
    #define applyVertexTransform gl_Position = ftransform
#else
    void applyVertexTransform() {
        vec3 viewPos = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;

        #if defined SHADOW || defined SHADOW_SOLID || defined SHADOW_CUTOUT
            gl_Position = vec4(diag(gl_ProjectionMatrix) * viewPos, 1.0);        
        #else
            gl_Position = vec4(diag(gl_ProjectionMatrix) * viewPos, -viewPos.z);
        #endif

        #if (defined GBUFFERS_HAND || defined GBUFFERS_HAND_WATER || defined GBUFFERS_ARMOR_GLINT) && MC_VERSION >= 260100
            gl_Position.xyz += gl_ProjectionMatrix[3].xyz;
        #else
            gl_Position.z += gl_ProjectionMatrix[3].z;
        #endif
    }
#endif