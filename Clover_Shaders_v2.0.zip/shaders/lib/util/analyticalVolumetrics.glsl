float integrateHeightVolume(float yOrigin, float yEnd, float wsdist, float alti, float scale) {
    float d0 = yEnd - alti;
    float d1 = yOrigin - alti;
    float d2 = yEnd - yOrigin;

    if (d2 == 0.0) d2 = 1e-6;

    return (atanFast(d0 / scale) - atanFast(d1 / scale)) * scale * wsdist / d2;
}