#ifndef END_CRYSTAL_CAPTURE_GLSL
#define END_CRYSTAL_CAPTURE_GLSL

// Writes crystal positions into endcrystal_img. Included only by gbuffers_entities (world1).
// The position comes from the crystal's own visible surface (depth buffer), so it is always where
// the crystal is drawn, regardless of how the entity transform is set up.
// Layout (width = END_CRYSTAL_SLOTS, height = 5):
//   row 0      occupied flag (0 = empty)
//   row 1..3   x, y, z stored as ints times 10
//   row 4      time (ms) when the crystal was last seen
//   row 5      time (ms) when the crystal was first registered (drives the grow-in)

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1

layout(r32i) uniform iimage2D endcrystal_img;

// Time in ms, wrapped to an hour so it fits an int; ages are measured modulo that wrap
int EndCrystalNowMs() {
    return int(mod(frameTimeCounter, 3600.0) * 1000.0);
}

int EndCrystalAgeMs(int lastSeen) {
    int age = EndCrystalNowMs() - lastSeen;
    if (age < 0) age += 3600000;
    return age;
}

bool CrystalSlotStale(int lastSeen) {
    return EndCrystalAgeMs(lastSeen) > END_CRYSTAL_STALE_MS;
}

void CaptureEndCrystal(vec3 posAbs) {
    ivec3 p = ivec3(floor(posAbs * 10.0 + 0.5));

    // 1) Update the slot already holding this crystal (matched by XZ within 2 blocks)
    int freeSlot = -1;
    for (int k = 0; k < END_CRYSTAL_SLOTS; k++) {
        int occupied = imageLoad(endcrystal_img, ivec2(k, 0)).r;
        int lastSeen = imageLoad(endcrystal_img, ivec2(k, 4)).r;
        bool live = occupied != 0 && !CrystalSlotStale(lastSeen);
        if (!live) {
            if (freeSlot < 0) freeSlot = k;
            continue;
        }
        vec2 stored = vec2(imageLoad(endcrystal_img, ivec2(k, 1)).r,
                           imageLoad(endcrystal_img, ivec2(k, 3)).r) * 0.1;
        vec2 d = stored - posAbs.xz;
        if (dot(d, d) < 4.0) {
            // Position stays fixed after registration (rewriting it per fragment caused jitter)
            imageStore(endcrystal_img, ivec2(k, 4), ivec4(EndCrystalNowMs()));
            return;
        }
    }
    if (freeSlot < 0) return;

    // 2) New crystal: claim a free slot atomically
    int oldFlag = imageLoad(endcrystal_img, ivec2(freeSlot, 0)).r;
    int prev = imageAtomicCompSwap(endcrystal_img, ivec2(freeSlot, 0), oldFlag, 1);
    if (prev != oldFlag) return;

    imageStore(endcrystal_img, ivec2(freeSlot, 1), ivec4(p.x));
    imageStore(endcrystal_img, ivec2(freeSlot, 2), ivec4(p.y));
    imageStore(endcrystal_img, ivec2(freeSlot, 3), ivec4(p.z));
    imageStore(endcrystal_img, ivec2(freeSlot, 4), ivec4(EndCrystalNowMs()));
    imageStore(endcrystal_img, ivec2(freeSlot, 5), ivec4(EndCrystalNowMs()));
}

#endif
#endif
