bool intersectsOOBB(vec3 origin, vec3 rayDir, vec3 center, vec3 halfSize, mat3 rot, out float t) {
    rayDir = rot * rayDir;
    origin = rot * (origin - center);

    vec3 t0 = (-halfSize - origin) / rayDir;
    vec3 t1 = ( halfSize - origin) / rayDir;

    float tEnter = maxOf(min(t0, t1));
    float tExit  = minOf(max(t0, t1));

    t = tEnter;

    return tExit > max0(tEnter);
}

void rayExitOOBB(vec3 origin, vec3 rayDir, vec3 center, vec3 halfSize, mat3 rot, out float tExit) {
    rayDir = rot * rayDir;
    origin = rot * (origin - center);

    vec3 t0 = (-halfSize - origin) / rayDir;
    vec3 t1 = ( halfSize - origin) / rayDir;

    tExit = minOf(max(t0, t1));
}