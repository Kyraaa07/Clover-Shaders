
#define RT_HIT_GEO 0
#define RT_HIT_ENV 1
#define RT_HIT_SKY 2

const int refinementSteps = 6;

int raytrace(out vec3 hitPos, vec3 screenPos, vec3 viewPos, vec3 rayDir, int stepcount) {
    if (rayDir.z > -viewPos.z) return RT_HIT_ENV;

    vec3 rayStep = viewToScreen(viewPos + rayDir) - screenPos;

    vec3 dists = (step(0.0, rayStep) - screenPos) / rayStep;
         dists.z += 0.75; // fixes ray misses
    rayStep *= minOf(dists) / stepcount;

    // Thanks to DrDestens
    float zThresh = max(3.0 *  abs(rayStep.z), 0.02 / pow2(viewPos.z)); 

    vec3 screenPosRT = screenPos + rayStep * dither_ign;

    float zDiff, zSamp;
    bool intersects = false;
    for (int i = 0; i < stepcount; i++) {
        #ifdef DEFERRED
            // colortex6 (1/4 res depth) is still last frame's during deferred, use the real depth buffer
            zSamp = textureLod(depthtex1, screenPosRT.xy, 0).r;
        #else
            zSamp = textureLod(colortex6, screenPosRT.xy, 0).r;
        #endif
        zDiff = screenPosRT.z - zSamp;

        if (zDiff > 0.0 && zDiff < zThresh) {
            intersects = true;
            break;
        } 

        screenPosRT += rayStep;
    }

    if (intersects) {
        rayStep *= 0.5;
        vec3 searchPos = screenPosRT;
                hitPos = screenPosRT;

        for (int i = 0; i < refinementSteps; i++) {
            float zSampS = textureLod(depthtex1, searchPos.xy, 0).r;
            float zDiffS = searchPos.z - zSampS;

            if (zDiffS > 0.0) {
                zSamp  = zSampS;
                hitPos = searchPos;
            }

            searchPos -= rayStep * sign(zDiffS);
            rayStep *= 0.5;
        }
        if (zSamp == 1.0) return RT_HIT_SKY;
        if (zSamp < 0.56) return RT_HIT_ENV;

        zDiff = hitPos.z - zSamp;
        if (zDiff > zThresh) return RT_HIT_ENV;

        if (zDiff > zThresh * 0.1) hitPos = screenPosRT;

        return RT_HIT_GEO;
    }

    return RT_HIT_ENV;
}
