vec3 getGbuffersScreenPos() {
  vec3 screenPos = vec3(gl_FragCoord.xy / view, gl_FragCoord.z);

  #if !defined GBUFFERS_ENTITIES && !defined GBUFFERS_ENTITIES_TRANSLUCENT
    screenPos.xy = taaJitter(screenPos.xy, -0.5);
  #endif

  #if defined GBUFFERS_HAND || defined GBUFFERS_HAND_WATER
	  fixHandDepth(screenPos.z);
  #endif
    
  return screenPos;
}