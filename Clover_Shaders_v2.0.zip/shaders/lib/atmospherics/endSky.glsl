#include "/lib/settings/colorMultsSettings.glsl"
#include "/lib/settings/atmosphereSettings.glsl"
#include "/lib/util/cubemapSampling.glsl"
#include "/lib/util/traceOOBB.glsl"
#include "/lib/util/R2.glsl"

// -- Hardcoded default rotation matrix 
const mat3 standardRotation = mat3( 0.85030064529, 0.21711740038, 0.479425538604,
                                   -0.35463719283, 0.90944625784, 0.217117400380,
                                   -0.38887179644,-0.35463719283, 0.850300645290);

float getCelestialGlare(vec3 bodyDir, vec3 worldDir) {
    float VdotL = dot(worldDir, bodyDir);
    return max0(0.0003 * VdotL / (1.0 - 0.9997 * VdotL));
}

void drawSun(inout vec3 color, vec3 worldDir) {
    // <-- Spatial Properties -->
    const float scalingFactor = 1.7819;

    const mat3 sunRot = standardRotation;

    const float sunDist = 149597870.7;
    const float sunRadius = 695700.0 * scalingFactor;

    vec3 sunCenter = sunDist * pSunVec; 

    // <-- Colors --> 
    const vec3 endSunColor = vec3(16.0, 9.6, 9.6);

    color += 0.002 * endSunColor * getCelestialGlare(pSunVec, worldDir);
    
    float t;
    if (intersectsOOBB(vec3(0.0), worldDir, sunCenter, vec3(sunRadius), sunRot, t)) 
        color = endSunColor;
}

void drawEarth(inout vec3 color, vec3 worldDir) {
    // <-- Spatial Properties -->
    const float scalingFactor = 3.3333;

    const mat3 earthRot = standardRotation;
    const vec3 earthDir = normalize(vec3(1.0, 0.5, 0.4));
   
    const float earthDist = 384400.0;
    const float earthRadius = 6371.0 * scalingFactor;
    
    const vec3 earthCenter = earthDist * earthDir;

    // <-- Colors --> 
    const vec3 earthGlareColor = vec3(0.06, 0.08, 0.1);

    color += earthGlareColor * getCelestialGlare(earthDir, worldDir);

    float t;
    if (intersectsOOBB(vec3(0.0), worldDir, earthCenter, vec3(earthRadius), earthRot, t)) {
        vec3 hitPos = t * worldDir;

        float tExit;
        rayExitOOBB(hitPos, pSunVec, earthCenter, vec3(earthRadius), earthRot, tExit);

        float light = exp2(-0.0003 * tExit) * 0.98 + 0.02;

        vec3 localDelta = earthRot * (hitPos - earthCenter);

        color = sampleCubemap(localDelta, earthTex) * light;
    }
}


void drawComet(inout vec3 color, vec3 worldDir, vec3 cometCenter, mat3 cometRot) {
    // <-- Spatial Properties -->
    const float cometRadius = 1.0;
   
    const float tailHalfLength = cometRadius * 20.0;
    const vec3 tailHalfSize = vec3(cometRadius, cometRadius, tailHalfLength);
    
    // <-- Colors --> 
    const vec3 tailColor = vec3(0.2, 0.4, 0.6);

    float t;
    if(intersectsOOBB(vec3(0.0), worldDir, cometCenter, vec3(cometRadius), cometRot, t)) {
        vec3 hitPos = t * worldDir;

        float tExit;
        rayExitOOBB(hitPos, pSunVec, cometCenter, vec3(cometRadius), cometRot, tExit);

        float light = exp2(-tExit) * 0.98 + 0.02;
        
        color = vec3(0.3) * light;
    }

    vec3 tailCenter = cometCenter + row(cometRot, 2) * (cometRadius - tailHalfLength);

    if(intersectsOOBB(vec3(0.0), worldDir, tailCenter, tailHalfSize, cometRot, t)) {
        vec3 delta = cometCenter - t * worldDir;

        float dist = dot(row(cometRot, 2), delta); 
        float f = exp2(-0.2 * (dist + cometRadius));
        
        color += tailColor * f / (20.0 - 19.8 * f);
    }
}

void drawComets(inout vec3 color, vec3 worldDir) {
    const float timeSpan = 15.0;
    const float cometAlti = 110.0;
    const float cometSpeed = 30.7;

    const vec3 cometDir = normalize(vec3(-0.1, -0.1, 1.0));

    const vec3 tangent = normalize(cross(cometDir, vec3(0.1, 0.9, 0.0)));
    const mat3 cometRot = transpose(mat3(tangent, cross(tangent, cometDir), cometDir));

    float localTime = mod(frameTimeCounter, timeSpan);
    float normTime = localTime / timeSpan;

    int timeId = int(frameTimeCounter / timeSpan);

    vec3 offset = vec3(0.0, cometAlti, 0.0) + localTime * cometSpeed * cometDir;

    vec3 cometColor = color;
    for (int i = 0; i < 3; i++) {
        int cometId = 3 * timeId + i;
        
        vec2 rand = R2(cometId) * vec2(500.0, 300.0) - 250.0;
        vec3 base = vec3(rand.x, 0.0, rand.y);

        drawComet(cometColor, worldDir, base + offset, cometRot);
    }

    color = mix(cometColor, color, pow2(2.0 * normTime - 1.0));
}

// ---------------- Black hole ----------------
#if END_BLACK_HOLE == 1
const vec3 bhDir = normalize(vec3(-0.62, 0.30, -0.72));
const vec3 bhX   = normalize(cross(vec3(0.0, 1.0, 0.0), bhDir));
const vec3 bhY   = cross(bhDir, bhX);

const float bhRadius   = 0.040 * END_BLACK_HOLE_SIZE; // angular radius of the event horizon (radians)
const float bhEinstein = 2.0;                         // lensing radius, in horizon radii
const float bhDiskTilt = 0.26;                        // disk inclination: 1 = face-on, 0 = edge-on
const float bhRoll     = -0.32;                       // disk roll (radians)

// Position relative to the hole, in units of the horizon radius
vec2 bhLocal(vec3 d) {
    float c = dot(d, bhDir);
    return vec2(dot(d, bhX), dot(d, bhY)) / (max(c, 1e-3) * bhRadius);
}

// Gravitational lensing: where the background (stars / nebula) is actually sampled from
vec3 bhLensDir(vec3 d) {
    if (dot(d, bhDir) < 0.8) return d;

    vec2 p = bhLocal(d);
    float r2 = max(dot(p, p), 0.05);

    vec2 pSrc = p * (1.0 - bhEinstein * bhEinstein / r2);
    float w = smoothstep(9.0, 5.0, sqrt(r2)); // fade the effect out far from the hole

    vec2 pFinal = mix(p, pSrc, w);

    return normalize(bhDir + (bhX * pFinal.x + bhY * pFinal.y) * bhRadius);
}

void drawBlackHole(inout vec3 color, vec3 d) {
    if (dot(d, bhDir) < 0.8) return;

    vec2 p = bhLocal(d);
    float r = length(p);
    if (r > 8.0) return;

    // Disk: tilted & rolled ellipse
    float cr = cos(bhRoll), sr = sin(bhRoll);
    vec2 pr = vec2(cr * p.x - sr * p.y, sr * p.x + cr * p.y);
    vec2 q  = vec2(pr.x, pr.y / bhDiskTilt);
    float rq = length(q);

    float t = clamp((rq - 1.5) / 4.0, 0.0, 1.0);
    float diskMask = smoothstep(1.4, 1.75, rq) * smoothstep(5.8, 4.4, rq);

    // Hot inner edge -> magenta -> deep violet
    vec3 hot  = vec3(0.92, 0.55, 1.00);
    vec3 mid  = vec3(0.85, 0.25, 1.00);
    vec3 cold = vec3(0.30, 0.05, 0.65);
    vec3 diskCol = mix(mix(hot, mid, smoothstep(0.0, 0.35, t)), cold, smoothstep(0.35, 1.0, t));

    float ang = atan(q.y, q.x);
    float swirl = 0.7 + 0.3 * sin(ang * 7.0 - rq * 6.0 + frameTimeCounter * 1.5)
                      * sin(ang * 3.0 + rq * 2.5 - frameTimeCounter * 0.7);
    float doppler = mix(0.35, 1.8, 0.5 + 0.5 * q.x / max(rq, 1e-3)); // approaching side is brighter

    vec3 disk = diskCol * pow(1.0 - t, 2.2) * 5.0 * swirl * doppler * diskMask * END_BLACK_HOLE_LIGHT;

    // Lensed image of the far side of the disk bending over the hole + photon ring
    float upper = 0.35 + 0.65 * smoothstep(-0.3, 0.8, pr.y / max(r, 1e-3));
    float halo = exp(-pow2((r - 1.38) / 0.38)) * upper;
    float photonRing = exp(-pow2((r - 1.06) / 0.07));

    vec3 lensed = (mix(mid, hot, 0.5) * 2.4 * halo + hot * 5.0 * photonRing) * END_BLACK_HOLE_LIGHT;

    // Soft purple glow around the whole thing
    vec3 glow = vec3(0.45, 0.10, 0.85) * 0.12 * END_BLACK_HOLE_LIGHT / (1.0 + 0.5 * r * r)
              * (1.0 - smoothstep(2.0, 8.0, r)); // soft falloff, no visible edge

    // Compose: the horizon blocks everything behind it, the front half of the disk passes in front of it
    bool frontHalf = q.y < 0.0;

    float horizon = smoothstep(0.96, 1.0, r);

    vec3 backAdd  = (glow + lensed + (frontHalf ? vec3(0.0) : disk)) * horizon;
    vec3 frontAdd = frontHalf ? disk : vec3(0.0);

    color = color * horizon + (backAdd + frontAdd) * END_BLACK_HOLE_BRIGHTNESS;
}
#endif

vec3 getEndSky(vec3 worldDir) {
    #if END_BLACK_HOLE == 1
        vec3 bgDir = bhLensDir(worldDir);
    #else
        vec3 bgDir = worldDir;
    #endif

    // Purple tinted milky way + a soft violet haze towards the horizon
    const vec3 purpleTint = vec3(1.25, 0.55, 1.55);
    vec3 color = sampleCubemap(bgDir, milkywayTex) * purpleTint * END_SKY_MULT;

    float haze = pow(1.0 - abs(worldDir.y), 2.5);
    color += vec3(0.030, 0.006, 0.055) * haze * END_SKY_MULT;

    #ifdef END
        drawSun(color, worldDir);
    #endif
    drawEarth(color, worldDir);
    drawComets(color, worldDir);

    #if END_BLACK_HOLE == 1
        drawBlackHole(color, worldDir);
    #endif
    
    return color;
}