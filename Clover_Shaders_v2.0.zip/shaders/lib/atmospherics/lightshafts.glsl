#include "/lib/util/packing.glsl"
#include "/lib/colors/lightingColors.glsl"
#include "/lib/lighting/phaseFunctions.glsl"

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"

vec3 getShadowSample(vec3 shadowScreen) {
    if (isOutOfBounds(shadowScreen.xy)) return vec3(1.0);

    uvec3 data = texelFetch(colortex1, ivec2(shadowScreen * 1024.0), 0).rgb;

    uint compare = uint(shadowScreen.z * 65535.0);

    if (data.r > compare) return vec3(1.0);
    if (data.g < compare) return vec3(0.0);

    return shadowColorRange * unpack1_2x5b_6b(data.b);
}

void DoLightshafts(inout vec3 color, vec3 rayDir, float wsdist) {
    const int samplecount = 8;

    // vl strength is computed first so we can exit early
    float vlStrength = pow3(min1(20.0 * abs(pSunVec.y)));

    if (!isCamInWater) {
        float caveFactor   = 0.5 - 0.5 * skylightFactor;
        float sunsetFactor = pow2(invNoonFactor - nightFactor);

        vlStrength *= max(caveFactor, min1(1.0 - rayDir.y) * sunsetFactor);
    }

    if (vlStrength < 0.02) return;
    vlStrength *= linearStep(0.02, 0.04, vlStrength);

    wsdist = min(wsdist, far);
    if (isCamInWater) wsdist = min(min(96.0, float(SHADOW_DISTANCE)), wsdist);

    vec3 shadowDir = diag(shadowProjection) * (mat3(shadowModelView) * rayDir);
    vec3 shadowCam = diag(shadowProjection) * shadowModelView[3].xyz + shadowProjection[3].xyz;

    float stepLength = wsdist / samplecount;

    vec3 rayStep = shadowDir * stepLength;

    vec3 rtPos = shadowCam + rayStep * dither_ign;

    // Clover's Atmosphere is composed of some very special substance..
    vec3 scCoeff = isCamInWater ? vec3(1.5, 5.0, 8.0) * 1e-2 : vec3(5.6, 6.0, 8.0) * 1e-3;
    float g = isCamInWater ? 0.3 : 0.6;

    float VdotL = dot(rayDir, pSunVec) * sign(pSunVec.y);
    float phase = henyeyGreenstein(VdotL, g);

    vec3 stepTransmit = exp(-scCoeff * stepLength);
    vec3 stepScatter  = (phase * stepLength * vlStrength) * scCoeff * lightColor;

    vec3 transmit = vec3(1.0);
    vec3 scatter  = vec3(0.0);
    
    for (int i = 0; i < samplecount; i++) {
        vec3 dstPos = getDistortedPos(rtPos);
        vec3 shadow = getShadowSample(dstPos * 0.5 + 0.5);
        
        scatter  += transmit * shadow;
        transmit *= stepTransmit;

        rtPos += rayStep;
    }
    scatter *= stepScatter;

    color += scatter;
}