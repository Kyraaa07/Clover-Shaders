#ifndef SKY_GLSL
#define SKY_GLSL

#include "/lib/settings/atmosphereSettings.glsl"
#include "/lib/colors/skyColors.glsl"

vec3 getSky(float VdotU, float VdotS) {
    vec3 sky = VdotU > 0.0 ? topSkyColor : bottomSkyColor;

    float horizonFactor  = bellCurve(abs(VdotU), 0.075);
    float dawnScattering = bellCurve(abs(VdotU), 0.025) * bellCurve(1.0 - VdotS, 0.08) 
                                                        * pow4(1.0 - min1(abs(pSunVec.y - 0.15)));
    sky = mix(sky, middleSkyColor, horizonFactor);
    sky = mix(sky, dawnScattColor, dawnScattering * 0.2);

    float sunAppearance  = linearStep(-0.05, 0.2,  pSunVec.y);
    float moonAppearance = linearStep( 0.05, 0.1, -pSunVec.y);

    float glareFactor = (0.075 / (1.0 - 0.925 * pow2(VdotS)) - 0.075) * min1(2.0 * abs(VdotS));
    if (VdotS > 0.0) {            
        sky += glareFactor * sunAppearance * sunGlareColor;
    } else {
        sky += glareFactor * moonAppearance * moonGlareColor;
    }

    return sky + (dither_ign - 0.5) / 127.5;
}

#endif