#include "/lib/colors/altSkyColors.glsl"
#include "/lib/lighting/phaseFunctions.glsl"

vec4 getSmokeSample(vec3 p, float dist) {
    #ifdef GBUFFERS_TRANSLUCENT
        float noise = 0.454;
    #else
        float ang = dot(p, vec3(0.25)) - 2.0 * frameTimeCounter;
        vec2 wrap = vec2(cos(ang), sin(ang));

        vec2 wCoord = 0.025 * (p.xz + wrap);
        float noise = textureLod(colortex5, wCoord, 0).r; 
    #endif

    float planeFactor = pow2(p.y - 32.0);
   
    float distFade  = min1(dist * 0.04);
    float altiFade  = 1.0 + 0.001 * planeFactor;
    float altiFade2 = 1.0 + 0.05  * planeFactor;

    vec3 lavaLightColor = netherLavaGlow;

    float density = noise * distFade / min(3.0, altiFade);     
    vec3 radiance = altSkyColor + lavaLightColor / altiFade2;

    return vec4(radiance, density);
}

void DoNetherSmoke(inout vec3 color, vec3 rayDir, float wsdist) {
    const int samplecount = 4;

    const float scCoeff = 0.025;
    const float vlStrength = 20.0;

    wsdist = min(wsdist, far);
    
    float stepLength = wsdist / samplecount;
    
    vec3 rayStep = rayDir * stepLength;

    vec3 rtPos = cameraPosition + rayStep * dither_ign;
    float dist = stepLength * dither_ign;

    float transmit = 1.0;
    vec3 scatter = vec3(0.0);
    
    for (int i = 0; i < samplecount; i++) {
        vec4 ss = getSmokeSample(rtPos, dist);

        float stepTransmit = exp(-scCoeff * stepLength * ss.a);
       
        scatter  += (1.0 - stepTransmit) * transmit * ss.rgb;
        transmit *= stepTransmit;

        rtPos += rayStep;
        dist  += stepLength;
    }
    scatter *= isotropicPhase * vlStrength;

    color = color * transmit + scatter;
}