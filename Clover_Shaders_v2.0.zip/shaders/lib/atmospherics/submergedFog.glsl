#include "/lib/settings/natureSettings.glsl"

const vec3 waterFogColor = WATER_FOG_COLOR; 
const vec3 lavaFogColor = vec3(4.0, 0.5, 0.1);
const vec3 snowFogColor = vec3(0.25, 0.4, 0.6);

// ---- Lava view ----
// Animated molten surface seen from inside the lava: moving noise bands, dark crust,
// and bright flowing streaks. Two noise layers drift in different directions.
vec3 GetLavaView(vec3 sceneColor) {
    vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    float t = frameTimeCounter;

    // Wobble the coordinates so the lava looks like it is flowing
    vec2 warp = vec2(
        textureLod(noisetex, uv * 1.2 + vec2(t * 0.015, 0.0), 0).r,
        textureLod(noisetex, uv * 1.2 + vec2(0.0, t * 0.012) + 0.37, 0).r
    ) - 0.5;
    vec2 q = uv + warp * 0.35;

    float n1 = textureLod(noisetex, q * 2.2 + vec2(t * 0.025, -t * 0.018), 0).r;
    float n2 = textureLod(noisetex, q * 4.5 - vec2(t * 0.040, t * 0.030), 0).r;
    float n  = clamp01(0.6 * n1 + 0.4 * n2);

    vec3 crust  = vec3(0.20, 0.02, 0.00);  // cooled dark rock
    vec3 molten = vec3(1.00, 0.30, 0.02);  // hot orange
    vec3 hot    = vec3(1.00, 0.85, 0.35);  // bright yellow streaks

    vec3 lava = mix(crust, molten, smoothstep(0.25, 0.60, n));
    lava = mix(lava, hot, smoothstep(0.72, 0.92, n) * (0.6 + 0.4 * n2));

    // Keep a faint hint of the scene underneath, the rest is pure lava
    return lava * 1.1 + sceneColor * 0.08;
}

void DoSubmergedFog(inout vec3 color, float wsdist) {
    // Water
    if (isCamInWater) {
        float bordFog = 1.0 - min1(1.1 * wsdist / far);
        float expoFog = exp2(-0.0008 * wsdist); // almost clear, the sea tint only shows far away

        // Sea colour is a bit brighter by day, darker at night
        vec3 seaColor = waterFogColor * mix(0.35, 1.0, 1.0 - nightFactor);

        color = mix(seaColor, color, bordFog * expoFog);
    } 
    
    // Lava
    else if (isCamInLava) {
        color = GetLavaView(color);
    } 

    // Powdered Snow
    else if (isCamInSnow) {
        float fog = pow2(max0(1.0 - 0.2 * wsdist));

        color = mix(snowFogColor, color, fog);
    }
}