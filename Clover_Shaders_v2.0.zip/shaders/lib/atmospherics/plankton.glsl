#ifndef PLANKTON_GLSL
#define PLANKTON_GLSL

#include "/lib/settings/effectsSettings.glsl"
#include "/lib/util/packing.glsl"

// Bioluminescent plankton inside water. Drawn like the Beauty Night fireflies: small glowing
// points (bright core plus soft halo) in a box around the camera, blinking on their own phase.
// They sink slowly, fade in at the top of the box and fade out toward the bottom.
// How many show up depends on how dark the spot is, like hostile mob spawning:
// dark places and night get many, lit places (torches, daylight) get only a few.

const vec3  plkLo  = vec3(-20.0, -12.0, -20.0);
const vec3  plkBox = vec3( 40.0,  12.0,  40.0);
const int   PLANKTON_MAX = 48;

vec3 plk_hash3(float n) {
    vec3 p = fract(vec3(n) * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

vec3 planktonColor() {
    #if PLANKTON_COLOR == 1
        return vec3(0.35, 1.00, 0.45);  // green
    #elif PLANKTON_COLOR == 2
        return vec3(0.25, 0.45, 1.00);  // blue
    #else
        return vec3(0.20, 0.95, 1.00);  // cyan
    #endif
}

// Block light of the pixel currently being shaded (stored in the material buffer)
float plk_pixelBlockLight() {
    uvec4 materialData = texelFetch(colortex3, ivec2(gl_FragCoord.xy), 0);
    vec4 b1, b2, b3, b4;
    unpack4_4x8b(materialData, b1, b2, b3, b4);
    return b4.r;
}

void plk_get(int i, out vec3 rel, out float intensity, out float fade) {
    vec3 h = plk_hash3(float(i) + 7.0);
    float t = frameTimeCounter;

    // Gentle side-to-side drift
    vec3 wander = vec3(
        sin(t * 0.30 + h.x * 6.283) * 1.2,
        0.0,
        cos(t * 0.25 + h.z * 6.283) * 1.2
    );

    // Sinking: y moves down over time in world space
    float sink = t * 0.35;

    // Points live in world space (they do not follow the camera). Only the repeating
    // window around the camera is drawn, so they stay put when you swim up or down.
    vec3 pw = h * plkBox + wander;
    pw.y = h.y * plkBox.y - sink;
    rel = pw - cameraPosition;
    rel.xz = mod(rel.xz - plkLo.xz, plkBox.xz) + plkLo.xz;
    rel.y  = mod(rel.y - plkLo.y, plkBox.y) + plkLo.y;

    // Height inside the box: 0 = bottom, 1 = top
    float f = (rel.y - plkLo.y) / plkBox.y;
    fade = smoothstep(0.0, 0.30, f) * smoothstep(1.0, 0.82, f);

    float blink = 0.5 + 0.5 * sin(t * (1.2 + h.x * 1.5) + h.z * 6.283);
    blink = smoothstep(0.35, 1.0, blink);
    intensity = 0.30 + 0.70 * blink;
}

void DoPlankton(inout vec3 color, vec3 playerPos, bool isWaterPixel) {
    vec3 worldPos = playerPos + cameraPosition;
    float camMove = length(cameraPosition - previousCameraPosition);
    float reactive = PLANKTON_REACTIVE == 1 ? clamp(camMove * 4.0, 0.0, 1.0) : 0.0;

    #if PLANKTON_SURFACE_GLOW == 1
        // Faint shimmer on the water surface seen from above at night
        if (isWaterPixel && !isCamInWater) {
            // Smooth diagonal ripple (a product of two sines made a blocky checker pattern)
            float shimmer = 0.5 + 0.5 * sin(dot(worldPos.xz, vec2(0.6, 0.8)) * 1.1 + frameTimeCounter * 1.5);
            color += planktonColor() * shimmer * 0.012 * PLANKTON_BRIGHTNESS * nightFactor;
        }
    #endif

    if (!isCamInWater) return;

    // Darkness of this spot: block light lights it up, and daylight lights it a bit too
    float blockLight = plk_pixelBlockLight();
    float daylight   = 1.0 - nightFactor;
    float lit        = max(smoothstep(0.05, 0.6, blockLight), daylight * 0.6);
    float darkness   = 1.0 - lit;

    // Share of plankton that exist at this spot. Dark and night = many, lit = few
    float visible = clamp(PLANKTON_DENSITY * 0.5, 0.0, 1.0) * mix(0.08, 1.0, darkness);

    float dayFade = PLANKTON_NIGHT_ONLY == 1 ? mix(0.35, 1.0, nightFactor) : 1.0;
    float strength = PLANKTON_BRIGHTNESS * dayFade * 0.6;

    vec3 rayDir     = normalize(playerPos);
    float sceneDist = length(playerPos);
    vec3 col = planktonColor();
    vec3 glow = vec3(0.0);

    for (int i = 0; i < PLANKTON_MAX; i++) {
        // Each plankton point is either present or not, decided by its own hash
        if (plk_hash3(float(i) + 3.0).x > visible) continue;

        vec3 rel; float intensity, fade;
        plk_get(i, rel, intensity, fade);

        float w = intensity * fade * mix(1.0, 1.8, reactive);

        float tt = dot(rel, rayDir);
        if (tt > 0.1 && tt < sceneDist) {
            vec3 closest = rayDir * tt - rel;
            float d2 = dot(closest, closest);

            float r  = 0.03 + 0.003 * tt;
            float r2 = r * r;

            float core = exp(-d2 / r2);
            float halo = exp(-d2 / (r2 * 30.0));

            glow += col * (core * 1.0 + halo * 0.12) * w;
        }
    }

    color += glow * strength;
}

#endif
