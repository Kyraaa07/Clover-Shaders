#ifndef PORTAL_SHOOTING_STARS_GLSL
#define PORTAL_SHOOTING_STARS_GLSL

// Shooting stars seen through the End Portal. Streaks are spawned around the direction the player is
// looking, so there is always a chance to see one inside the portal opening.

vec3 ps_hash3(float n) {
    vec3 p = fract(vec3(n) * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

vec3 psShootingStars(vec3 worldDir, vec3 forward) {
    vec3 result = vec3(0.0);

    for (int layer = 0; layer < 3; layer++) {
        float period = 1.6 + 0.9 * float(layer);
        float tm = frameTimeCounter / period + 0.37 * float(layer);

        float slot   = floor(tm);
        float localT = fract(tm);

        const float activeFrac = 0.45;
        if (localT > activeFrac) continue;
        float u = localT / activeFrac;

        vec3 h  = ps_hash3(slot * 3.0 + float(layer) * 17.0 + 1.0);
        vec3 h2 = ps_hash3(slot * 5.0 + float(layer) * 31.0 + 2.0);

        // Start direction: somewhere around the view direction
        vec3 ref = abs(forward.y) < 0.95 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        vec3 fx = normalize(cross(forward, ref));
        vec3 fy = cross(forward, fx);
        vec3 s = normalize(forward + fx * (h.x * 2.0 - 1.0) * 0.8 + fy * (h.y * 2.0 - 1.0) * 0.6);

        // Streak frame around the start direction
        float ang = h2.x * 6.2832;
        vec3 sx = normalize(cross(s, ref));
        vec3 sy = cross(s, sx);
        vec3 tx = sx * cos(ang) + sy * sin(ang);
        vec3 ty = cross(s, tx);

        float c = dot(worldDir, s);
        if (c < 0.5) continue;

        vec2 p = vec2(dot(worldDir, tx), dot(worldDir, ty)) / c;

        float tailLen = 0.10 + 0.08 * h2.y;
        float head    = -0.30 + u * 0.60;
        float along   = (p.x - (head - tailLen)) / tailLen; // 0 = tail end, 1 = head

        if (along < 0.0 || along > 1.0) continue;

        float width = 0.0016 + 0.0016 * along;
        float body  = exp(-p.y * p.y / (width * width));
        float life  = smoothstep(0.0, 0.12, u) * smoothstep(1.0, 0.7, u);

        vec3 col = mix(vec3(0.55, 0.45, 1.00), vec3(0.90, 0.95, 1.00), along);
        result += col * body * pow(along, 2.0) * life * 3.0;
    }

    return result;
}

#endif
