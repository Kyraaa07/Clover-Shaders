void DoDarknessEffect(inout vec3 color, vec2 screenPosXY) {
    float effectFactor = max(blindness, darknessFactor);

    if (effectFactor > 1e-6) {
        vec3 screenPos1 = vec3(screenPosXY, textureLod(depthtex1, texcoord, 0).r);
        float wsdist1 = length(screenToView(screenPos1));

        color *= pow2(max0(1.0 - 0.1 * effectFactor * wsdist1));
    }
}