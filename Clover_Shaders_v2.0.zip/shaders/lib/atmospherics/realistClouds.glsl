// "Realist" volumetric clouds.
// Ported from BSL Shaders v10.1.3 (lib/atmospherics/clouds.glsl -> DrawCloudVolumetric, default Perlin base).
// Same entry point as the Complementary clouds (complementaryClouds.glsl) so deferred.glsl / translucent depth culling work unchanged.
// Noise texture (BSL noise.png, 512x512 RGBA) is bound to colortex2 in the deferred stage (see shaders.properties).

#include "/lib/colors/lightingColors.glsl"

// Match BSL's default look (scale 12 / thickness 5) while sharing Clover's Scale / Thickness sliders
const float rlCloudScale     = CLOUD_SCALE * 1.2;
const float rlCloudThickness = CLOUD_THICKNESS * 1.25;
const float rlCloudStretch   = 1.0;

// BSL light colours are ~half the magnitude of Clover's; this compensates (tune with Cloud Brightness)
const float rlExposure = 1.5;

float rlCloudSampleBase(vec2 coord) {
    return textureLod(colortex2, coord, 0.0).r;
}

float rlCloudSampleDetail(vec2 coord, float cloudGradient) {
    float detailZ    = floor(cloudGradient * rlCloudThickness) * 0.04;
    float detailFrac = fract(cloudGradient * rlCloudThickness);

    float noiseDetailLow  = textureLod(colortex2, coord + detailZ,        0.0).b;
    float noiseDetailHigh = textureLod(colortex2, coord + detailZ + 0.04, 0.0).b;

    return mix(noiseDetailLow, noiseDetailHigh, detailFrac);
}

float rlCloudCoverage(float cloudGradient) {
    float noiseCoverage = abs(cloudGradient - 0.125);

    noiseCoverage *= cloudGradient > 0.125 ? (2.14 - CLOUD_AMOUNT * 0.1) : 8.0;
    noiseCoverage = noiseCoverage * noiseCoverage * 4.0;

    return noiseCoverage;
}

float rlCloudApplyDensity(float noise) {
    noise *= CLOUD_DENSITY * 0.125;
    noise *= (1.0 - 0.75 * rainFactor);
    noise = noise / sqrt(noise * noise + 0.5);

    return noise;
}

float rlCloudSample(vec2 coord, vec2 wind, float cloudGradient, float sunCoverage) {
    coord *= 0.004 * rlCloudStretch;

    vec2 baseCoord   = coord * 0.25 + wind;
    vec2 detailCoord = coord * 0.5 - wind * 2.0;

    float noiseBase     = rlCloudSampleBase(baseCoord);
    float noiseDetail   = rlCloudSampleDetail(detailCoord, cloudGradient);
    float noiseCoverage = rlCloudCoverage(cloudGradient);

    float noise = mix(noiseBase, noiseDetail, 0.0476 * CLOUD_DETAIL) * 21.0;

    noise = mix(noise - noiseCoverage, 21.0 - noiseCoverage * 2.5, 0.33 * rainFactor);
    noise = max(noise - (sunCoverage * 3.0 + CLOUD_AMOUNT), 0.0);

    return rlCloudApplyDensity(noise);
}

float rlInvLerp(float v, float l, float h) {
    return clamp((v - l) / (h - l), 0.0, 1.0);
}

void DoClouds(inout vec3 color, vec3 rayOrigin, vec3 rayDir, float wsdist, inout float cloudDepth) {
    if (isEyeInWater > 1) return;

    bool isSky = wsdist > 1e20;
    float cloudMask = isSky ? 1.0 : 0.0; // terrain always occludes clouds

    float dither = dither_ign;

    vec3 nWorldPos = rayDir;
    if (abs(nWorldPos.y) < 1e-4) nWorldPos.y = nWorldPos.y < 0.0 ? -1e-4 : 1e-4;

    float viewLength = isSky ? 1e30 : wsdist;

    const int maxSamples = 32;

    float lowerY = float(CLOUD_HEIGHT);
    float upperY = lowerY + rlCloudThickness * rlCloudScale;

    float lowerPlane = (lowerY - rayOrigin.y) / nWorldPos.y;
    float upperPlane = (upperY - rayOrigin.y) / nWorldPos.y;

    float nearestPlane  = max(min(lowerPlane, upperPlane), 0.0);
    float furthestPlane = max(lowerPlane, upperPlane);

    if (furthestPlane < 0.0) return;

    // Perf: terrain closer than the cloud layer hides every cloud sample, so skip the whole raymarch
    if (!isSky && wsdist < nearestPlane) return;

    float cloudMaxDistance = max(480.0, 2.0 * far);
    float cloudViewLength = cloudMaxDistance;
    float maxCloudViewLength = cloudViewLength;

    float planeDifference = furthestPlane - nearestPlane;

    vec3 startPos = rayOrigin + nearestPlane * nWorldPos;

    float lengthScaling = abs(rayOrigin.y - (upperY + lowerY) * 0.5) / ((upperY - lowerY) * 0.5);
    lengthScaling = clamp((lengthScaling - 1.0) * rlCloudThickness * 0.125, 0.0, 1.0);

    float sampleLength = rlCloudThickness * rlCloudScale / 2.0;
    sampleLength /= (4.0 * nWorldPos.y * nWorldPos.y) * lengthScaling + 1.0;

    vec3 sampleStep = nWorldPos * sampleLength;
    int samples = int(min(planeDifference / sampleLength, float(maxSamples)) + 1.0);

    vec3 samplePos = startPos + sampleStep * dither;
    float sampleTotalLength = nearestPlane + sampleLength * dither;

    float time = frameTimeCounter;
    vec2 wind = vec2(
        time * CLOUD_SPEED * 0.0005,
        sin(time * CLOUD_SPEED * 0.001) * 0.005
    ) * 0.667;

    // -- Lighting inputs (BSL names, Clover sources) -- //
    vec3 pLightVec = pSunVec * sign(pSunVec.y);
    float shadowFade = min1(20.0 * pLightVec.y);
    float sunVisibility = clamp(pSunVec.y + 0.15, 0.0, 0.25) * 4.0;
    float sunSkyVisibility = sunVisibility * (1.0 - rainFactor * 0.5);
    float fogDensity = 1.0 + 0.5 * rainFactor;

    float VoU = nWorldPos.y;
    float VoL = dot(nWorldPos, pLightVec);

    // "Reveal": clouds thin out around the sun / moon
    float sunCoverage = mix(abs(VoL), max(VoL, 0.0), shadowFade);
    sunCoverage = pow(clamp(sunCoverage * 2.0 - 1.0, 0.0, 1.0), 12.0) * (1.0 - rainFactor);

    float halfVoL = mix(abs(VoL) * 0.8, VoL, shadowFade) * 0.5 + 0.5;
    float halfVoLSqr = halfVoL * halfVoL;
    float scattering = pow(halfVoL, 6.0);
    float noiseLightFactor = (2.0 - 1.5 * VoL * shadowFade) * CLOUD_DENSITY * 0.5;

    float viewLengthSoftMin = viewLength - sampleLength * 0.5;
    float viewLengthSoftMax = viewLength + sampleLength * 0.5;

    float cloud = 0.0;
    float cloudFaded = 0.0;
    float cloudLighting = 0.0;

    float distanceFade = 1.0;
    float fadeStart = 32.0 / max(fogDensity, 0.5);
    float fadeEnd = 240.0 / max(fogDensity, 0.5);

    float xzNormalizeFactor = 10.0 / max(abs(float(CLOUD_HEIGHT) - 72.0), 56.0);

    for (int i = 0; i < samples; i++) {
        if (cloud > 0.99) break;
        if (sampleTotalLength > viewLengthSoftMax && cloudMask == 0.0) break;

        float cloudGradient = rlInvLerp(samplePos.y, lowerY, upperY);
        float xzNormalizedDistance = length(samplePos.xz - rayOrigin.xz) * xzNormalizeFactor;
        vec2 cloudCoord = samplePos.xz / rlCloudScale;

        float noise = rlCloudSample(cloudCoord, wind, cloudGradient, sunCoverage);
        noise *= step(lowerY, samplePos.y) * step(samplePos.y, upperY);

        float sampleLighting = pow(cloudGradient, 1.125 * halfVoLSqr + 0.875) * 0.8 + 0.2;
        sampleLighting *= 1.0 - pow(noise, noiseLightFactor);

        float sampleFade = rlInvLerp(xzNormalizedDistance, fadeEnd, fadeStart);
        distanceFade *= mix(1.0, sampleFade, noise * (1.0 - cloud));
        noise *= step(xzNormalizedDistance, fadeEnd);

        cloudLighting = mix(cloudLighting, sampleLighting, noise * (1.0 - cloud * cloud));

        cloud = mix(cloud, 1.0, noise);

        if (!isSky) {
            float softFade = rlInvLerp(sampleTotalLength, viewLengthSoftMax, viewLengthSoftMin);
            noise *= softFade;
        }

        cloudFaded = mix(cloudFaded, 1.0, noise);

        if (cloudViewLength == maxCloudViewLength && cloud > 0.5) {
            cloudViewLength = sampleTotalLength;
        }

        samplePos += sampleStep;
        sampleTotalLength += sampleLength;
    }

    cloudFaded *= distanceFade;

    cloudLighting = mix(cloudLighting, 1.0, (1.0 - cloud * cloud) * scattering * 0.5);
    cloudLighting *= (1.0 - 0.9 * rainFactor);

    vec3 cloudAmbientCol = ambientColor * (0.3 * sunSkyVisibility + 0.5);
    vec3 cloudLightCol = lightColor * (0.85 + 1.15 * scattering);

    vec3 cloudColor = mix(cloudAmbientCol, cloudLightCol, cloudLighting);

    cloudColor *= 1.0 - 0.4 * rainFactor;
    cloudColor *= CLOUD_BRIGHTNESS * rlExposure * (0.5 - 0.25 * (1.0 - sunSkyVisibility) * (1.0 - rainFactor));

    cloudFaded *= cloudFaded * CLOUD_OPACITY;

    if (cloudFaded < dither) {
        cloudViewLength = maxCloudViewLength;
    }

    // Fade out when far below the world (BSL behaviour)
    float underFade = clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
    cloudColor *= underFade;
    cloudFaded *= underFade;

    cloudFaded = min1(cloudFaded);
    color = mix(color, cloudColor, cloudFaded);

    // Depth used to cull translucents behind the clouds (view-space z distance, same encoding as Complementary clouds)
    if (cloudViewLength < maxCloudViewLength) {
        float viewZScale = -(gbufferModelView * vec4(nWorldPos, 0.0)).z;
        float zDist = cloudViewLength * viewZScale;
        cloudDepth = min1(floor(zDist * 191.25 / far + dither_ign) / 255.0);
    }
}
