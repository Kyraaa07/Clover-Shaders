#ifdef OVERWORLD
    #include "/lib/atmospherics/sky.glsl"
    #include "/lib/util/analyticalVolumetrics.glsl"
#else
    #include "/lib/colors/altSkyColors.glsl"
#endif

// With Voxy the world is visible far beyond the vanilla far plane, so the border fog must
// use the LOD distance for EVERY pixel (vanilla terrain/water too), otherwise the vanilla edge
// gets fogged to sky color and shows up as pale halos over the LODs.
float borderFogDist = vxRenderDistance > 0 ? max(far, float(vxRenderDistance) * 16.0 - 256.0) : far;

void DoFog(inout vec3 color, vec3 playerPos, float wsdist, float VdotU, float VdotS) {
    // Underwater the sky-coloured fog would grey out the sea. DoSubmergedFog does the water look.
    if (isCamInWater) return;

    #ifndef END
        #ifdef OVERWORLD
            float skylFade = max0(1.0 - 2.0 * skylightFactor);
            float altiFade = linearStep(55.0, 40.0, cameraPosition.y);

            float fogMixer = isCamInWater ? 0.0 : skylFade * altiFade;

            vec3 atmoFogColor = mix(middleSkyColor, vec3(0.45, 0.45, 0.5), fogMixer);
        #else
            vec3 atmoFogColor = altSkyColor;
        #endif

        #ifdef OVERWORLD
            float rainAdd = 49e-4 * skylightFactor * rainFactor;
            float atmoFog = exp2(-(1e-4 + rainAdd) * wsdist);

            float fogAlti   = 60.0;
            float worldPosY = cameraPosition.y + playerPos.y; 
            float integral  = integrateHeightVolume(cameraPosition.y, worldPosY, wsdist, fogAlti, 10.0);

            float LdotUM2   = min1(abs(pSunVec.y) * 10.0 + 0.2);
            float fogFactor = 0.005 * wsdist *
                              pow2(1.0 - 0.2 * noonFactor) *
                              clamp((cameraPosition.y - fogAlti) / 60.0, 0.1, 1.0);

            float heightFog = exp2(-0.02 * integral * min1(fogFactor) * skylightFactor * LdotUM2);
    
            atmoFog *= heightFog;
        #else
            float atmoFog = exp2(-1e-3 * wsdist);
        #endif

        color = mix(atmoFogColor, color, atmoFog);
    #endif

    #ifdef NETHER
        const float fogStart = 0.32;
    #else
        const float fogStart = 0.85;
    #endif

    float borderFog = pow2(linearStep(fogStart, 1.0, max(length(playerPos.xz), abs(playerPos.y)) / borderFogDist));

    if (borderFog > 0.0) {
        #ifdef OVERWORLD
            vec3 sky = getSky(VdotU, VdotS);
        #else
            vec3 sky = altSkyColor;
        #endif

        color = mix(color, sky, borderFog);
    }
}