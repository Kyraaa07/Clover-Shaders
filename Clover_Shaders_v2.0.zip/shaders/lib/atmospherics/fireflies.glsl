#ifndef FIREFLIES_GLSL
#define FIREFLIES_GLSL

// Beauty Night: a small swarm of fireflies that drifts around the player at night.
// They are drawn as additive glow points and also light up nearby surfaces.
// The swarm lives in a box around the camera and wraps around, so no world data is needed.

uniform ivec2 eyeBrightnessSmooth;

const vec3 ffLo    = vec3(-20.0, -5.0, -20.0);
const vec3 ffBox   = vec3( 40.0, 10.0,  40.0);

// Cave swarm: smaller box = denser fireflies in tight tunnels
const vec3 ffCaveLo  = vec3(-14.0, -5.0, -14.0);
const vec3 ffCaveBox = vec3( 28.0, 10.0,  28.0);
const vec3 ffColor = vec3(0.70, 1.00, 0.22);

// Multi colour palette: yellow, green, blue, orange (each firefly keeps its own colour)
vec3 ff_palette(int idx) {
    if (idx == 0) return vec3(1.00, 0.85, 0.20);  // yellow
    if (idx == 1) return vec3(0.35, 1.00, 0.25);  // green
    if (idx == 2) return vec3(0.30, 0.60, 1.00);  // blue
    return              vec3(1.00, 0.45, 0.10);   // orange
}

vec3 ff_hash3(float n) {
    vec3 p = fract(vec3(n) * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

void ff_get(int i, vec3 lo, vec3 box, out vec3 rel, out float intensity, out float fade, out vec3 col) {
    vec3 h = ff_hash3(float(i) + 1.0);

    #if FIREFLY_COLORS == 1
        col = ff_palette(int(ff_hash3(float(i) + 37.0).x * 3.999));
    #else
        col = ffColor;
    #endif
    float t = frameTimeCounter * FIREFLY_SPEED;

    vec3 wander = vec3(
        sin(t * 0.31 + h.x * 6.283) * 2.6 + sin(t * 0.83 + h.y * 11.0) * 0.7,
        sin(t * 0.47 + h.y * 6.283) * 1.1 + sin(t * 1.10 + h.z *  7.0) * 0.3,
        cos(t * 0.27 + h.z * 6.283) * 2.6 + cos(t * 0.77 + h.x *  9.0) * 0.7
    );

    rel = h * box + wander - cameraPosition;
    rel = mod(rel - lo, box) + lo;

    vec3 edge = min(rel - lo, lo + box - rel);
    fade = smoothstep(0.0, 3.0, min(edge.x, min(edge.y, edge.z)));

    float blink = 0.5 + 0.5 * sin(t * (1.2 + h.x * 1.5) + h.z * 6.283);
    blink = smoothstep(0.35, 1.0, blink);
    intensity = 0.30 + 0.70 * blink;
}

float ff_getStrength() {
    float s = smoothstep(0.4, 0.9, nightFactor);
    s *= 1.0 - wetness;
    s *= smoothstep(0.25, 0.7, float(eyeBrightnessSmooth.y) / 240.0); // fade out in caves / indoors
    s *= 1.0 - smoothstep(0.15, 0.55, float(eyeBrightnessSmooth.x) / 240.0); // only where there is little artificial light
    return s;
}

// Cave fireflies: any dark place with little sky light and little artificial light (day or night)
float ff_getCaveStrength() {
    float s = 1.0 - smoothstep(0.08, 0.35, float(eyeBrightnessSmooth.y) / 240.0);
    s *= 1.0 - smoothstep(0.25, 0.65, float(eyeBrightnessSmooth.x) / 240.0);
    return s;
}

void ff_draw(inout vec3 color, vec3 albedo, float blockLight, vec3 playerPos, bool isSky,
             float strength, vec3 lo, vec3 box, int count) {
    if (strength < 0.01) return;

    float sceneDist = isSky ? 1e30 : length(playerPos);
    vec3 rayDir = normalize(playerPos);

    vec3 glow  = vec3(0.0);
    vec3 light = vec3(0.0);

    for (int i = 0; i < count; i++) {
        vec3 rel, fcol; float intensity, fade;
        ff_get(i, lo, box, rel, intensity, fade, fcol);

        float w = intensity * fade;

        // Visible glow point
        float tt = dot(rel, rayDir);
        if (tt > 0.1 && tt < sceneDist) {
            vec3 closest = rayDir * tt - rel;
            float d2 = dot(closest, closest);

            float r  = 0.035 + 0.004 * tt;
            float r2 = r * r;

            float core = exp(-d2 / r2);
            float halo = exp(-d2 / (r2 * 40.0));

            glow += fcol * (core * 1.1 + halo * 0.16) * w;
        }

        // Light on nearby surfaces
        if (!isSky) {
            float d = length(rel - playerPos);
            light += fcol * (pow2(max(0.0, 1.0 - d / 7.0)) * w);
        }
    }

    color += glow * FIREFLY_BRIGHTNESS * strength;
    color += albedo * light * (0.25 * FIREFLY_LIGHT * strength * (1.0 - smoothstep(0.2, 0.7, blockLight)));
}

void doFireflies(inout vec3 color, vec3 albedo, float blockLight, vec3 playerPos, bool isSky) {
    ff_draw(color, albedo, blockLight, playerPos, isSky, ff_getStrength(), ffLo, ffBox, FIREFLY_AMOUNT);
}

void doCaveFireflies(inout vec3 color, vec3 albedo, float blockLight, vec3 playerPos, bool isSky) {
    ff_draw(color, albedo, blockLight, playerPos, isSky, ff_getCaveStrength(), ffCaveLo, ffCaveBox, CAVE_FIREFLY_AMOUNT);
}

#endif
