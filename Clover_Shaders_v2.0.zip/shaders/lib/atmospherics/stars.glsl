float hash21(vec2 p) {
	return fract(sin(dot(p, vec2(5.392182, 8.92886))) * 43758.5453123);
}

vec2 getMappedCoord(vec3 rayDir) {
    vec2 wind = vec2(3.3 * timeAngle, 0.0);

    float norm = rayDir.y + length(rayDir.xz) * 1.2;
    vec2 coord = rayDir.xz / norm + wind;

    return floor(coord * (400.0 / STAR_SCALE)) / (400.0 / STAR_SCALE);
}

vec3 getStars(vec3 rayDir) {
    float absVdotS = abs(dot(rayDir, pSunVec));

    float horizFactor = linearStep(-0.06, 0.34, rayDir.y);
    float nightFactor = linearStep(0.15, -0.10, pSunVec.y);
    float celesFactor = linearStep(0.997, 0.995, absVdotS);

    float visiblity = horizFactor * nightFactor * celesFactor * invRainFactor;

    if (visiblity < 1e-6) return vec3(0.0);

    vec2 sCoord = getMappedCoord(rayDir);
    float stars = hash21(sCoord) * hash21(sCoord + 0.44);

    stars  = pow3(linearStep(1.0 - STAR_AMOUNT, 1.0, stars));
    stars *= pow4(stars) * 0.95 + 0.05;

    return (vec3(1.2, 2.0, 3.6) * STAR_BRIGHTNESS) * (stars * visiblity);
}