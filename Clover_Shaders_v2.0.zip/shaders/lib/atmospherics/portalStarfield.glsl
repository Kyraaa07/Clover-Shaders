// ---- End Portal starfield ----
// Dense, bright, twinkling stars in mixed colours, projected on the view direction.
// Used by the End Portal window in the deferred pass.

float psHash(vec3 p) {
    return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
}

vec3 portalStarfield(vec3 dir, float time) {
    vec3  p    = dir * 70.0;
    vec3  cell = floor(p);
    vec3  f    = fract(p) - 0.5;
    float h    = psHash(cell);

    if (h < 0.30) return vec3(0.0);

    vec3  off  = vec3(psHash(cell + 1.1), psHash(cell + 2.3), psHash(cell + 3.7)) * 0.5 - 0.25;
    float dist = length(f - off);
    float twinkle = 0.55 + 0.45 * sin(time * 2.5 + h * 40.0);
    float strength = (h - 0.30) / 0.70;
    float star = smoothstep(0.22, 0.0, dist) * twinkle * (0.6 + 0.8 * strength);

    vec3 col = vec3(1.0, 1.0, 1.0);
    if (h > 0.92)      col = vec3(1.00, 0.55, 0.85);  // pink
    else if (h > 0.84) col = vec3(0.55, 0.75, 1.00);  // blue
    else if (h > 0.72) col = vec3(0.40, 1.00, 0.90);  // teal
    else if (h > 0.60) col = vec3(0.70, 1.00, 0.60);  // green

    return col * star;
}
