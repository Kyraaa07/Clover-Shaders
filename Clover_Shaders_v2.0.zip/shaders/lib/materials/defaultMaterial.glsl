Material getMaterial(mat3 tbnMatrix, vec3 albedo) {
    Material material;
    material.albedo = SRGBToLinear(albedo);

    #ifdef NORMALS_OVERRIDE
	    material.geoNormal = vec3(0.0, 0.0, 1.0);
	    material.normalM = vec3(0.0, 0.0, 1.0);
    #else
        material.geoNormal = tbnMatrix[2];
        material.normalM = tbnMatrix[2];
    #endif

    #ifdef LMCOORD_OVERRIDE
        material.blocklight = 0.0;
        material.skylight = 0.0;
    #else
        material.blocklight = lmcoord.x;
        material.skylight = lmcoord.y;
    #endif

    #ifdef GBUFFERS_TERRAIN
        material.ao = glColor.a;
    #else
        material.ao = 1.0;
    #endif

    material.roughness = 1.0;
    material.emission = 0.0;
    material.sss = 0.0;
    material.f0 = 0.02;

    return material;
}