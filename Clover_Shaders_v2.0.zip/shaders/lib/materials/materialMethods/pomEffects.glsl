/*
    Parallax Occlusion Mapping (POM) for Clover Shaders
    Adapted from Complementary Unbound by EminGT
    Integrated by: Clover POM Patch
*/

// ---------------------------------------------------------------------------
// Atlas helpers — convert tile-local UV to atlas UV and back
// ---------------------------------------------------------------------------

// Read the normal/height map at a tile-local coord, clamped to the tile
vec4 POM_ReadNormal(vec2 localCoord) {
    // Wrap within tile, then remap to atlas space
    vec2 atlasCoord = fract(localCoord) * vTexCoordAM.pq + vTexCoordAM.st;
    return textureGrad(normals, atlasCoord, dcdx, dcdy);
}

// ---------------------------------------------------------------------------
// Main POM trace — returns the offset local coord after depth tracing
// Also fills newCoord (atlas-space) and traceCoordDepth for slope normals
// ---------------------------------------------------------------------------
vec2 GetParallaxCoord(
    float parallaxFade,
    float dither,
    inout vec2  newCoord,        // atlas-space result coord
    inout float texDepth,        // height at hit
    inout vec3  traceCoordDepth  // (localCoord.xy, depth) for slope normals
) {
    float invQuality = 1.0 / float(POM_QUALITY);

    // Sample the very first texel to do early-out checks
    vec4  normalMap   = POM_ReadNormal(vTexCoord.st);
    vec2  normalMapXY = normalMap.xy * 2.0 - 1.0;
    float normalCheck = normalMapXY.x + normalMapXY.y;
    float minHeight   = 1.0 - invQuality;

    // Skip POM if: looking straight down, surface already flat, or flat normal map
    if (viewVector.z >= 0.0 || normalMap.a >= minHeight || normalCheck <= -1.999)
        return vTexCoord.st;

    // Step vector in tile-local space
    vec2 interval = viewVector.xy * 0.25 * (1.0 - parallaxFade) * POM_DEPTH
                    / (-viewVector.z * float(POM_QUALITY));

    float i = 0.0;
    vec2  localCoord;

    // First step offset by TAA dither so edges don't alias over frames
    if (texDepth <= 1.0 - i * invQuality) {
        localCoord = vTexCoord.st + i * interval;
        texDepth   = POM_ReadNormal(localCoord).a;
        i = dither;
    }

    // March until we hit the surface
    for (; i < float(POM_QUALITY) && texDepth <= 1.0 - i * invQuality; i++) {
        localCoord = vTexCoord.st + i * interval;
        texDepth   = POM_ReadNormal(localCoord).a;
    }

    // Step back one to get the last coord before the hit
    float prevI = max(i - 1.0, 0.0);
    traceCoordDepth.xy -= prevI * interval;
    traceCoordDepth.z  -= prevI * invQuality;

    localCoord = fract(vTexCoord.st + prevI * interval);
    newCoord   = localCoord * vTexCoordAM.pq + vTexCoordAM.st;
    return localCoord;
}

// ---------------------------------------------------------------------------
// Parallax self-shadow — darkens areas occluded from the sun by the surface
// ---------------------------------------------------------------------------
float GetParallaxShadow(
    float parallaxFade,
    float dither,
    float height,
    vec2  localCoord,
    vec3  lightVec,
    mat3  tbnMatrix
) {
    float shadow = 1.0;

    vec3 pDir    = tbnMatrix * lightVec;
    pDir.xy     *= POM_DEPTH; // scale XY by depth factor

    for (int i = 0; i < 4 && shadow >= 0.01; i++) {
        float stepLC = 0.025 * (float(i) + dither);

        float currentHeight  = height + pDir.z * stepLC;
        vec2  pCoordAtlas    = fract(localCoord + pDir.xy * stepLC) * vTexCoordAM.pq + vTexCoordAM.st;
        float offsetHeight   = textureGrad(normals, pCoordAtlas, dcdx, dcdy).a;

        shadow *= clamp(1.0 - (offsetHeight - currentHeight) * 4.0, 0.0, 1.0);
    }

    return mix(shadow, 1.0, parallaxFade);
}

// ---------------------------------------------------------------------------
// Slope normal correction — improves normals at steep height discontinuities
// (thanks to null511 for the original algorithm, via Complementary)
// ---------------------------------------------------------------------------
vec3 GetParallaxSlopeNormal(vec2 localCoord, float traceDepth, vec3 viewDir) {
    vec2 atlasPixelSize = 1.0 / vec2(atlasSize);
    float atlasAspect   = float(atlasSize.x) / float(atlasSize.y);
    vec2 atlasCoord     = fract(localCoord) * vTexCoordAM.pq + vTexCoordAM.st;

    vec2 tileSize      = vec2(atlasSize) * vTexCoordAM.pq;
    vec2 tilePixelSize = 1.0 / tileSize;

    vec2 tex_snapped = floor(atlasCoord * vec2(atlasSize)) * atlasPixelSize;
    vec2 tex_offset  = atlasCoord - (tex_snapped + 0.5 * atlasPixelSize);

    vec2 stepSign = sign(tex_offset);
    vec2 viewSign = sign(viewDir.xy);

    bool dir = abs(tex_offset.x * atlasAspect) < abs(tex_offset.y);
    vec2 tex_x, tex_y;

    if (dir) {
        tex_x = localCoord - vec2(tilePixelSize.x * viewSign.x, 0.0);
        tex_y = localCoord + vec2(0.0, stepSign.y * tilePixelSize.y);
    } else {
        tex_x = localCoord + vec2(tilePixelSize.x * stepSign.x, 0.0);
        tex_y = localCoord - vec2(0.0, viewSign.y * tilePixelSize.y);
    }

    float height_x = POM_ReadNormal(tex_x).a;
    float height_y = POM_ReadNormal(tex_y).a;

    if (dir) {
        if (!(traceDepth > height_y && viewSign.y != stepSign.y)) {
            if (traceDepth > height_x) return vec3(-viewSign.x, 0.0, 0.0);
            return abs(viewDir.y) > abs(viewDir.x)
                ? vec3(0.0, -viewSign.y, 0.0)
                : vec3(-viewSign.x, 0.0, 0.0);
        }
        return vec3(0.0, -viewSign.y, 0.0);
    } else {
        if (!(traceDepth > height_x && viewSign.x != stepSign.x)) {
            if (traceDepth > height_y) return vec3(0.0, -viewSign.y, 0.0);
            return abs(viewDir.y) > abs(viewDir.x)
                ? vec3(0.0, -viewSign.y, 0.0)
                : vec3(-viewSign.x, 0.0, 0.0);
        }
        return vec3(-viewSign.x, 0.0, 0.0);
    }
}
