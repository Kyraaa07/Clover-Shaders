const int layers = 4;

const vec3 tint = vec3(0.1, 0.4, 0.8);
const vec3 base = vec3(0.0, 0.2, 1.0) / 255.0; 

float t = -1.0 / dot(material.geoNormal, viewPos);

vec2 delta = viewToFace(viewPos, tbnMatrix) * t / (layers - 1) * 0.0625; 
vec2 coord = viewToFace(vsCameraPosition + viewPos, tbnMatrix) * 0.0625;

const vec2 windDir[layers] = vec2[layers](vec2(0.00000025, 0.00000000), vec2(-0.00184342, -0.00168873), 
                                          vec2(0.00021856, 0.00249043), vec2( 0.00152110, -0.00198400));

float stars = 0.0;
for (int i = 0; i < layers; i++) {
    vec2 wind = windDir[i] * (frameTimeCounter + 50.0);

    stars += texture(gtexture, coord + wind).r;
    coord += delta;
}
stars = min1(2.0 * stars * stars);

material.albedo = base + stars * tint;
material.emission = 0.25 * stars;

material.roughness = 1.0;

#if PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1
    // The portal surface itself is replaced by the End sky in the deferred pass.
    // Here we only describe the light it casts (colour = albedo, strength = emission).
    material.albedo   = END_PORTAL_LIGHT_COLOR;
    material.emission = min(0.28 * PORTAL_LIGHT_STRENGTH, 0.3);
#endif

// Open portal glows in the same colour as the Eyes of Ender (or stays dark when switched off).
#if PORTAL_ENHANCE == 1
    #if END_PORTAL_EMITS_LIGHT == 1
        material.albedo   = END_PORTAL_LIGHT_COLOR;
        material.emission = min(0.28 * PORTAL_LIGHT_STRENGTH * END_PORTAL_GLOW_STRENGTH, 0.4);
    #else
        material.emission = 0.0;
    #endif
#endif