// Nether portal: normal purple mixed with a dark purple that pools at the bottom of the portal
// and licks upwards like fire.
{
    vec3 pWorld = playerPos + cameraPosition;

    float along = pWorld.x + pWorld.z;   // works for both portal orientations
    float h     = fract(pWorld.y);       // 0 = bottom of the block, 1 = top
    float tt    = frameTimeCounter * NETHER_PORTAL_FLAME_SPEED;

    vec2 q = vec2(along * 2.2, pWorld.y * 1.7 - tt * 1.5);

    float f1 = pe_fbm(q);
    float f2 = pe_fbm(q * 1.9 + vec2(5.2 + 0.6 * sin(tt * 0.7), -tt * 0.9));
    float flame = f1 * 0.6 + f2 * 0.4;

    // Dark gradient at the bottom, with flame tongues reaching upwards
    float flameMask = 1.0 - smoothstep(0.0, 0.9, h * 1.15 + (flame - 0.5) * 0.9);

    const vec3 deepPurple = vec3(0.14, 0.015, 0.32);
    const vec3 hotPurple  = vec3(0.62, 0.16, 1.00);

    material.albedo = mix(material.albedo, deepPurple, flameMask * 0.9);

    float tongue = flameMask * (1.0 - flameMask) * 4.0; // brightest on the flame edge
    material.albedo = clamp01(material.albedo + hotPurple * tongue * flame * 0.55);

    material.emission = min((max(material.emission, 0.14) + 0.10 * tongue * flame) * PORTAL_LIGHT_STRENGTH, 0.3);

    alpha = mix(alpha, min(1.0, alpha * 1.25 + 0.1), flameMask);
}
