vec2 faceCoord = (viewPos + vsCameraPosition) * mat2x3(tbnMatrix);
vec3 nViewPos  = normalize(viewPos);

float solidDepth = texelFetch(depthtex1, ivec2(gl_FragCoord.xy), 0).r;
vec3 viewDiff = screenToView(vec3(screenPos.xy, solidDepth)) - viewPos;

material.f0 = 0.05;
material.sss = 0.0;
material.roughness = 0.0;
#if WATER_TEXTURE == 1
    material.normalM = material.geoNormal; // flat surface like vanilla water
#else
    material.normalM = getWaterNormal(faceCoord, tbnMatrix, nViewPos);
#endif

// Depth: vertical height of water above the floor behind it (shallow near the shore, deep further out).
// Vertical, not along the view ray, so far-away shallow water stays turquoise.
float waterDepth = abs(dot(viewDiff, upVec));
// Three stops: shallow turquoise (see-through) -> blue-green in the middle -> deep blue
float midMix  = smoothstep(0.5, 4.0, waterDepth);
float deepMix = smoothstep(4.0, 14.0, waterDepth);
vec3 waterTint = mix(WATER_TINT, WATER_MID_TINT, midMix);
waterTint = mix(waterTint, WATER_DEEP_TINT, deepMix);
material.albedo = glColor.rgb * waterTint;
material.albedo.g = min(material.albedo.g, WATER_GREEN_CAP);

#if WATER_TEXTURE == 1
    // Vanilla water texture: its light/dark pattern modulates the shader water colour
    float vanillaTex = getLuminance(colorP) / 0.55;
    material.albedo *= clamp(1.0 + (vanillaTex - 1.0) * 1.6, 0.4, 1.8);
#endif

alpha = 1.0 - (1.0 - WATER_OPACITY * 0.01) * exp2(-0.15 * length(viewDiff));

if (isCamInWater) alpha = 0.9;

// Foam                   
vec2 foamCoord  = 0.25 * faceCoord + 0.05 * frameTimeCounter;

float distFactor = exp2(-4.0 * abs(dot(viewDiff, upVec)));
float normFactor = pow4(pow4(dot(tbnMatrix[2], upVec)));
float foamNoise  = textureLod(noisetex, foamCoord, 0).r;

float foam = WATER_FOAM * 0.01 * distFactor * normFactor * foamNoise;

#if WATER_TEXTURE == 1
    foam = 0.0;
#endif
material.albedo = mix(material.albedo, vec3(1.0), foam);
alpha = mix(alpha, 1.0, foam);