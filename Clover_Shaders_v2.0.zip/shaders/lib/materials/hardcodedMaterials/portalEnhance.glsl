#ifndef PORTAL_ENHANCE_GLSL
#define PORTAL_ENHANCE_GLSL

float pe_hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float pe_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    return mix(mix(pe_hash(i),                pe_hash(i + vec2(1.0, 0.0)), f.x),
               mix(pe_hash(i + vec2(0.0, 1.0)), pe_hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

float pe_fbm(vec2 p) {
    float a = 0.5;
    float sum = 0.0;
    for (int i = 0; i < 4; i++) {
        sum += a * pe_noise(p);
        p = p * 2.03 + vec2(17.1, -9.7);
        a *= 0.5;
    }
    return sum / 0.9375;
}

#endif
