#include "/lib/settings/materialSettings.glsl"
#include "/lib/util/packing.glsl"

struct Material {
    vec3 albedo;
    vec3 normalM;
    vec3 geoNormal;
    float roughness;
    float blocklight;
    float skylight;
    float emission;
    float sss;
    float f0; // 0.0 - 229.0 / 255.0 --> f0,   230.0 / 255.0 --> 1.0 metals
    float ao; // vanillaAo
};

#ifdef DEFERRED
    #ifndef LOD_MAX_DIST
        #define LOD_MAX_DIST 32768.0 // Must match program/voxy/voxyCommon.glsl
    #endif

    // View-space (planar) depth of a Voxy LOD pixel, written by program/voxy/voxyCommon.glsl
    float getLodDepthAt(ivec2 px) {
        uvec4 materialData = texelFetch(colortex3, px, 0);

        float lo = float(materialData.w & 255u);
        float hi = float((materialData.w >> 16u) & 255u);

        return (lo + hi * 256.0) * (LOD_MAX_DIST / 65535.0);
    }

    float getLodDepth() {
        uvec4 materialData = texelFetch(colortex3, ivec2(gl_FragCoord.xy), 0);

        float lo = float(materialData.w & 255u);
        float hi = float((materialData.w >> 16u) & 255u);

        return (lo + hi * 256.0) * (LOD_MAX_DIST / 65535.0);
    }

    Material getMaterial() {
        Material material;
        
        uvec4 materialData = texelFetch(colortex3, ivec2(gl_FragCoord.xy), 0);
        
        vec4 b1, b2, b3, b4;
        unpack4_4x8b(materialData, b1, b2, b3, b4);

        material.albedo = b1.rgb;
        
        material.normalM   = octaDecode(b2.xy);
        material.geoNormal = octaDecode(b2.zw);

        material.f0 = b3.b; 
        material.ao = b4.a;
        material.sss = b3.g;
        material.skylight = b4.g;
        material.emission = b4.b;
        material.roughness = b3.r;
        material.blocklight = b4.r; 

        return material;
    }
#else
    #if defined DEFAULT_MATERIAL || PBR_MODE != 0
        #include "/lib/materials/defaultMaterial.glsl"
    #else
        #include "/lib/materials/labpbrMaterials.glsl"
    #endif

    #include "/lib/materials/hardcodedMaterials.glsl"

    void packMaterialData(Material material, out uvec4 buffer0) {
        vec4 b1 = vec4(material.albedo, 0.0);
        vec4 b2 = vec4(octaEncode(material.normalM), octaEncode(material.geoNormal));
        vec4 b3 = vec4(material.roughness,  material.sss,      material.f0,           0.0    );
        vec4 b4 = vec4(material.blocklight, material.skylight, material.emission, material.ao);

        buffer0 = pack4_4x8b(b1, b2, b3, b4);
    }
#endif

bool isMetal(float f0) {
    return f0 > 229.1 / 255.0;
}