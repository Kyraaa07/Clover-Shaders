Material getMaterial(mat3 tbnMatrix, vec3 albedo) {
    Material material;
    material.albedo = SRGBToLinear(albedo);

    vec4 specularData = texture(specular, texcoord);
    material.roughness = pow2(1.0 - specularData.r);
    material.emission = fract(specularData.a) * 0.15 * LABPBR_EMISSION_STRENGTH;
    material.f0 = specularData.g;

    #ifdef GBUFFERS_ENTITIES
        material.sss = 0.0;
    #else
        material.sss = step(0.25098039215,  specularData.b) * 
                           (specularData.b - 0.25098039215) * 1.33507853402;
    #endif

    #if defined GBUFFERS_TEXTURED || defined GBUFFERS_PARTICLES || defined GBUFFERS_PARTICLES_TRANSLUCENT
        material.normalM = tbnMatrix[2];
    #else
        material.normalM   = vec3(texture(normals, texcoord).rg * 2.0 - 1.0, 0.0);
        material.normalM.z = sqrt(1.0 - lengthSquared(material.normalM.xy));
        material.normalM   = tbnMatrix * material.normalM; 
    #endif
    material.geoNormal = tbnMatrix[2];

    material.blocklight = lmcoord.x;
    material.skylight = lmcoord.y;

    #ifdef GBUFFERS_TERRAIN
        material.ao = glColor.a;
    #else
        material.ao = 1.0;
    #endif
    
    return material;
}