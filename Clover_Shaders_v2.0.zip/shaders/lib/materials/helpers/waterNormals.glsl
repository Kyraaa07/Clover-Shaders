vec3 getWaveNormal(vec2 coord, float stretch, float intensity, float speedMulti) {
    vec2 newCoord = coord / stretch + 0.15 * speedMulti * frameTimeCounter;
    vec2 normalXY = textureLod(noisetex, newCoord, 0).gb - 0.5;
    return vec3(normalXY * intensity, 1.0);
}

vec3 getWaterNormal(vec2 coord, mat3 tbnMatrix, vec3 nViewPos) {
    vec3 waterNormal = getWaveNormal(coord, 5.0,  0.37, -0.20) +
                       getWaveNormal(coord, 10.0, 0.50,  0.12) +
                       getWaveNormal(coord, 30.0, 0.40,  0.12) + 
                       getWaveNormal(coord, 50.0, 0.50, -0.20);

    waterNormal = tbnMatrix * normalize(waterNormal);
    
    vec3 refVec = reflect(nViewPos, waterNormal);
    float mixer = pow4(1.0 - max0(dot(refVec, tbnMatrix[2])));
    
    return normalize(mix(waterNormal, tbnMatrix[2], mixer));
}