/* ------------------ matID: 2000, Glass ------------------ */
if (matID == 2000) {
    material.roughness = 0.0;
    material.sss = 0.3;
    material.f0 = 0.02;
}

/* ------------------- matID: 2001, Ice ------------------- */
else if (matID == 2001) {
    material.roughness = 0.04;
    material.f0 = 0.02;
}