// 'atlasSize' uniform seems to be wrong on Iris 1.21.9+
#if MC_VERSION >= 12109
    ivec2 atlasSize = textureSize(gtexture, 0);
#endif

if ((atlasSize.x == 512 || atlasSize.x == 256) && atlasSize.y == 256) { // Particle atlas
    /* -------------------- Water Particles ------------------- */
    if (
        material.albedo.r < 0.38 &&
        material.albedo.g < 0.58 &&
        material.albedo.b < 0.87 &&
        material.albedo.b > 0.55 && 
        material.albedo.g > material.albedo.r
    ) {
        material.albedo *= vec3(0.73, 0.83, 0.73);
        material.albedo += vec3(0.03, 0.10, 0.10);
    }

    /* ------------------ Firework Particles ------------------ */
    else if (
        minOf(material.albedo) > 0.999 ||

        maxOf(abs(material.albedo - 0.45907989242)) < 1e-6 ||
        maxOf(abs(material.albedo - 0.62534472080)) < 1e-6
    ) {
        material.emission = 0.2;
        material.blocklight = 0.0;
    }

    /* ------------------ Emissive Particles ------------------ */
    else if (
        // Exclude translucent particles
        alpha > 0.95 &&

        // Exclude tinted particles, except redstone
        (minOf(glColor.rgb) > 0.999 || glColor.g + glColor.b < 0.18) &&
        
        // Exclude cherry leaves
        (material.albedo.r > 0.995 || material.albedo.r < 0.645 || 
         material.albedo.g > 0.495 || material.albedo.g < 0.145 ||
         material.albedo.b > 0.730 || material.albedo.b < 0.380)
    ) {
        material.emission = pow2(material.blocklight) * 0.7 * PARTICLE_EMISSION_STRENGTH;
    }
}