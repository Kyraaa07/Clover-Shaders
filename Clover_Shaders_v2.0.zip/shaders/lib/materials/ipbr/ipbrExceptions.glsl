#if defined GBUFFERS_TERRAIN || defined GBUFFERS_ENTITIES
    /* ------------- matID: 5000, Fire & Soul Fire ------------ */
    if (matID == 5000) {
        material.emission = lumaColorPM * 0.35;
    }
#endif