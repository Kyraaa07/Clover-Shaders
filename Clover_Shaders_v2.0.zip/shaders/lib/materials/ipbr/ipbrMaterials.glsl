// Auto generated roughness
material.roughness = max(0.25, 0.6 - 0.3 * lumaColorPM);

// <-- Particles -->
#if PARTICLE_MATERIALS == 1
    #if defined GBUFFERS_TEXTURED || defined GBUFFERS_PARTICLES || defined GBUFFERS_PARTICLES_TRANSLUCENT
        #include "/lib/materials/ipbr/ipbrParticles.glsl"
    #endif
#endif

// <-- Entities -->
#if defined GBUFFERS_ENTITIES || defined GBUFFERS_ENTITIES_TRANSLUCENT
    #include "/lib/materials/ipbr/ipbrEntities.glsl"

    #ifdef IS_IRIS
        if (currentRenderedItemId > 0) {
            #ifdef GBUFFERS_ENTITIES
                #include "/lib/materials/ipbr/ipbrSolids.glsl"
            #endif

            #if defined GBUFFERS_ENTITIES_TRANSLUCENT || MC_VERSION < 260100
                #include "/lib/materials/ipbr/ipbrTranslucents.glsl"
            #endif
        }
    #endif
#endif

// <-- Terrain -->
#ifdef GBUFFERS_TERRAIN
    #include "/lib/materials/ipbr/ipbrSolids.glsl"
#endif

// <-- Translucents -->
#ifdef GBUFFERS_WATER
    #include "/lib/materials/ipbr/ipbrTranslucents.glsl"
#endif

// <-- Hand -->
#ifdef IS_IRIS
    #ifdef GBUFFERS_HAND
        if (currentRenderedItemId > 0) {
            #include "/lib/materials/ipbr/ipbrSolids.glsl"
        }   
    #endif

    #ifdef GBUFFERS_HAND_WATER
        if (currentRenderedItemId > 0) {
            #include "/lib/materials/ipbr/ipbrTranslucents.glsl"
        }   
    #endif
#endif

// <-- Exceptions -->
#include "/lib/materials/ipbr/ipbrExceptions.glsl"