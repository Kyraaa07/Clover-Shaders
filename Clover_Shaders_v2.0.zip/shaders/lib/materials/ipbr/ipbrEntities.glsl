/* --------------- matID: 4002, End Crystal --------------- */
if (matID == 4002) {
    if (material.albedo.r - material.albedo.g > 0.5) {
        material.emission = 0.6;
    }
    material.blocklight = 0.75;
}

/* -------------- matID: 4003, Experience Orb ------------- */
else if (matID == 4003) {
    material.emission = lumaColorPM * 0.6;
}

/* ---------- matID: 4004, Vex, Allay, Glow Squid --------- */
else if (matID == 4004) {
    material.emission = lumaColorPM * 0.18 + 0.02;
    material.blocklight = 0.0;
}

/* --------------- matID: 4005, Armor Trims --------------- */
else if (matID == 4005) {
    #if GLOWING_ARMOR_TRIMS == 1
        material.emission = 0.03;
    #endif
}