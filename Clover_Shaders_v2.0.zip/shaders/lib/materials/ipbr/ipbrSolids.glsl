if (matID >= 1000) {
    if (matID <= 1015) {
        if (matID <= 1007) {
            if (matID <= 1003) {
                if (matID <= 1001) {
                    /* --------------- matID: 1000, Copper Bulb --------------- */
                    if (matID == 1000) {
                        if (material.albedo.g > 2.9 * material.albedo.b || lumaColorPM > 0.6) {
                            material.emission = 0.5 * lumaColorPM;
                        }
                        material.blocklight *= 0.9;
                    }

                    /* ------------------- matID: 1001, Ores ------------------ */
                    else {
                        #if GLOWING_ORES == 1
                            float maxAlbedo = maxOf(material.albedo);
                            float minAlbedo = minOf(material.albedo);

                            float threshold = 3.0 * minAlbedo * (1.0 - lumaColorPM);

                            if (maxAlbedo > max(0.13, threshold)) {
                                material.emission = maxAlbedo * 0.03 + 0.0045;
                            }
                        #endif
                    }
                } else {
                    /* -------------- matID: 1002, Copper Lantern ------------- */
                    if (matID == 1002) {
                        if (material.albedo.g > material.albedo.r + 1.7 * material.albedo.b || lumaColorPM > 0.4) {
                            material.emission = lumaColorPM * 0.5;
                        }
                        material.blocklight *= 0.87;
                    } 

                    /* ----------------- matID: 1003, Torches ----------------- */
                    else {
                        if (material.albedo.r > 0.4 || material.albedo.g > material.albedo.r) {
                            material.emission = 0.35;
                        }
                        material.blocklight *= 0.95;
                    }
                }
            } else {
                if (matID <= 1005) {
                    /* ---------------- matID: 1004, Amethyst ----------------- */
                    if (matID == 1004) {
                        #ifdef GBUFFERS_TERRAIN
                            vec3 fracWorldPos = fract(cameraPosition + playerPos);
                            float maxLocalPos = maxOf(abs(fracWorldPos - 0.5));

                            float emissionPre = pow2(1.0 - 2.0 * maxLocalPos) * lumaColorPM;

                            material.emission = min(0.15, pow2(emissionPre));
                        #else 
                            material.emission = floor(pow2(lumaColorPM) * 12.0 + 1.0) / 255.0;
                        #endif
                    } 

                    /* --------------- matID: 1005, Froglights ---------------- */
                    else {
                        material.albedo *= pow2(material.albedo);
                        material.emission = 0.125;
                        material.blocklight *= 0.3;
                    }
                } else {
                    /* -------------- matID: 1006, Glow Berries --------------- */
                    if (matID == 1006) {
                        if (material.albedo.r > 0.3) {
                            material.emission = 1.0;
                            material.albedo.gb *= vec2(0.3, 0.2);
                        }
                        material.blocklight *= 0.9;
                    } 
                    
                    /* ----- matID: 1007, End Portal Frame + Eye of Ender ----- */
                    else {
                        vec2 fracWorldPos = fract(cameraPosition.xz + playerPos.xz);
                        float maxLocalPos = maxOf(abs(fracWorldPos - 0.5));

                        if (maxLocalPos < 0.25) {
                            material.emission = pow2(0.85 - 3.4 * maxLocalPos) * lumaColorPM;
                        }

                        material.blocklight *= 0.94;
                    }
                }
            }
        } else {
            if (matID <= 1011) {
                if (matID <= 1009) {
                    /* -------------- matID: 1008, Redstone Lamp -------------- */
                    if (matID == 1008) {
                        if (lumaColorPM > 0.08)
                            material.emission = 0.35 * lumaColorPM;
                        material.blocklight *= 0.8;
                    } 
                    
                    /* -------------- matID: 1009, Soul Campfire -------------- */
                    else {
                        if (lumaColorPM > 0.8 ||
                            material.albedo.b - material.albedo.r > 0.2) material.emission = 0.15;
                    }
                } else {
                    /* --------- matID: 1010, Shroomlight & Glowstone --------- */
                    if (matID == 1010) {
                        material.emission = 0.34 * lumaColorPM;
                        material.blocklight *= 0.8;
                    } 

                    /* --------- matID: 1011, Lantern & Soul Lantern ---------- */
                    else { 
                        if (material.albedo.r > 0.1 || material.albedo.b > 0.3) {
                            material.emission = lumaColorPM * 0.5;
                        }
                        material.blocklight *= 0.87;
                    }
                }
            } else {
                if (matID <= 1013) {
                    /* ---------------- matID: 1012, Campfire ----------------- */
                    if (matID == 1012) {
                        if (lumaColorPM > 0.8 || 
                            (material.albedo.b < 0.1 && 
                            material.albedo.r - material.albedo.g > 0.2)) material.emission = 0.25;

                        material.blocklight *= 0.92;
                    } 
                    
                    /* --------------- matID: 1013, Sea Lantern --------------- */
                    else {
                        material.emission = pow2(lumaColorPM) * 0.4;
                        material.blocklight *= 0.8;
                        material.albedo.g *= 0.7;
                    }
                } else {
                    /* ------------------ matID: 1014, Magma ------------------ */
                    if (matID == 1014) {
                        if (lumaColorPM > 0.1) {
                            material.emission = lumaColorPM * 0.3;
                            material.albedo.g *= 0.5;
                        }
                        material.blocklight = 0.7;
                    }
                    
                    /* --------------- matID: 1015, Glow Lichen --------------- */
                    else {
                        if (lumaColorPM > 0.4) {
                            material.emission = 0.1;
                        }
                        material.blocklight = max(material.blocklight, 0.6);
                    }
                }
            }
        }
    } 
    /* ----------------- matID: 1016, End Rod ----------------- */
    else if (matID == 1016) {
        if (lumaColorPM > 0.6) {
            material.emission = lumaColorPM * 0.3;
        }
        material.blocklight *= 0.93;
    } 
    
    /* ----------------- matID: 1017, Beacon ------------------ */
    else if (matID == 1017) {
        if (
            material.albedo.g > material.albedo.b + 0.008 || 
            material.albedo.g > 0.96 && material.albedo.r < 0.99
        ) {
            material.emission = 0.5;
        }
        material.blocklight *= 0.9;
    } 

    /* ------------------ matID: 1018, Lava ------------------- */
    else if (matID == 1018) {
        material.emission = lumaColorPM * 0.5;
        material.albedo = min1(material.albedo + pow3(lumaColorPM));
    }

    /* ------------- matID: 1019, Jack O'Lantern -------------- */
    else if (matID == 1019) {
        if (material.albedo.g > 0.45) {
            material.emission = pow2(pow4(lumaColorPM)) * 0.7;
        }
        material.blocklight = 0.82;
    }

    /* ------------------ matID: 1020, Rails ------------------ */
    else if (matID == 1020) {
        material.albedo = SRGBToLinear(textureLod(gtexture, texcoord, 0).rgb);
        if (material.albedo.g < 0.05) {
            material.emission = 0.5;
        }
    }

    /* ------------- matID: 1021, Crying Obsidian ------------- */
    else if (matID == 1021) {
        if (material.albedo.b > 32.0 * material.albedo.g) {
            material.emission = min1(pow2(lumaColorPM) * 400.0);
            material.albedo = sqrt(material.albedo) * 0.5;
        }
    }

    /* --- matID: 1022, Gold / Iron / Diamond / Lapis / Emerald Blocks --- */
    else if (matID == 1022) {
        #if GLOWING_GEM_BLOCKS == 1
            // cahaya tipis: dasar kecil + sedikit naik di bagian paling terang tekstur
            material.emission = 0.02 + 0.03 * lumaColorPM;
        #endif
    }
}