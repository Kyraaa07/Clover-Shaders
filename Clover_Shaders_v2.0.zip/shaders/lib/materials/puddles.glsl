// ---------------- Rain Puddles ----------------
// Included at the end of applyHardcodedMaterials() (terrain only).
// Puddles = wet, glossy GROUND (not opaque water): the ground texture stays visible, it only gets
// slightly darker and mirror-like. Puddle strength is stored in roughness; the deferred pass reads
// it back (roughness < 0.16) and blends in a fresnel sky / screen space reflection.
// NOTE: albedo must always stay inside 0..1, otherwise the 8 bit packing overflows into the
// neighbouring channels (that is what caused the purple speckles).
//
// FIX: preserve PBR normal map detail under puddles so block textures stay
// visible even at high PUDDLE_PERMANENT_AMOUNT. The water surface is blended
// ON TOP of the PBR normal rather than replacing it completely.

// ---------------- Glossy World ----------------
// Same wet / mirror-like finish as a puddle, but on EVERY terrain face (floor, walls, ceiling),
// inside and outside, and independent of rain or sky light. The deferred pass reflects any terrain
// pixel with roughness < 0.16, so we only have to lower roughness (plus a slight darkening).
#if GLOSSY_WORLD == 1 && defined GBUFFERS_TERRAIN
{
    if (matID != 1 && matID != 2 && material.emission < 0.01 && material.f0 < 229.1 / 255.0) {
        vec3 gPos = playerPos + cameraPosition;
        float gNoise = textureLod(noisetex, (gPos.xz + 11.0 * floor(gPos.y + 0.01) + 5.0 * gPos.y) / 48.0, 0).r;

        #ifdef OVERWORLD
            float gBase = GLOSSY_STRENGTH_OVERWORLD;
        #else
            float gBase = GLOSSY_STRENGTH_NETHER_END;
        #endif
        float gStrength  = gBase * (0.8 + 0.2 * gNoise);
        float gRoughness = mix(0.15, 0.02, clamp01(gStrength));

        material.albedo    = clamp01(material.albedo * mix(1.0, 0.9, gStrength));
        material.roughness = min(material.roughness, gRoughness);
        material.f0        = max(material.f0, 0.045); // never lower than a water film
    }
}
#endif

#if RAIN_PUDDLES > 0 && defined GBUFFERS_TERRAIN
{
    #ifndef OVERWORLD
        float puddleWet = PUDDLE_PERMANENT_AMOUNT;               // Nether / End: no rain, so puddles are always there
    #elif RAIN_PUDDLES == 2
        float puddleWet = max(PUDDLE_PERMANENT_AMOUNT, wetness); // always there, rain only adds more
    #else
        float puddleWet = wetness;                               // only while / after it rains
    #endif

    if (puddleWet > 0.01 && matID != 1 && matID != 2 && material.emission < 0.01 && material.f0 < 229.1 / 255.0) {
        vec3 wPos = playerPos + cameraPosition;

        float upFacing = linearStep(0.9, 0.99, dot(material.geoNormal, upVec));
        #ifdef OVERWORLD
            float openSky  = linearStep(0.80, 0.95, material.skylight); // Not under roofs / trees
        #else
            float openSky  = 1.0; // No sky light to rely on in the Nether / End
        #endif

        // ---- General damp ground (real rain only) ----
        float wetSurf = wetness * openSky * mix(0.5, 1.0, upFacing);
        material.albedo    = clamp01(mix(material.albedo, material.albedo * 0.96, 0.5 * wetSurf));
        material.roughness = mix(material.roughness, 0.12, 0.5 * wetSurf);

        // ---- Puddle blobs ----
        vec2 pCoord = (wPos.xz + 13.0 * floor(wPos.y + 0.01)) / (PUDDLE_SCALE * 40.0);
        float blob  = textureLod(noisetex, pCoord, 0).r * 0.7 +
                      textureLod(noisetex, pCoord * 2.7 + 0.37, 0).r * 0.3;

        float edge = mix(0.78, 1.0 - PUDDLE_COVERAGE, clamp01(puddleWet * 1.5));
        float puddle = smoothstep(edge, edge + 0.09, blob) * upFacing * openSky * linearStep(0.02, 0.25, puddleWet);

        if (puddle > 0.001) {
            // Wet earth: keep the ground texture, darken it only slightly (stays see-through)
            float depthF = linearStep(edge, edge + 0.2, blob); // puddle centre is wetter than its rim
            // Only a light, slightly cool tint: block colours stay the same, the water film just looks thin and see-through
            float wetDark = 0.94 + 0.03 * (1.0 - depthF);
            vec3 filmTint = mix(vec3(1.0), vec3(0.92, 0.96, 1.0), 0.6);
            material.albedo = clamp01(mix(material.albedo, material.albedo * wetDark * filmTint, puddle));

            // ---------------------------------------------------------------
            // Gloss: roughness floor of 0.08 so PBR texture micro-detail is
            // still lit and visible — avoids the "pure mirror / blank surface"
            // look at high permanent puddle amounts.
            // depthF drives how glossy the puddle centre is vs its rim.
            // ---------------------------------------------------------------
            float targetRoughness = mix(0.05, 0.015, depthF); // rim: 0.05, centre: 0.015 (glossy)
            material.roughness = mix(material.roughness, targetRoughness,
                                     puddle * (0.6 + 0.4 * depthF));
            material.f0 = mix(material.f0, 0.045, puddle);

            // ---- Ripples (only while it's actually raining, subtle) ----
            vec3 nWorld = vec3(0.0, 1.0, 0.0);

            #if PUDDLE_RIPPLES == 1
                if (rainFactor > 0.01) {
                    vec2 grad = vec2(0.0);
                    for (int i = 0; i < 2; i++) {
                        vec2 q = wPos.xz * (1.7 + 0.9 * float(i)) + 17.3 * float(i);
                        vec2 cell = floor(q);
                        vec2 f = fract(q) - 0.5;

                        float h1 = fract(sin(dot(cell, vec2(127.1, 311.7))) * 43758.5453);
                        float h2 = fract(sin(dot(cell, vec2(269.5, 183.3))) * 43758.5453);
                        float h3 = fract(sin(dot(cell, vec2(419.2, 371.9))) * 43758.5453);

                        vec2 d = f - (vec2(h2, h3) - 0.5) * 0.5;
                        float dist  = length(d);
                        float phase = fract(frameTimeCounter * (0.7 + 0.4 * h1) + h1 * 7.0);
                        float ring  = dist - phase * 0.48;
                        float env   = exp(-pow2(ring * 14.0)) * pow2(1.0 - phase);

                        grad += (d / (dist + 1e-4)) * cos(ring * 45.0) * env;
                    }
                    nWorld = normalize(vec3(-0.09 * rainFactor * grad.x, 1.0, -0.09 * rainFactor * grad.y));
                }
            #endif

            // ---------------------------------------------------------------
            // Normal blend fix:
            // Instead of fully replacing the PBR normal with the flat water
            // surface, we blend them. The PBR detail is kept at (1 - puddleNormalStr)
            // so block texture bumps stay subtly visible through the water film.
            //
            // puddleNormalStr: at puddle centre (depthF=1) → 0.80 (mostly water),
            //                  at puddle rim   (depthF=0) → 0.45 (half-half).
            // This means even at 100% permanent puddle the texture still shows.
            // ---------------------------------------------------------------
            float puddleNormalStr = puddle * mix(0.45, 0.80, depthF);

            vec3 nView = mat3(gbufferModelView) * nWorld;
            material.normalM = normalize(mix(material.normalM, nView, puddleNormalStr));
        }
    }
}
#endif
