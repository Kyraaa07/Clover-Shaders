# Clover Shaders v2.0

**by Kyraaa**

---

## 🇮🇩 Bahasa Indonesia

Clover Shaders v2.0 adalah shader pack Minecraft dengan pencahayaan, langit, dan efek yang bisa diatur lewat menu.

### Fitur

- **Awan Blocky** — awan bulat lembut dengan bayangan antar-awan, pemudaran ke warna langit, dan perilaku saat hujan. Opsi: Cloud Quality (Fast / Balanced / High), Scale, Height, Thickness, Speed, Opacity, Brightness.
- **Awan Realist** — awan volumetrik yang lembut dan realistis.
- **Pilihan jenis awan** ada di layar *Clouds* (Realist / Blocky / Off).
- **Profil grafik**: Potato, Low, Medium, High, Very High, Extreme.
- **Portal Enhance** — portal Nether dan End memancarkan cahaya sesuai warnanya. Nether portal dengan api ungu, end portal dengan langit End dan bintang jatuh.
- **Fireflies (Beauty Night)** — kunang-kunang malam hari yang memberi sedikit cahaya.
- Opsi tambahan: Motion Blur, Wind Movement, pengaturan air, Lens Flare, Vignette, dan lainnya.

### Cara install

1. Taruh file `.zip` ke folder `shaderpacks` Minecraft.
2. Buka *Options → Video Settings → Shader Packs* lalu pilih Clover Shaders v2.0.
3. Butuh Iris (atau OptiFine). Fitur LOD butuh Voxy.

### Tips

- Kalau awan terlalu terang atau gelap, atur *Cloud Brightness*.
- Kalau FPS turun, turunkan *Cloud Quality* ke Fast atau pakai preset grafik yang lebih rendah.

---

## 🇬🇧 English

Clover Shaders v2.0 is a Minecraft shader pack with configurable lighting, sky and effects.

### Features

- **Blocky clouds** — soft rounded clouds with cloud self-shadowing, sky fade and rain behaviour. Options: Cloud Quality (Fast / Balanced / High), Scale, Height, Thickness, Speed, Opacity, Brightness.
- **Realist clouds** — soft, realistic volumetric clouds.
- **Cloud type selector** lives in the *Clouds* screen (Realist / Blocky / Off).
- **Portal Enhance** — Nether and End portals emit light matching their colour. Nether portals get purple flames, End portals get the End sky and shooting stars.
- **Fireflies (Beauty Night)** — fireflies drift around at night and give off a little light.
- More options: Motion Blur, Wind Movement, water settings, Lens Flare, Vignette and more.

### Installation

1. Put the `.zip` into your Minecraft `shaderpacks` folder.
2. Go to *Options → Video Settings → Shader Packs* and select Clover Shaders v2.0.
3. Requires Iris (or OptiFine). LOD support requires Voxy.

### Tips

- If the clouds look too bright or too dark, adjust *Cloud Brightness*.
- If your FPS drops, set *Cloud Quality* to Fast or use a lower graphics preset.

---

Parts of the cloud code are ported from Complementary Reimagined and BSL Shaders (see the headers in `lib/atmospherics/`).
