// Grass blade shadows - vertex stage helper (shadow_solid / shadow_cutout, Overworld only).
// Hands the geometry shader (grassBladesShadowGS.glsl) the same per-vertex data that
// gbuffers_solid.glsl gives its geometry shader, so both passes generate identical blades.
// Included at global scope in the shadow vertex shaders; call gbsVertexData() from main().

#include "/lib/settings/natureSettings.glsl"

uniform mat4 shadowModelViewInverse;

attribute float mc_Entity;
attribute vec3  at_midBlock;

flat out int vs_kind;     // 0 none, 1 grass block top, 2 short grass/fern, 3 tall grass (lower), 4 tall grass (upper)
out vec3  vs_playerPos;   // un-waved player-space position (same space the gbuffers pass uses)
out vec3  vs_midBlock;    // at_midBlock / 64
out float vs_lmY;         // sky light, 0..1

void gbsVertexData() {
    vs_kind      = 0;
    vs_playerPos = vec3(0.0);
    vs_midBlock  = vec3(0.0);
    vs_lmY       = 1.0;

    #if GRASS_BLADES == 1 && GRASS_SHADOWS == 1
        int rawID = int(mc_Entity);
        // everything that is not grass pays for nothing but this compare
        if (rawID == 1101 || (rawID >= 6 && rawID <= 8)) {
            vs_playerPos = (shadowModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
            vs_midBlock  = at_midBlock.xyz * (1.0 / 64.0);
            vs_lmY       = clamp(((gl_TextureMatrix[1] * gl_MultiTexCoord1).y - 0.03125) * 1.06667, 0.0, 1.0);

            vec3 worldNormal = mat3(shadowModelViewInverse) * (gl_NormalMatrix * gl_Normal);
            if (rawID == 1101 && worldNormal.y > 0.9) vs_kind = 1;
            else if (rawID == 6) vs_kind = 2;
            else if (rawID == 7) vs_kind = 3;
            else if (rawID == 8) vs_kind = 4;
        }
    #endif
}
