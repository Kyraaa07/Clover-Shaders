#ifndef WATER_WAKE_ENTITIES_GLSL
#define WATER_WAKE_ENTITIES_GLSL

// Water Wake: entity side. Included only by gbuffers_entities.
// Every visible entity fragment near the camera writes the lowest / highest world Y it reaches into the
// cell it covers (2x2 cells for a slightly fatter footprint). The water pass later checks whether that
// Y range touches the water surface, and the prepare pass turns the result into waves.

#include "/lib/settings/effectsSettings.glsl"
#include "/lib/materials/helpers/waterSim.glsl"

#if defined GBUFFERS_ENTITIES && WATER_WAKE == 1 && WATER_WAKE_ENTITIES == 1

layout(r32i) coherent uniform iimage2D wk_ent_min_img;
layout(r32i) coherent uniform iimage2D wk_ent_max_img;

void CaptureEntityForWake(vec3 posAbs) {
    vec2 rel = posAbs.xz - cameraPosition.xz;
    if (abs(rel.x) > 24.0 || abs(rel.y) > 24.0) return; // simulated area is about 25 blocks around the camera

    vec2 cellF = posAbs.xz / SIM_CELL - simCameraCell(cameraPosition) + SIM_RES * 0.5;
    ivec2 base = ivec2(floor(cellF - 0.5));
    int yLo = int(floor(posAbs.y * WK_Y_SCALE));
    int yHi = int(ceil(posAbs.y * WK_Y_SCALE));

    for (int i = 0; i < 4; i++) {
        ivec2 c = base + ivec2(i & 1, i >> 1);
        if (c.x < 0 || c.y < 0 || c.x >= int(SIM_RES) || c.y >= int(SIM_RES)) continue;
        imageAtomicMin(wk_ent_min_img, c, yLo);
        imageAtomicMax(wk_ent_max_img, c, yHi);
    }
}

#endif
#endif
