// Grass blade shadows - geometry stage (shadow_solid / shadow_cutout, Overworld only).
//
// Rebuilds the very same blades as the gbuffers geometry shader (same seed, same wind, same player bend, because
// it runs the same gbMakeBlade()) and writes them into the shadow map. Only the output differs:
//   - no colours / lighting, just positions
//   - ribbons are turned a little toward the light and widened, because a ribbon seen edge-on from the sun or
//     thinner than a shadow texel would leave no shadow at all
//   - GRASS_SHADOW_DETAIL 0 (Fast) only casts every second blade, with wider ribbons
//
// Needs GRASS_BLADES = 1, GRASS_SHADOWS = 1 and SHADOWS = 1, otherwise this stage is a pure pass-through.

#include "/lib/common.glsl"
#include "/lib/settings/lightingSettings.glsl"
#include "/lib/settings/natureSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"
#include "/lib/util/grassBlades.glsl"

#if !(GRASS_BLADES == 1 && GRASS_SHADOWS == 1 && SHADOWS == 1)
    // pass-through only: one invocation is enough
    #undef GB_INV
    #define GB_INV 1
#endif

// How much wider the shadow ribbons are than the visible blades
#if GRASS_SHADOW_DETAIL == 0
    #define GBS_WIDTH_MULT 2.0
#else
    #define GBS_WIDTH_MULT 1.4
#endif
// 0 = keep the visible ribbon direction, 1 = always face the light
#define GBS_LIGHT_FACING 0.7

layout(triangles, invocations = GB_INV) in;
layout(triangle_strip, max_vertices = GB_MAXV) out;

flat in int vs_kind[];
in vec3  vs_playerPos[];
in vec3  vs_midBlock[];
in float vs_lmY[];
#ifdef SHADOW_CUTOUT
    in vec2 vs_texcoord[];

    out vec2  texcoord;
    out float bladeFlag; // 1 = generated blade (skips the alpha test in the fragment shader)
#endif

void gbsPassVertex(int i) {
    gl_Position = gl_in[i].gl_Position;
    #ifdef SHADOW_CUTOUT
        texcoord  = vs_texcoord[i];
        bladeFlag = 0.0;
    #endif
    EmitVertex();
}

// player space -> distorted shadow clip space (mirrors applyVertexTransform() + getDistortedPos() of the vertex stage)
void gbsEmitBladeVertex(vec3 playerPos) {
    vec3 shadowView = mat3(shadowModelView) * playerPos + shadowModelView[3].xyz;
    vec3 pos = diag(shadowProjection) * shadowView;
    pos.z += shadowProjection[3].z;
    gl_Position = vec4(getDistortedPos(pos), 1.0);
    #ifdef SHADOW_CUTOUT
        texcoord  = vs_texcoord[0];
        bladeFlag = 1.0;
    #endif
    EmitVertex();
}

void main() {
    int kind = vs_kind[0];

    vec3 p0 = vs_playerPos[0];
    vec3 p1 = vs_playerPos[1];
    vec3 p2 = vs_playerPos[2];
    vec3 triCenter = (p0 + p1 + p2) * (1.0 / 3.0);
    float dist = length(triCenter);

    #if GRASS_BLADES == 1 && GRASS_SHADOWS == 1 && SHADOWS == 1
        bool inRange = kind > 0 && dist < float(GRASS_RENDER_RADIUS);
        #if GRASS_PLANTS_AS_BLADES == 1
            bool replaced = kind >= 2 && inRange;
        #else
            bool replaced = false;
            if (kind >= 2) inRange = false;
        #endif
    #else
        bool inRange = false;
        bool replaced = false;
    #endif

    // 1) the original triangle (flat grass block, every other block, plants out of blade range)
    if (gl_InvocationID == 0 && !replaced) {
        gbsPassVertex(0);
        gbsPassVertex(1);
        gbsPassVertex(2);
        EndPrimitive();
    }

    #if GRASS_BLADES == 1 && GRASS_SHADOWS == 1 && SHADOWS == 1
    if (!inRange || kind == 4) return;

    // 2) blades: identical seed and counts to the gbuffers pass so shadow and blade line up
    vec3 cW = triCenter + cameraPosition;
    vec2 stableXZ = floor(cW.xz + 0.5);
    float stableY  = floor(cW.y  + 0.5);
    vec2 seed = stableXZ * 1.97 + stableY * 3.13;

    int wantBlades = kind == 1 ? GB_TRI_BLADES : max(GB_TRI_BLADES / 2, 1);

    // plant block centre, sign-agnostic for at_midBlock (the centre sits at fract == 0.5)
    vec3 plantCenter = vec3(0.0);
    if (kind >= 2) {
        vec3 wv = p0 + cameraPosition;
        vec3 mb = vs_midBlock[0];
        vec3 cA = wv + mb;
        vec3 cB = wv - mb;
        float eA = dot(abs(fract(cA.xz) - 0.5), vec2(1.0));
        float eB = dot(abs(fract(cB.xz) - 0.5), vec2(1.0));
        plantCenter = eA <= eB ? cA : cB;
    }

    GbWind wind = gbGetWind();

    // horizontal direction toward the light (player space); the ribbons turn to face it
    vec3 toLight = normalize(shadowModelViewInverse[2].xyz);
    float lightH = length(toLight.xz);
    vec2 lightSide = lightH > 0.05 ? vec2(-toLight.z, toLight.x) / lightH : vec2(0.0);

    float thin = smoothstep(float(GRASS_RENDER_RADIUS) * 0.45, float(GRASS_RENDER_RADIUS), dist);
    float keepProb = 1.0 - 0.7 * thin;

    for (int b = 0; b < GB_BPI; b++) {
        int k = gl_InvocationID * GB_BPI + b;
        if (k >= wantBlades) break;

        #if GRASS_SHADOW_DETAIL == 0
            if ((k & 1) == 1) continue; // Fast: every second blade
        #endif

        vec2 s = seed + float(k) * vec2(1.618, 2.414);
        vec2 r = gbHash2(s);
        float rBlade = gbHash(s + 9.1);
        float rKeep  = gbHash(s + 21.7);

        if (rKeep > keepProb) continue;

        vec3 basePlayer;
        float baseLmY;
        if (kind == 1) {
            vec2 q = r;
            if (q.x + q.y > 1.0) q = 1.0 - q;
            vec3 bw = vec3(1.0 - q.x - q.y, q.x, q.y);
            basePlayer = p0 * bw.x + p1 * bw.y + p2 * bw.z;
            baseLmY    = vs_lmY[0] * bw.x + vs_lmY[1] * bw.y + vs_lmY[2] * bw.z;
        } else {
            vec3 wp = vec3(plantCenter.x + (r.x - 0.5) * 0.9, plantCenter.y - 0.5, plantCenter.z + (r.y - 0.5) * 0.9);
            basePlayer = wp - cameraPosition;
            baseLmY    = (vs_lmY[0] + vs_lmY[1] + vs_lmY[2]) * (1.0 / 3.0);
        }

        vec3 baseWorld = basePlayer + cameraPosition;
        GbBlade B = gbMakeBlade(basePlayer, baseWorld, baseLmY, kind, rBlade, rKeep, dist, wind);
        if (!B.alive) continue;

        float widthMul = B.widthScale * inversesqrt(max(keepProb, 0.3)) * GBS_WIDTH_MULT;

        vec2 side = B.side;
        if (lightH > 0.05) {
            vec2 ls = dot(lightSide, side) < 0.0 ? -lightSide : lightSide;
            side = normalize(mix(side, ls, GBS_LIGHT_FACING));
        }
        vec3 sideV = vec3(side.x, 0.0, side.y);

        for (int i = 0; i < GB_SEG; i++) {
            float t = float(i) / float(GB_SEG);
            float hw = gbWidthAt(t, GB_TIP_W) * widthMul;
            vec3 pc = B.pts[i];
            gbsEmitBladeVertex(pc - sideV * hw);
            gbsEmitBladeVertex(pc + sideV * hw);
        }
        gbsEmitBladeVertex(B.pts[GB_SEG]);
        EndPrimitive();
    }
    #endif
}
