#ifndef ENCHANT_PALETTE_GLSL
#define ENCHANT_PALETTE_GLSL

#include "/lib/settings/effectsSettings.glsl"

// Cycling neon palette, 4 colours per theme (see ENCHANT_COLOR_THEME)
vec3 enchantPalette(float t) {
#if ENCHANT_COLOR_THEME == 1      // Cyber Blue
    const vec3 c0 = vec3(0.05, 0.20, 1.00); // electric blue
    const vec3 c1 = vec3(0.00, 0.55, 1.00); // azure
    const vec3 c2 = vec3(0.00, 0.95, 1.00); // neon cyan
    const vec3 c3 = vec3(0.45, 0.65, 1.00); // ice blue
#elif ENCHANT_COLOR_THEME == 2    // Cyber Green
    const vec3 c0 = vec3(0.00, 0.85, 0.25); // emerald
    const vec3 c1 = vec3(0.20, 1.00, 0.35); // neon green
    const vec3 c2 = vec3(0.65, 1.00, 0.15); // acid lime
    const vec3 c3 = vec3(0.00, 0.95, 0.65); // mint teal
#elif ENCHANT_COLOR_THEME == 3    // Cyber Red
    const vec3 c0 = vec3(0.90, 0.03, 0.10); // crimson
    const vec3 c1 = vec3(1.00, 0.12, 0.18); // neon red
    const vec3 c2 = vec3(1.00, 0.15, 0.45); // hot pink-red
    const vec3 c3 = vec3(1.00, 0.35, 0.05); // orange-red
#elif ENCHANT_COLOR_THEME == 4    // Golden
    const vec3 c0 = vec3(0.85, 0.55, 0.05); // deep gold
    const vec3 c1 = vec3(1.00, 0.75, 0.10); // gold
    const vec3 c2 = vec3(1.00, 0.88, 0.35); // bright yellow-gold
    const vec3 c3 = vec3(1.00, 0.55, 0.08); // amber
#else                             // Cyber Purple (default)
    const vec3 c0 = vec3(0.25, 0.08, 1.00); // electric indigo
    const vec3 c1 = vec3(0.72, 0.15, 1.00); // neon purple
    const vec3 c2 = vec3(1.00, 0.18, 0.90); // neon magenta
    const vec3 c3 = vec3(0.42, 0.52, 1.00); // electric blue-violet
#endif
    t = fract(t) * 4.0;
    float f = smoothstep(0.0, 1.0, fract(t));
    int   i = int(floor(t));
    vec3 a = (i == 0) ? c0 : (i == 1) ? c1 : (i == 2) ? c2 : c3;
    vec3 b = (i == 0) ? c1 : (i == 1) ? c2 : (i == 2) ? c3 : c0;
    return mix(a, b, f);
}

#endif
