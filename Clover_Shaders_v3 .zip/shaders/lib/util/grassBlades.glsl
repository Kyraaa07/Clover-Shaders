// ============================================================================
//  Grassier Blades for Clover  -  geometry shader part
//  Ported from the logic of the "Grassier Grass" Fabric mod (grass_blades.vsh):
//    - blades are stacked strips following a cubic Bezier spine
//    - regional height noise + per-blade height/width variation
//    - Voronoi clumps (inward resting lean, rim sparsity, width/lean cohesion)
//    - scrolling wind noise, wind curve, rest curve, tip flutter
//    - camera facing width turn
//    - base -> tip brightness gradient, per-blade hue jitter, wind shimmer
//    - player interaction (reuses Clover's Player Grass Bend)
//  The mod bakes blades on the CPU; a shader pack cannot, so here every grass
//  top face (and optionally short/tall grass + ferns) is expanded by a geometry
//  shader instead.  Needs Iris with geometry shader support (GLSL 400).
// ============================================================================

// ---------------- compile-time budget (must be literals for layout()) ----------------
#ifdef POM
    #define GB_COMPS 35
#else
    #define GB_COMPS 24
#endif

#if GRASS_BLADE_SEGMENTS == 2
    #define GB_VPB 5
    #ifdef POM
        #define GB_BPI 5
        #define GB_MAXV 28
    #else
        #define GB_BPI 7
        #define GB_MAXV 38
    #endif
#elif GRASS_BLADE_SEGMENTS == 4
    #define GB_VPB 9
    #ifdef POM
        #define GB_BPI 2
        #define GB_MAXV 21
    #else
        #define GB_BPI 4
        #define GB_MAXV 39
    #endif
#else
    #define GB_VPB 7
    #ifdef POM
        #define GB_BPI 3
        #define GB_MAXV 24
    #else
        #define GB_BPI 5
        #define GB_MAXV 38
    #endif
#endif

#define GB_SEG ((GB_VPB - 1) / 2)

// blades wanted per triangle (a grass top face is 2 triangles)
#define GB_TRI_BLADES (GRASS_BLADE_DENSITY / 2)

#if GB_TRI_BLADES <= GB_BPI
    #define GB_INV 1
#elif GB_TRI_BLADES <= GB_BPI * 2
    #define GB_INV 2
#elif GB_TRI_BLADES <= GB_BPI * 3
    #define GB_INV 3
#elif GB_TRI_BLADES <= GB_BPI * 4
    #define GB_INV 4
#elif GB_TRI_BLADES <= GB_BPI * 5
    #define GB_INV 5
#elif GB_TRI_BLADES <= GB_BPI * 6
    #define GB_INV 6
#elif GB_TRI_BLADES <= GB_BPI * 7
    #define GB_INV 7
#else
    #define GB_INV 8
#endif

// blades off: the geometry shader is a pure pass-through, one invocation is enough
#if GRASS_BLADES == 0
    #undef GB_INV
    #define GB_INV 1
#endif

// ---------------- constants mirrored from grass_blades.vsh / GrassGeometry ----------------
const float GB_PI2 = 6.2831853;
const float GB_MAX_ROT = 1.05;

const float GB_BASE_W = 0.040;
const float GB_MID_W  = 0.050;
const float GB_TIP_W  = 0.013;
const float GB_SPLIT  = 2.0 / 3.0;
const float GB_TAPER_SCALE = 0.8947368;

const float GB_PER_BLADE_H_MIN = 0.88;
const float GB_PER_BLADE_H_MAX = 1.14;
const float GB_PER_BLADE_W_COMP = 0.12;
const float GB_H_NOISE_CONTRAST = 1.35;
const float GB_H_NOISE_SHORT = 0.10;
const float GB_H_NOISE_TALL = 1.28;
const float GB_REGIONAL_LEN = 0.59;
const float GB_MIN_LEN = 0.02;
const float GB_TALL_MULT = 3.0;
const float GB_DEFAULT_ANIM_LEN = 0.5075;

const float GB_LEAN_RESP_MIN = 0.30;
const float GB_LEAN_RESP_MAX = 0.58;
const float GB_TRAIL_WIND_SUPP = 0.95;
const float GB_TRAIL_CURVE_SUPP = 0.90;
const float GB_TRAIL_FLUTTER_SUPP = 1.0;

const float GB_BEND_AMOUNT = 0.10;
const float GB_BEND_LOWER_H = 0.45;
const float GB_BEND_UPPER_H = 0.82;
const float GB_BEND_UPPER_FRAC = 0.22;

const float GB_CURVE_ROT = 0.40;
const float GB_CURVE_PEAK = 0.52;
const float GB_CURVE_LOWER = 0.30;
const float GB_CURVE_UPPER = 0.72;

const float GB_REST_MIN = -0.52;
const float GB_REST_MAX = 0.52;
const float GB_REST_FADE_END = 0.35;

const float GB_CLUMP_WIDTH_MIN = 0.92;
const float GB_CLUMP_WIDTH_MAX = 1.08;
const float GB_CLUMP_LEAN_COHESION = 0.42;
const float GB_CLUMP_REST_COHESION = 0.55;
const float GB_CLUMP_INWARD_ROT = 0.21;
const float GB_CLUMP_INWARD_CURVE = 0.55;
const float GB_CLUMP_SIZE = 2.67;      // blocks per Voronoi cell (mod: 16 / 6)

const float GB_CAM_FACE = 0.38;
const float GB_CAM_START = 2.0;
const float GB_CAM_END = 42.0;

// ---------------- noise ----------------
float gbHash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 gbHash2(vec2 p) {
    float a = gbHash(p);
    return vec2(a, gbHash(p + a * 17.31 + 5.17));
}

float gbNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = gbHash(i);
    float b = gbHash(i + vec2(1.0, 0.0));
    float c = gbHash(i + vec2(0.0, 1.0));
    float d = gbHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Voronoi clump: returns (restRandom, widthRandom, distanceToCentre 0..1), and direction to centre
vec3 gbClump(vec2 w, out vec2 toCentre) {
    vec2 p = w / GB_CLUMP_SIZE;
    vec2 cell = floor(p);
    vec2 f = fract(p);
    float best = 8.0;
    vec2 bestCell = cell;
    vec2 bestVec = vec2(0.0);
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 g = vec2(float(x), float(y));
            vec2 o = 0.5 + (gbHash2(cell + g) - 0.5) * 0.72;
            vec2 d = g + o - f;
            float dd = dot(d, d);
            if (dd < best) { best = dd; bestCell = cell + g; bestVec = d; }
        }
    }
    float dist = clamp(sqrt(best) / 0.75, 0.0, 1.0);
    float len = length(bestVec);
    toCentre = len > 1e-4 ? bestVec / len : vec2(0.0);
    vec2 r = gbHash2(bestCell + 31.7);
    return vec3(r, dist);
}

// ---------------- blade math ----------------
vec3 gbBezier(vec3 p0, vec3 p1, vec3 p2, vec3 p3, float t) {
    float it = 1.0 - t;
    return it*it*it*p0 + 3.0*it*it*t*p1 + 3.0*it*t*t*p2 + t*t*t*p3;
}

vec3 gbSpinePoint(vec3 basePoint, vec2 dir, float visualLen, float animLen, float h, float rot) {
    vec3 pt = basePoint;
    pt.xz += dir * (sin(rot) * animLen * h);
    pt.y  += cos(rot) * visualLen * h;
    return pt;
}

float gbCurveResponse(float rot) {
    float rise = smoothstep(0.0, GB_CURVE_PEAK, rot);
    float fall = 1.0 - smoothstep(GB_CURVE_PEAK, GB_MAX_ROT, rot);
    return rise * fall;
}

vec2 gbMixDir(vec2 a, vec2 b, float amount) {
    float ang = atan(a.x * b.y - a.y * b.x, dot(a, b)) * clamp(amount, 0.0, 1.0);
    float s = sin(ang), c = cos(ang);
    return vec2(a.x * c - a.y * s, a.x * s + a.y * c);
}

float gbWidthAt(float h, float tipW) {
    if (h <= GB_SPLIT) return mix(GB_BASE_W, GB_MID_W, h / GB_SPLIT);
    return mix(GB_MID_W, tipW, (h - GB_SPLIT) / (1.0 - GB_SPLIT));
}

vec3 gbHueShift(vec3 c, float angle) {
    const mat3 toYIQ = mat3(0.299, 0.596, 0.211, 0.587, -0.274, -0.523, 0.114, -0.322, 0.312);
    const mat3 toRGB = mat3(1.0, 1.0, 1.0, 0.956, -0.272, -1.106, 0.621, -0.647, 1.703);
    vec3 yiq = toYIQ * c;
    float s = sin(angle), co = cos(angle);
    yiq.yz = vec2(yiq.y * co - yiq.z * s, yiq.y * s + yiq.z * co);
    return max(toRGB * yiq, 0.0);
}

// Saturation: scale chroma around the grey axis (luma-preserving)
vec3 gbSaturate(vec3 c, float sat) {
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    return max(mix(vec3(luma), c, sat), 0.0);
}

// Vibrance: boosts muted colours more than already-vivid ones
vec3 gbVibrance(vec3 c, float vib) {
    float luma   = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float maxC   = max(c.r, max(c.g, c.b));
    float minC   = min(c.r, min(c.g, c.b));
    float chroma = maxC - minC;                  // 0 = grey, 1 = fully saturated
    // Muted colours (low chroma) get a bigger boost; vivid colours get almost none
    float boost  = vib * (1.0 - chroma);
    return max(mix(vec3(luma), c, 1.0 + boost), 0.0);
}

// Wind shared by every blade this frame (cheap, computed once per invocation)
struct GbWind {
    vec2  dir;
    vec2  scroll;
    float intensity;   // 0..5, same range as the mod
};

GbWind gbGetWind() {
    GbWind w;
    float t = frameTimeCounter;
    // dynamic wind: direction drifts slowly, strength breathes, rain makes it gustier
    float ang = 0.35 * sin(t * 0.045) + 0.18 * sin(t * 0.11 + 1.7);
    w.dir = vec2(cos(ang), sin(ang));
    float breathe = 0.8 + 0.2 * sin(t * 0.07 + 0.6) * 0.5 + 0.1 * sin(t * 0.19);
    w.intensity = GRASS_WIND_SPEED * breathe * (1.0 + 0.6 * wetness);
    w.scroll = w.dir * t * (1.2 + 2.2 * clamp(w.intensity, 0.0, 2.0));
    return w;
}

// Player interaction: reuses Clover's Player Grass Bend maths.
// returns strength 0..1 and direction away from the player.
float gbPlayerPush(vec3 basePlayerPos, out vec2 away) {
    away = vec2(0.0);
    #if PLAYER_GRASS_BEND == 1
        vec3 eye = dot(relativeEyePosition, relativeEyePosition) > 100.0 ? vec3(0.0) : -relativeEyePosition;
        vec3 rel = basePlayerPos - (eye - vec3(0.0, 1.62, 0.0));
        if (rel.y > -0.6 && rel.y < 2.2) {
            float d = length(rel.xz);
            float push = (1.0 - smoothstep(0.0, PLAYER_GRASS_RADIUS, d)) * PLAYER_GRASS_STRENGTH;
            away = d > 1e-3 ? rel.xz / d : vec2(0.0);
            return clamp(push, 0.0, 1.0);
        }
    #endif
    return 0.0;
}

// Everything the emit loop needs from one blade
struct GbBlade {
    vec3  pts[GB_SEG + 1];   // spine centre points (player space), last one is the tip
    vec2  side;              // unit side direction
    float widthScale;        // final half-width multiplier (blade-level)
    vec3  tint;              // per-blade colour multiplier (hue jitter, brightness, wave)
    float gradBase;
    float random;
    bool  alive;
};

// kind: 1 = grass block top, 2 = short grass/fern, 3 = lower half of tall grass
GbBlade gbMakeBlade(vec3 basePlayer, vec3 baseWorld, float skyLight, int kind, float bladeRand,
                    float keepRand, float distToCam, GbWind wind) {
    GbBlade B;
    B.alive = true;
    B.random = bladeRand;

    vec2 w = baseWorld.xz;

    // --- clump + regional noise ---
    vec2 toCentre;
    vec3 clump = gbClump(w, toCentre);
    float clumpInfluence = 0.6 + 0.4 * (1.0 - smoothstep(0.25, 0.85, clump.z));

    // sparsity: remove blades from the rim of each clump inward
    float rimScore = clump.z * 0.85 + keepRand * 0.15;
    if (rimScore > 1.0 - GRASS_SPARSITY) { B.alive = false; return B; }

    float hn = gbNoise(w * 0.14 + 11.3);
    hn = clamp((hn - 0.5) * GB_H_NOISE_CONTRAST + 0.5, 0.0, 1.0);
    hn = smoothstep(0.0, 1.0, hn);

    float heightMulti = mix(GB_H_NOISE_SHORT, GB_H_NOISE_TALL, hn);
    float lenMult = kind == 3 ? GB_TALL_MULT : 1.0;
    float baseLen = GRASS_BLADE_HEIGHT * lenMult;

    float shapedRand = smoothstep(0.0, 1.0, bladeRand);
    float perBladeH = mix(GB_PER_BLADE_H_MIN, GB_PER_BLADE_H_MAX, shapedRand);
    float perBladeW = mix(1.0 + GB_PER_BLADE_W_COMP, 1.0 - GB_PER_BLADE_W_COMP, shapedRand);

    float clumpWidth = mix(1.0, mix(GB_CLUMP_WIDTH_MIN, GB_CLUMP_WIDTH_MAX, smoothstep(0.0, 1.0, clump.y)), clumpInfluence);
    float regionalWidth = mix(1.0, 1.0, hn) * clumpWidth * perBladeW;

    float extra = (baseLen * (heightMulti - 1.0) * GB_REGIONAL_LEN + baseLen * (perBladeH - 1.0)) * GRASS_HEIGHT_VARIATION;
    float bladeLen = max(baseLen + extra, GB_MIN_LEN);
    float animLen = max(bladeLen, GB_DEFAULT_ANIM_LEN * lenMult);

    // --- wind ---
    float windAmount = clamp(wind.intensity * clamp(skyLight, 0.0, 1.0), 0.0, 1.0);
    float noiseBias = clamp(wind.intensity / 5.0, 0.0, 1.0);
    vec2 wn = (w + wind.scroll) ;
    float windNoise = 0.7 * gbNoise(wn * 0.15) + 0.3 * gbNoise(wn * 0.45 + 7.1);
    windNoise = clamp((windNoise - 0.5) * 1.6 + 0.5, 0.0, 1.0);
    float localWind = mix(windNoise, 1.0, noiseBias);

    float leanRandom = mix(gbHash(w + vec2(43.17, 11.91)), clump.y, GB_CLUMP_LEAN_COHESION * clumpInfluence);
    float leanResponse = mix(GB_LEAN_RESP_MIN, GB_LEAN_RESP_MAX, leanRandom);
    float resisted = localWind * windAmount * leanResponse;
    float windRot = clamp(resisted, 0.0, 1.0) * GB_MAX_ROT;

    // --- player interaction ---
    // FIX Bug 2: separate push query from direction assignment.
    // Previously trailDir was passed as wind.dir into gbPlayerPush (out param),
    // so when push == 0 the out param wrote vec2(0) but trailDir stayed as wind.dir
    // only via the guard below — causing a hard snap at the radius edge that made
    // blades jitter in third-person view and when the camera panned.
    // Now we capture push + raw away direction separately and smooth-blend.
    vec2 trailDir = wind.dir;
    float trailEffect = 0.0;
    {
        vec2 rawAway = vec2(0.0);
        float rawPush = gbPlayerPush(basePlayer, rawAway);
        if (rawPush > 0.001 && dot(rawAway, rawAway) > 1e-6) {
            // Smooth the direction blend so there's no hard pop at the radius edge
            float blend = smoothstep(0.0, 0.08, rawPush);
            trailDir   = normalize(mix(wind.dir, rawAway, blend));
            trailEffect = rawPush;
        }
    }
    float trailWindMul = 1.0 - trailEffect * GB_TRAIL_WIND_SUPP;
    resisted *= trailWindMul;
    windRot *= trailWindMul;
    float trailRot = trailEffect * GB_MAX_ROT;

    // --- resting lean toward the clump centre ---
    float curvedClump = pow(clamp(clump.z, 0.0, 1.0), GB_CLUMP_INWARD_CURVE);
    float inwardRot = curvedClump * GB_CLUMP_INWARD_ROT * (1.0 - windAmount);

    vec2 leanVec = wind.dir * windRot + trailDir * trailRot + toCentre * inwardRot;
    float rotation = clamp(length(leanVec), 0.0, GB_MAX_ROT);

    float activeRot = windRot + trailRot;
    float trailMix = trailRot / max(activeRot, 0.0001);
    vec2 activeDir = gbMixDir(wind.dir, trailDir, trailMix);
    float restLen = length(toCentre);
    vec2 restDir = restLen > 0.001 ? toCentre / restLen : activeDir;
    float dirMix = activeRot / max(inwardRot + activeRot, 0.0001);
    vec2 leanDir = gbMixDir(restDir, activeDir, dirMix);
    vec2 crossLean = vec2(-leanDir.y, leanDir.x);

    float windForce = clamp(max(resisted, trailEffect), 0.0, 1.0);

    // --- Bezier spine ---
    float bendElig = smoothstep(0.0, 0.1, hn);
    if (kind >= 2) bendElig = 1.0;

    float curveRot = GB_CURVE_ROT * gbCurveResponse(rotation) * bendElig;
    curveRot *= 1.0 - trailEffect * GB_TRAIL_CURVE_SUPP;

    float restRand = mix(gbHash(w + vec2(7.13, 91.77)), clump.x, GB_CLUMP_REST_COHESION * clumpInfluence);
    float restFade = 1.0 - smoothstep(0.0, GB_REST_FADE_END, windForce);
    float restRot = mix(GB_REST_MIN, GB_REST_MAX, restRand) * restFade * (bendElig + 0.25);
    restRot *= 1.0 - trailEffect * GB_TRAIL_CURVE_SUPP;

    float tipRot = rotation + curveRot + restRot;

    vec3 baseP = basePlayer;
    vec3 tipP = gbSpinePoint(baseP, leanDir, bladeLen, animLen, 1.0, tipRot);

    // tip flutter
    float calm = 1.0 - smoothstep(0.25, 0.85, windForce);
    float phase = dot(w, vec2(97.0, 151.0));
    float speedStep = floor(mix(58.0, 71.0, gbHash(w + vec2(73.17, 29.43))));
    float flutter = sin(frameTimeCounter * 3.2 * (speedStep / 64.0) + phase);
    float bend = flutter * GB_BEND_AMOUNT * animLen * bendElig * calm;
    bend *= 1.0 - trailEffect * GB_TRAIL_FLUTTER_SUPP;
    vec2 bendOff = crossLean * bend;

    vec3 lowerP = gbSpinePoint(baseP, leanDir, bladeLen, animLen, GB_BEND_LOWER_H,
                               rotation + curveRot * GB_CURVE_LOWER + restRot * GB_CURVE_LOWER);
    vec3 upperP = gbSpinePoint(baseP, leanDir, bladeLen, animLen, GB_BEND_UPPER_H,
                               rotation + curveRot * GB_CURVE_UPPER + restRot * GB_CURVE_UPPER);
    upperP.xz += bendOff * GB_BEND_UPPER_FRAC;
    tipP.xz += bendOff;

    for (int i = 0; i <= GB_SEG; i++) {
        float t = float(i) / float(GB_SEG);
        B.pts[i] = gbBezier(baseP, lowerP, upperP, tipP, t);
    }

    // --- side direction with subtle camera facing ---
    float sideAng = bladeRand * GB_PI2 * 7.0;
    vec2 side = vec2(cos(sideAng), sin(sideAng));
    vec2 toCam = -basePlayer.xz;
    float cd = length(toCam);
    if (cd > 0.001) {
        toCam /= cd;
        vec2 camSide = vec2(-toCam.y, toCam.x);
        if (dot(camSide, side) < 0.0) camSide = -camSide;
        float edgeOn = 1.0 - abs(dot(side, camSide));
        float fade = 1.0 - smoothstep(GB_CAM_START, GB_CAM_END, cd);
        side = normalize(mix(side, camSide, GB_CAM_FACE * edgeOn * fade));
    }
    B.side = side;

    // --- width: density compensation + distance thinning compensation ---
    float densityComp = sqrt(64.0 / float(GRASS_BLADE_DENSITY));
    B.widthScale = GB_TAPER_SCALE * GRASS_BLADE_WIDTH * regionalWidth * densityComp;

    // --- colour: hue jitter (per blade + slow world noise), brightness, wind shimmer ---
    float hueWorld = (gbNoise(w * 0.04 + 3.1) - 0.5) * 0.04 * GB_PI2 * 0.5;
    // Green-shift: push hue slightly toward green (negative hue angle in YIQ = greener)
    float greenShift = -GRASS_GREEN_SHIFT * GB_PI2;
    float hueBlade = (bladeRand * 2.0 - 1.0) * radians(GRASS_HUE_JITTER);
    float waveMul = mix(0.85, 1.0, windNoise);
    B.tint = vec3(waveMul * GRASS_BRIGHTNESS);
    B.random = hueWorld + hueBlade + greenShift;   // reused as the hue angle
    B.gradBase = GRASS_GRADIENT_BASE * 0.75;
    return B;
}
