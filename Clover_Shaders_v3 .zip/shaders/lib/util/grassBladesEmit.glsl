// Emit logic of the grass-blade geometry shader.
// Expects (declared by gbuffers_solid.glsl before including this file):
//   in  : vs_vertexNormal[] vs_vertexTangent[] vs_matID[] vs_texcoord[] vs_glColor[] vs_lmcoord[]
//         vs_kind[] vs_playerPos[] vs_midBlock[]  (+ vs_viewVector/vs_vTexCoord/... with POM)
//   out : vertexNormal vertexTangent matID texcoord glColor lmcoord bladeInfo (+ POM varyings)

void gbPassVertex(int i) {
    gl_Position   = gl_in[i].gl_Position;
    vertexNormal  = vs_vertexNormal[i];
    vertexTangent = vs_vertexTangent[i];
    matID         = vs_matID[i];
    texcoord      = vs_texcoord[i];
    glColor       = vs_glColor[i];
    lmcoord       = vs_lmcoord[i];
    bladeInfo     = vec4(0.0);
    #ifdef GENERATED_NORMALS
        gnMidCoord    = vs_gnMidCoord[i];
        gnAbsMid      = vs_gnAbsMid[i];
    #endif
    #ifdef POM
        viewVector      = vs_viewVector[i];
        vTexCoord       = vs_vTexCoord[i];
        vTexCoordAM     = vs_vTexCoordAM[i];
        signMidCoordPos = vs_signMidCoordPos[i];
    #endif
    EmitVertex();
}

void gbEmitBladeVertex(vec3 playerPos, vec3 color, vec2 tc, vec2 lm, vec3 nrmView, vec4 tanView, float flag) {
    vec4 clip = gbufferProjection * (gbufferModelView * vec4(playerPos, 1.0));
    clip.xy = taaJitter(clip.xy, clip.w);
    gl_Position   = clip;
    vertexNormal  = nrmView;
    vertexTangent = tanView;
    matID         = 2;              // foliage material (subsurface etc.)
    texcoord      = tc;
    glColor       = vec4(color, 1.0);
    lmcoord       = lm;
    bladeInfo     = vec4(0.0, 0.0, 0.0, flag);
    #ifdef GENERATED_NORMALS
        gnMidCoord    = vec2(0.5);   // blades skip generated normals
        gnAbsMid      = vec2(0.0);
    #endif
    #ifdef POM
        viewVector      = vs_viewVector[0];
        vTexCoord       = vs_vTexCoord[0];
        vTexCoordAM     = vs_vTexCoordAM[0];
        signMidCoordPos = vs_signMidCoordPos[0];
    #endif
    EmitVertex();
}

void main() {
    int kind = vs_kind[0];

    vec3 p0 = vs_playerPos[0];
    vec3 p1 = vs_playerPos[1];
    vec3 p2 = vs_playerPos[2];
    vec3 triCenter = (p0 + p1 + p2) * (1.0 / 3.0);
    float dist = length(triCenter);

    #if GRASS_BLADES == 1
        bool inRange = kind > 0 && dist < float(GRASS_RENDER_RADIUS);
        #if GRASS_PLANTS_AS_BLADES == 1
            bool replaced = kind >= 2 && inRange;
        #else
            bool replaced = false;
            if (kind >= 2) inRange = false;
        #endif
    #else
        bool inRange = false;
        bool replaced = false;
    #endif

    // 1) the original triangle (grass floor, every other block, or plants out of blade range)
    if (gl_InvocationID == 0 && !replaced) {
        gbPassVertex(0);
        gbPassVertex(1);
        gbPassVertex(2);
        EndPrimitive();
    }

    #if GRASS_BLADES == 1
    if (!inRange || kind == 4) return;

    // 2) blades
    // FIX: snap world position to integer grid before computing seed.
    // Using raw float cW.xz caused sub-texel drift when the camera rotated
    // (gbufferModelViewInverse precision), making every blade jitter each frame.
    // Snapping to the nearest block centre gives a stable, camera-independent seed.
    vec3 cW = triCenter + cameraPosition;
    vec2 stableXZ = floor(cW.xz + 0.5);
    float stableY  = floor(cW.y  + 0.5);
    vec2 seed = stableXZ * 1.97 + stableY * 3.13;

    int wantBlades = kind == 1 ? GB_TRI_BLADES : max(GB_TRI_BLADES / 2, 1);

    // texture tile extents (a triangle of a quad always covers both extents)
    vec2 tcMin = min(vs_texcoord[0], min(vs_texcoord[1], vs_texcoord[2]));
    vec2 tcMax = max(vs_texcoord[0], max(vs_texcoord[1], vs_texcoord[2]));

    // plant block centre, sign-agnostic for at_midBlock (the centre sits at fract == 0.5)
    vec3 plantCenter = vec3(0.0);
    if (kind >= 2) {
        vec3 wv = p0 + cameraPosition;
        vec3 mb = vs_midBlock[0];
        vec3 cA = wv + mb;
        vec3 cB = wv - mb;
        float eA = dot(abs(fract(cA.xz) - 0.5), vec2(1.0));
        float eB = dot(abs(fract(cB.xz) - 0.5), vec2(1.0));
        plantCenter = eA <= eB ? cA : cB;
    }

    GbWind wind = gbGetWind();
    vec3 nUp = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));

    float thin = smoothstep(float(GRASS_RENDER_RADIUS) * 0.45, float(GRASS_RENDER_RADIUS), dist);
    float keepProb = 1.0 - 0.7 * thin;

    for (int b = 0; b < GB_BPI; b++) {
        int k = gl_InvocationID * GB_BPI + b;
        if (k >= wantBlades) break;

        vec2 s = seed + float(k) * vec2(1.618, 2.414);
        vec2 r = gbHash2(s);
        float rBlade = gbHash(s + 9.1);
        float rKeep  = gbHash(s + 21.7);
        vec2 rTex    = gbHash2(s + 33.3);

        if (rKeep > keepProb) continue;

        vec3 basePlayer;
        vec4 baseColor;
        vec2 baseLm;
        if (kind == 1) {
            vec2 q = r;
            if (q.x + q.y > 1.0) q = 1.0 - q;
            vec3 bw = vec3(1.0 - q.x - q.y, q.x, q.y);
            basePlayer = p0 * bw.x + p1 * bw.y + p2 * bw.z;
            baseColor  = vs_glColor[0] * bw.x + vs_glColor[1] * bw.y + vs_glColor[2] * bw.z;
            baseLm     = vs_lmcoord[0] * bw.x + vs_lmcoord[1] * bw.y + vs_lmcoord[2] * bw.z;
        } else {
            vec3 wp = vec3(plantCenter.x + (r.x - 0.5) * 0.9, plantCenter.y - 0.5, plantCenter.z + (r.y - 0.5) * 0.9);
            basePlayer = wp - cameraPosition;
            baseColor  = (vs_glColor[0] + vs_glColor[1] + vs_glColor[2]) * (1.0 / 3.0);
            baseLm     = (vs_lmcoord[0] + vs_lmcoord[1] + vs_lmcoord[2]) * (1.0 / 3.0);
        }

        vec3 baseWorld = basePlayer + cameraPosition;
        GbBlade B = gbMakeBlade(basePlayer, baseWorld, baseLm.y, kind, rBlade, rKeep, dist, wind);
        if (!B.alive) continue;

        float widthMul = B.widthScale * inversesqrt(max(keepProb, 0.3));
        // Apply hue shift (includes green shift + per-blade jitter), then saturation and vibrance
        vec3 col0 = gbHueShift(baseColor.rgb, B.random) * B.tint;
        col0 = gbSaturate(col0, GRASS_SATURATION);
        col0 = gbVibrance(col0, GRASS_VIBRANCE);

        // sample the tile somewhere inside (avoid the border), per blade
        vec2 tc = mix(tcMin, tcMax, 0.1 + 0.8 * rTex);

        vec3 nrm = nUp;
        vec4 tng = vec4(normalize(mat3(gbufferModelView) * vec3(B.side.x, 0.0, B.side.y)), 1.0);
        float flag = kind == 1 ? 1.0 : 2.0;

        vec3 sideV = vec3(B.side.x, 0.0, B.side.y);

        // FIX Bug 3: skylight (lmcoord.y) ramps from base to tip so the upper
        // part of each blade catches more sky light, matching real foliage behaviour.
        // Block light (lmcoord.x) stays flat — it comes from the ground block.
        for (int i = 0; i < GB_SEG; i++) {
            float t = float(i) / float(GB_SEG);
            float hw = gbWidthAt(t, GB_TIP_W) * widthMul;
            float g = mix(B.gradBase, GRASS_GRADIENT_TIP, pow(t, max(GRASS_GRADIENT_CURVE, 0.001)));
            vec3 col = col0 * g;
            vec3 pc = B.pts[i];
            // Skylight gradient: base keeps block's lm, tip gets a bit more sky exposure
            vec2 lmSeg = vec2(baseLm.x, min(baseLm.y + 0.08 * t, 1.0));
            gbEmitBladeVertex(pc - sideV * hw, col, tc, lmSeg, nrm, tng, flag);
            gbEmitBladeVertex(pc + sideV * hw, col, tc, lmSeg, nrm, tng, flag);
        }
        vec2 lmTip = vec2(baseLm.x, min(baseLm.y + 0.08, 1.0));
        gbEmitBladeVertex(B.pts[GB_SEG], col0 * GRASS_GRADIENT_TIP, tc, lmTip, nrm, tng, flag);
        EndPrimitive();
    }
    #endif
}
