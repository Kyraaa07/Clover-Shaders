#include "/lib/settings/lightingSettings.glsl"

/*
const int colortex0Format = R11F_G11F_B10F; // Main color
const int colortex1Format = RGB16UI;        // Packed shadowmap - 1024px^2
const int colortex2Format = R11F_G11F_B10F; // Bloom buffer
const int colortex3Format = RGBA32UI;       // Packed material attributes
const int colortex4Format = R8;             // Gbuffers Program ID
const int colortex5Format = R8;             // Cloud depth
const int colortex6Format = R32F;           // 1/4 res depth
const int colortex7Format = RGBA16F;        // History buffer
const int colortex8Format = RGBA16;         // Overlays buffer
const int colortex9Format = RGBA16F;        // Weak emitter map (colour * weight, depth * weight)
const int colortex10Format = RGBA32F;       // Water ripple simulation (height, previous height)

const int shadowcolor0Format = RGB8; // Shadow color buffer
*/

const bool colortex0Clear = false;
const bool colortex1Clear = false;
const bool colortex2Clear = false;
const bool colortex3Clear = false;
const bool colortex4Clear = true; // Needed so far Voxy LOD pixels can be detected each frame
const bool colortex5Clear = false;
const bool colortex6Clear = false;
const bool colortex7Clear = false;
const bool colortex8Clear = true;
const bool colortex10Clear = false;

const bool shadowcolor0Clear = false;
const bool shadowcolor1Clear = false;

const int shadowMapResolution = SHADOW_RESOLUTION;
const bool shadowHardwareFiltering = true;

#if SHADOW_DISTANCE == 64
    const float shadowDistance = 64;
#elif SHADOW_DISTANCE == 96
    const float shadowDistance = 96;
#elif SHADOW_DISTANCE == 128
    const float shadowDistance = 128;
#elif SHADOW_DISTANCE == 192
    const float shadowDistance = 192;
#elif SHADOW_DISTANCE == 224
    const float shadowDistance = 224;
#elif SHADOW_DISTANCE == 256
    const float shadowDistance = 256;
#elif SHADOW_DISTANCE == 288
    const float shadowDistance = 288;
#elif SHADOW_DISTANCE == 320
    const float shadowDistance = 320;
#endif

#ifdef OVERWORLD
    #if SUN_ANGLE == -60
        const float sunPathRotation = -60;
    #elif SUN_ANGLE == -50
        const float sunPathRotation = -50;
    #elif SUN_ANGLE == -40
        const float sunPathRotation = -40;
    #elif SUN_ANGLE == -30
        const float sunPathRotation = -30;
    #elif SUN_ANGLE == -20
        const float sunPathRotation = -20;
    #elif SUN_ANGLE == -10
        const float sunPathRotation = -10;
    #elif SUN_ANGLE == 0
        const float sunPathRotation = 0;
    #elif SUN_ANGLE == 10
        const float sunPathRotation = 10;
    #elif SUN_ANGLE == 20
        const float sunPathRotation = 20;
    #elif SUN_ANGLE == 30
        const float sunPathRotation = 30;
    #elif SUN_ANGLE == 40
        const float sunPathRotation = 40;
    #elif SUN_ANGLE == 50
        const float sunPathRotation = 50;
    #elif SUN_ANGLE == 60
        const float sunPathRotation = 60; 
    #endif
#else
    const float sunPathRotation = -50.0;
#endif

const float shadowDistanceRenderMul = 1.0;
const float entityShadowDistanceMul = 0.25;

const int noiseTextureResolution = 256;