#ifndef GOLDEN_HOUR_GLSL
#define GOLDEN_HOUR_GLSL

// Golden hour only runs between these world ticks (sunset). Outside it everything is the
// original Clover look. Ticks: 12000 = sun on the horizon, 12800 = just after dusk.
const float GOLDEN_TICK_START = 12000.0;
const float GOLDEN_TICK_END   = 12800.0;
const float GOLDEN_TICK_FADE  = 120.0; // fade in/out inside the window so it does not pop

// 0 outside the window, 1 inside. timeAngle is fixed outside the Overworld, so this is 0 there.
float getGoldenWeight() {
    float tick = timeAngle * 24000.0;
    float fadeIn  = linearStep(GOLDEN_TICK_START, GOLDEN_TICK_START + GOLDEN_TICK_FADE, tick);
    float fadeOut = 1.0 - linearStep(GOLDEN_TICK_END - GOLDEN_TICK_FADE, GOLDEN_TICK_END, tick);
    return fadeIn * fadeOut;
}

#endif
