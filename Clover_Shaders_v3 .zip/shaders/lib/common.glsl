#define CLOVER 0 //[0]
#define PERF_IMPACT 0 //[0]

// -------- Common Includes -------- //
#include "/lib/uniforms.glsl"
#include "/lib/util/math.glsl"
#include "/lib/util/spaceConversion.glsl"

// -------- Common Variables -------- //
#ifdef OVERWORLD
    float timeAngle = worldTime / 24000.0;
#else
    float timeAngle = 0.25;
#endif
float noonFactor  = sqrt(max(sin(timeAngle *  tau), 0.0));
float nightFactor = sqrt(max(sin(timeAngle * -tau), 0.0));
float invNoonFactor  = 1.0 - noonFactor;
float invNightFactor = 1.0 - nightFactor;

bool isCamInWater = isEyeInWater == 1;
bool isCamInLava  = isEyeInWater == 2;
bool isCamInSnow  = isEyeInWater == 3;

// -------- Common Functions -------- //
float getLuminance(vec3 col) {
    return dot(col, vec3(0.2126, 0.7152, 0.0722));
}

vec3 linearToSRGB(vec3 c) {
    return pow(c, vec3(1.0 / 2.2));
}

vec3 SRGBToLinear(vec3 c) {
    return pow(c, vec3(2.2));
}

float linearizeDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}