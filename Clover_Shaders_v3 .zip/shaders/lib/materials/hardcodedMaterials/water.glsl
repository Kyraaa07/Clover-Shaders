// World-space face coordinates, so the water pattern stays put when the camera turns.
// tbnMatrix is view-space, so bring it to world space and project the world position onto it.
mat3 tbnWorld = mat3(gbufferModelViewInverse) * tbnMatrix;
vec3 worldPosW = playerPos + cameraPosition;
vec2 faceCoord = vec2(dot(worldPosW, tbnWorld[0]), dot(worldPosW, tbnWorld[1]));
vec3 nViewPos  = normalize(viewPos);

float solidDepth = texelFetch(depthtex1, ivec2(gl_FragCoord.xy), 0).r;
vec3 viewDiff = screenToView(vec3(screenPos.xy, solidDepth)) - viewPos;

material.f0 = 0.05;
material.sss = 0.0;
material.roughness = 0.0;
#if WATER_TEXTURE == 1
    material.normalM = material.geoNormal; // flat surface like vanilla water
#else
    material.normalM = getWaterNormal(faceCoord, tbnMatrix, nViewPos);
#endif

float wakeFoam = 0.0;
float wakeSpark = 0.0;
float wakeBody = 0.0;
#if WATER_WAKE == 1
    material.normalM = applyWaterWake(material.normalM, worldPosW.xz, worldPosW.y, wakeFoam, wakeSpark, wakeBody);
#endif

// Depth: vertical height of water above the floor behind it (shallow near the shore, deep further out).
// Vertical, not along the view ray, so far-away shallow water stays turquoise.
float waterDepth = abs(dot(viewDiff, upVec));
// Three stops: shallow turquoise (see-through) -> blue-green in the middle -> deep blue
float midMix  = smoothstep(0.5, 4.0, waterDepth);
float deepMix = smoothstep(4.0, 14.0, waterDepth);
vec3 waterTint = mix(WATER_TINT, WATER_MID_TINT, midMix);
waterTint = mix(waterTint, WATER_DEEP_TINT, deepMix);
material.albedo = glColor.rgb * waterTint;
material.albedo.g = min(material.albedo.g, WATER_GREEN_CAP);

#if WATER_TEXTURE == 1
    // Vanilla water texture: its light/dark pattern modulates the shader water colour
    float vanillaTex = getLuminance(colorP) / 0.55;
    material.albedo *= clamp(1.0 + (vanillaTex - 1.0) * 1.6, 0.4, 1.8);
#endif

alpha = 1.0 - (1.0 - WATER_OPACITY * 0.01) * exp2(-0.15 * length(viewDiff));

if (isCamInWater) alpha = 0.9;

// Foam                   
vec2 foamCoord  = 0.25 * faceCoord + 0.05 * frameTimeCounter;

float distFactor = exp2(-4.0 * abs(dot(viewDiff, upVec)));
float normFactor = pow4(pow4(dot(tbnMatrix[2], upVec)));
float foamNoise  = textureLod(noisetex, foamCoord, 0).r;

float foam = WATER_FOAM * 0.01 * distFactor * normFactor * foamNoise;

#if WATER_TEXTURE == 1
    foam = 0.0;
#endif
material.albedo = mix(material.albedo, vec3(1.0), foam);
alpha = mix(alpha, 1.0, foam);

// Wake crest foam (Water Wake)
material.albedo = mix(material.albedo, WAKE_TINT * 0.75, wakeBody * 0.25); // whole wake path, slightly lighter / different hue
material.albedo = mix(material.albedo, WAKE_TINT * 0.9, wakeFoam * 0.45);
material.albedo += WAKE_TINT * wakeSpark * 0.9;
alpha = mix(alpha, 1.0, clamp(wakeBody * 0.12 + wakeFoam * 0.25 + wakeSpark * 0.6, 0.0, 1.0));