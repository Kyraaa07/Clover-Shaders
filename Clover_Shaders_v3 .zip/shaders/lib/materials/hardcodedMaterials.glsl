#if PORTAL_ENHANCE == 1
    #include "/lib/materials/hardcodedMaterials/portalEnhance.glsl"
#endif

#include "/lib/settings/effectsSettings.glsl"

#if FOOTPRINTS == 1 && defined GBUFFERS_TERRAIN
    #include "/lib/materials/helpers/footprints.glsl"
#endif

#if defined NETHER && defined GBUFFERS_TERRAIN && NETHER_BIOME_COLORS == 1
    #include "/lib/colors/altSkyColors.glsl"
#endif

#ifdef GBUFFERS_WATER
    #include "/lib/materials/helpers/waterNormals.glsl"
    #include "/lib/materials/helpers/waterWake.glsl"

    #if defined NETHER && BIOME_COLORED_NETHER_PORTALS == 1
        #include "/lib/colors/altSkyColors.glsl"
    #endif
#endif

void applyHardcodedMaterials(inout Material material, inout float alpha, vec3 colorP, 
                             mat3 tbnMatrix, vec3 screenPos, vec3 viewPos, vec3 playerPos, int matID) {

    float lumaColorPM = pow2(getLuminance(colorP));

    // <-- IPBR Materials -->
    #if PBR_MODE == 1
        #include "/lib/materials/ipbr/ipbrMaterials.glsl"
    #elif PBR_MODE == 0
        // LabPBR: resource packs often have no (or very weak) emission data, which made torches / lava /
        // glowstone dark and killed coloured light. Run the IPBR tables on a copy and borrow ONLY the
        // emission from them where the pack gives none. Everything else stays 100% LabPBR.
        {
            Material labMaterial = material;

            #include "/lib/materials/ipbr/ipbrMaterials.glsl"

            float fallbackEmission = material.emission;
            material = labMaterial;

            if (material.emission < 0.01) material.emission = fallbackEmission;
        }
    #endif
    
    // <-- End Portal Frame: coloured, glowing Eye of Ender -->
    #if defined GBUFFERS_TERRAIN && END_EYE_GLOW == 1
        /* ----- matID: 1007, End Portal Frame (eye = true only) ----- */
        if (matID == 1007) {
            vec2 eyeFrac = fract(cameraPosition.xz + playerPos.xz);
            float eyeDist = maxOf(abs(eyeFrac - 0.5));

            if (eyeDist < 0.25) {
                float eyeGlow = pow2(0.85 - 3.4 * eyeDist);
                float eyeMask = min1(eyeGlow * 2.5);

                vec3 eyeTinted = END_EYE_COLOR_RGB * (0.4 + 0.6 * min1(lumaColorPM * 1.5));
                material.albedo   = mix(material.albedo, eyeTinted, eyeMask);
                material.emission = eyeGlow * max(lumaColorPM, 0.5) * END_EYE_GLOW_STRENGTH;
            }
        }
    #endif

    // <-- Nether biome lava: green in Soul Sand Valley, cyan in Warped Forest -->
    #if defined GBUFFERS_TERRAIN && defined NETHER && NETHER_BIOME_COLORS == 1
        /* ----------------- matID: 1018, Lava ----------------- */
        if (matID == 1018) {
            float lavaSoul   = netherSoulBiome()   * NETHER_BIOME_STRENGTH;
            float lavaWarped = netherWarpedBiome() * NETHER_BIOME_STRENGTH;

            if (lavaSoul + lavaWarped > 0.001) {
                // Keep the lava texture's light/dark pattern (luminance), only swap the hue
                float lavaLuma = getLuminance(material.albedo);

                vec3 greenTint = vec3(0.30, 1.00, 0.35);
                vec3 cyanTint  = vec3(0.15, 0.75, 1.00);
                greenTint /= getLuminance(greenTint);
                cyanTint  /= getLuminance(cyanTint);

                vec3 lavaAlbedo = material.albedo;
                lavaAlbedo = mix(lavaAlbedo, clamp01(lavaLuma * greenTint), lavaSoul);
                lavaAlbedo = mix(lavaAlbedo, clamp01(lavaLuma * cyanTint),  lavaWarped);
                material.albedo = lavaAlbedo;
            }
        }
    #endif

    // <-- Core Materials -->
    #ifdef GBUFFERS_TERRAIN
        /* ------------------- matID: 1, Leaves ------------------- */
        if (matID == 1) {
            material.sss = 0.4;
            material.roughness = 0.4 - 0.4 * lumaColorPM;
        }
        
        /* ------------------- matID: 2, Foliage ------------------ */
        else if (matID == 2) {
            material.sss = 0.4;
        }
    #endif

    #ifdef GBUFFERS_BLOCK
        /* ----------------- matID: 3, End Portal ----------------- */
        if (matID == 3) {
            #include "/lib/materials/hardcodedMaterials/endPortal.glsl"
        }
    #endif
    
    #ifdef GBUFFERS_WATER
        /* ---------------- matID: 4, Nether Portal --------------- */
        if (matID == 4) {
            material.emission = min(0.25, 40.0 * pow2(lumaColorPM));
            material.albedo = sqrt(material.albedo);
            
            #if defined NETHER && BIOME_COLORED_NETHER_PORTALS == 1
                const float saturationMulti = 1.3;  

                float lumaAltSky = getLuminance(altSkyColor);
                float lumaAlbedo = getLuminance(material.albedo);

                vec3 chromaAltSky = altSkyColor - lumaAltSky;
                vec3 chromaAlbedo = material.albedo - lumaAlbedo;

                float rSaturation = length(chromaAlbedo) * lumaAlbedo / lumaAltSky * saturationMulti;       

                material.albedo = clamp01(lumaAlbedo + chromaAltSky * rSaturation);
            #endif

            #if PORTAL_ENHANCE == 1 && NETHER_PORTAL_FLAMES == 1
                #include "/lib/materials/hardcodedMaterials/netherPortal.glsl"
            #endif
        }
        
        /* -------------------- matID: 5, Water ------------------- */
        else if (matID == 5) {
            #include "/lib/materials/hardcodedMaterials/water.glsl"
        }
    #endif              

    #ifdef GBUFFERS_ENTITIES
        /* -------------- matID: 6, End Crystal Beam -------------- */
        if (matID == 6) {
            material.emission = 0.02;
            material.roughness = 1.0;
            material.blocklight = 0.0;

            material.albedo *= vec3(0.3, 0.3, 0.45);

            #if END_CRYSTAL_VORTEX == 1
                // Healing beam: follows the dragon via vanilla geometry, drawn as a thin band.
                // Colour is 30% lighter than before, and the edge only dims the glow, never the colour, so no black.
                float across      = abs(texcoord.x - 0.5);
                float edge        = 1.0 - smoothstep(0.10, 0.30, across);
                float bloodPhase  = texcoord.x * 12.566 + texcoord.y * 9.0 - frameTimeCounter * 4.0;
                float bloodStreak = pow(0.5 + 0.5 * sin(bloodPhase), 3.0);
                const vec3 bloodDeep    = vec3(0.30, 0.04, 0.45);
                const vec3 bloodCrimson = vec3(0.95, 0.30, 0.04);
                const vec3 bloodLight   = vec3(0.60, 0.50, 0.70);
                vec3 bloodCol = mix(bloodDeep, bloodCrimson, bloodStreak) * 0.8;
                bloodCol = mix(bloodCol, bloodLight, 0.3);
                material.albedo   = bloodCol;
                material.emission = (0.12 + 0.25 * bloodStreak * END_CRYSTAL_VORTEX_STRENGTH) * (0.4 + 0.6 * edge);
            #endif
        }

        // Iris's gbuffers_lightning program was added in 1.20.3
        #if !defined IS_IRIS || MC_VERSION < 12003
            /* --------------- matID: 7, Lightning Bolt --------------- */
            else if (matID == 7) {
                material.emission = 0.4;
                material.blocklight = 0.0;
                material.albedo = vec3(0.5, 0.7, 1.0);
            } 
        #endif
    #endif

    // <-- Rain Puddles -->
    #include "/lib/materials/puddles.glsl"

    // <-- Footprints (matID 1100 = dirt, grass, sand, snow, mud...) -->
    #if FOOTPRINTS == 1 && defined GBUFFERS_TERRAIN
        if ((matID == 1100 || matID == 1101) && dot(material.geoNormal, upVec) > 0.7) {
            vec2 fpSlope;
            float fp = getFootprints(playerPos + cameraPosition, fpSlope) * FOOTPRINT_DEPTH;
            if (fp > 0.001) {
                float fpK = clamp01(fp);
                material.albedo   *= 1.0 - 0.32 * fpK;                 // compressed, damp soil is darker
                material.ao       *= 1.0 - 0.3 * fpK;                  // sits a little lower
                material.roughness = min(material.roughness, mix(material.roughness, 0.7, fpK));
                material.normalM   = normalize(material.normalM - mat3(gbufferModelView) * vec3(fpSlope.x, 0.0, fpSlope.y) * FOOTPRINT_DEPTH);
            }
        }
    #endif
}