#ifndef FOOTPRINT_STATE_GLSL
#define FOOTPRINT_STATE_GLSL

// Footprints .
// The last footprints live in the (faded-out) border row y = 0 of the water simulation buffer
// (colortex10), in the .b / .a channels that the ripple simulation never reads.
//   pixel (3,0)         : .b = distance walked so far (wraps)
//   footprint i (0..7)  : (4+3i,0).ba = position xz
//                         (5+3i,0).ba = birth time + heading
//                         (6+3i,0).ba = ground height + valid flag
// Positions are absolute world coordinates, so they never scroll with the simulation grid.
#define FP_SLOTS       8
#define FP_STEP_LENGTH 0.75                  // blocks between two footsteps
#define FP_ACC_PIXEL   3
#define FP_FIRST_PIXEL 4
#define FP_STATE_END   (FP_FIRST_PIXEL + 3 * FP_SLOTS)   // first x that is NOT footprint state

#endif
