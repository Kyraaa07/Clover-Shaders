#ifndef WATER_WAKE_GLSL
#define WATER_WAKE_GLSL

#include "/lib/settings/effectsSettings.glsl"
#include "/lib/materials/helpers/waterSim.glsl"

// Colour of the wake foam and splash. Default (0) is a pale mint-white that clearly stands out
// from the blue / turquoise water instead of blending into it.
#if WATER_WAKE_COLOR == 1
    #define WAKE_TINT vec3(1.00, 1.00, 1.00)
#elif WATER_WAKE_COLOR == 2
    #define WAKE_TINT vec3(1.00, 0.84, 0.50)
#elif WATER_WAKE_COLOR == 3
    #define WAKE_TINT vec3(1.00, 0.62, 0.82)
#elif WATER_WAKE_COLOR == 4
    #define WAKE_TINT vec3(0.55, 0.95, 1.00)
#else
    #define WAKE_TINT vec3(0.90, 1.00, 0.93)
#endif

#if defined GBUFFERS_WATER && defined FRAGMENT_SHADER && WATER_WAKE == 1
layout(r32i) coherent uniform iimage2D wk_ent_min_img;
layout(r32i) coherent uniform iimage2D wk_ent_max_img;
layout(r32i) coherent uniform iimage2D wk_hit_img;

// Water Physics: the player only disturbs the water while actually touching it (feet below the water
// surface: wading, swimming, in a boat). Walking on the shore / a bridge next to water does nothing.
// Texel (0,0) of wk_hit_img is never used by entity hits (they skip the border), so it carries the flag.
// Any visible water pixel close to the player whose surface is clearly above the player's feet sets it.
void recordPlayerTouch(vec2 worldXZ, float worldY) {
    if (dot(relativeEyePosition, relativeEyePosition) > 100.0) return;
    vec3 eye = cameraPosition - relativeEyePosition;
    vec2 d = worldXZ - eye.xz;
    if (dot(d, d) > 2.25) return;                     // within ~1.5 blocks of the player
    float feetY = eye.y - 1.62;                       // standing eye height
    // Shore: water surface sits ~0.11 below the ground the player stands on (0.35 below when sneaking).
    // Wading / swimming / boat: the surface is well above the feet.
    if (worldY > feetY + 0.35 && worldY < feetY + 2.2)
        imageStore(wk_hit_img, ivec2(0, 0), ivec4(frameCounter + 1));
}

// If an entity (written by gbuffers_entities this frame) reaches this water surface point, mark the
// cell as hit. The mark carries the frame number, so the prepare pass can tell fresh hits from old ones.
#if WATER_WAKE_ENTITIES == 1
void recordEntityHit(vec2 worldXZ, float worldY) {
    ivec2 c = ivec2(floor(worldXZ / SIM_CELL - simCameraCell(cameraPosition) + SIM_RES * 0.5));
    if (c.x < 3 || c.y < 3 || c.x >= int(SIM_RES) - 3 || c.y >= int(SIM_RES) - 3) return;

    int lo = imageLoad(wk_ent_min_img, c).r;
    int hi = imageLoad(wk_ent_max_img, c).r;
    if (lo > hi) return; // nothing wrote here this frame

    float yLo = float(lo) / WK_Y_SCALE;
    float yHi = float(hi) / WK_Y_SCALE;
    // entity bottom at / below the surface and its top not far below the surface
    if (yLo <= worldY + 0.06 && yHi >= worldY - 0.45) imageStore(wk_hit_img, c, ivec4(frameCounter + 1));
}
#endif
#endif

// Interactive water ripples, a real-time wave-equation
// simulation (prepare pass, colortex10) that ripples outward as you swim, wade or ride a boat.
// Returns height (blocks) in .x and the surface slope (d height / d block) in .yz.
vec3 simRipple(vec2 worldXZ) {
    vec2 cellCoord = worldXZ / SIM_CELL - simCameraCell(cameraPosition) + SIM_RES * 0.5;
    if (cellCoord.x < 3.0 || cellCoord.y < 3.0 || cellCoord.x > SIM_RES - 3.0 || cellCoord.y > SIM_RES - 3.0) return vec3(0.0);

    vec2 ts = vec2(textureSize(colortex10, 0));
    vec2 uv = cellCoord / ts;
    vec2 o  = 1.0 / ts;

    float h  = texture(colortex10, uv).r;
    float hx = texture(colortex10, uv + vec2(o.x, 0.0)).r - texture(colortex10, uv - vec2(o.x, 0.0)).r;
    float hz = texture(colortex10, uv + vec2(0.0, o.y)).r - texture(colortex10, uv - vec2(0.0, o.y)).r;
    return vec3(h, vec2(hx, hz) / (2.0 * SIM_CELL));
}

// normalV: view-space water normal. worldXZ / worldY: world position of the water pixel.
// foamOut: white crest foam strength (0..1) for the water shading.
// sparkOut: splash sparkles on the crests (0..1).
// bodyOut: soft tint over the whole disturbed area so the wake path is visible (0..1).
vec3 applyWaterWake(vec3 normalV, vec2 worldXZ, float worldY, out float foamOut, out float sparkOut, out float bodyOut) {
    foamOut = 0.0;
    sparkOut = 0.0;
    bodyOut = 0.0;

#if defined GBUFFERS_WATER && defined FRAGMENT_SHADER && WATER_WAKE == 1
    recordPlayerTouch(worldXZ, worldY);
    #if WATER_WAKE_ENTITIES == 1
        recordEntityHit(worldXZ, worldY);
    #endif
#endif

    vec3 rip = simRipple(worldXZ);
    float h = rip.x;
    vec2 grad = rip.yz;

    // Only show the wake when the player is actually near the water level (not on a tall bridge / flying).
    // The player's eye = camera MINUS relativeEyePosition (Iris), correct in 1st and 3rd person.
    float eyeY = cameraPosition.y - relativeEyePosition.y;
    float nearWater = 1.0 - smoothstep(3.5, 6.0, eyeY - worldY);

    float strength = WATER_WAKE_STRENGTH * 0.5; // 2.0 = reference strength
    vec3 tilt = mat3(gbufferModelView) * vec3(-grad.x, 0.0, -grad.y) * strength * nearWater;

    // Crest foam: bright where the ripple is tall or steep (lower thresholds = shows up sooner)
    float gl = length(grad);
    float crest = smoothstep(0.03, 0.16, h) + smoothstep(0.2, 0.8, gl) * 0.6;
    foamOut = clamp(crest * strength * 0.3, 0.0, 1.0) * nearWater;

    // Body tint: any disturbed water (crest OR trough) gets a faint wake colour
    bodyOut = clamp(smoothstep(0.012, 0.10, abs(h)) + smoothstep(0.08, 0.5, gl) * 0.5, 0.0, 1.0) * nearWater;

    // Splash sparkles: small droplets that flicker on the crests
    float t = frameTimeCounter;
    float dropNoise  = textureLod(noisetex, worldXZ * 2.3 + vec2(t * 0.9, -t * 0.7), 0).r;
    float dropNoise2 = textureLod(noisetex, worldXZ * 5.1 - vec2(t * 1.6,  t * 1.1), 0).r;
    float drops = smoothstep(0.62, 0.92, dropNoise * dropNoise2 * 2.2);
    sparkOut = drops * smoothstep(0.06, 0.22, h) * WATER_WAKE_SPLASH * nearWater;

    return normalize(normalV + tilt);
}

#endif
