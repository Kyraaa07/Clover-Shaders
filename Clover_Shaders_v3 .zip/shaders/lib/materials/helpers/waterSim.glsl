#ifndef WATER_SIM_GLSL
#define WATER_SIM_GLSL

// Interactive water ripple simulation .
// A 512x512 height field (colortex10) of 0.1 block cells, centred on the camera and
// scrolled with it. .r = height, .g = previous height, pixel (0,0).b = "eye was under water".
#define SIM_RES  512.0
#define SIM_CELL 0.1

// Entity interaction: entities write the min / max world Y of their visible surface per cell into two
// integer images, the water pass compares that with the water surface height and marks the cell as hit.
#define WK_Y_SCALE   32.0
#define WK_EMPTY_MIN 1073741824
#define WK_EMPTY_MAX (-1073741824)

vec2 simCameraCell(vec3 camPos) { return floor(camPos.xz / SIM_CELL); }

#endif
