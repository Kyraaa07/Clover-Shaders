#ifndef FOOTPRINTS_GLSL
#define FOOTPRINTS_GLSL

// Footprints, render side. Included at the top of
// hardcodedMaterials.glsl, only for terrain.
#include "/lib/materials/helpers/footprintState.glsl"

float fpHash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

// Minecraft leg print: the leg is a 4x4 pixel (1/4 block) square, so the print is a
// pixel-sharp square pressed in, with a bit of unevenness per pixel
float footShape(vec2 q) {
    vec2 px = floor(q * 16.0);                       // snap to Minecraft pixels (1/16 block)
    vec2 b = abs(px + 0.5) - vec2(2.0);              // inside when within the 4x4 pixel square
    float inside = step(max(b.x, b.y), 0.0);
    float tread = 0.85 + 0.15 * fpHash(px + 7.0);    // uneven pressed soil per pixel
    return inside * tread;
}

// How deep the footprints are pressed in at this point, and the slope of the print (world xz)
float getFootprints(vec3 wp, out vec2 slope) {
    slope = vec2(0.0);
    float imprint = 0.0;
    for (int i = 0; i < FP_SLOTS; i++) {
        vec4 a = texelFetch(colortex10, ivec2(FP_FIRST_PIXEL + 3 * i, 0), 0);
        vec2 rel = wp.xz - a.ba;
        if (!(dot(rel, rel) <= 0.09)) continue;      // also rejects NaN
        vec4 b = texelFetch(colortex10, ivec2(FP_FIRST_PIXEL + 3 * i + 1, 0), 0);
        vec4 c = texelFetch(colortex10, ivec2(FP_FIRST_PIXEL + 3 * i + 2, 0), 0);
        if (c.a < 0.5) continue;
        float age = mod(frameTimeCounter - b.b + 3600.0, 3600.0);
        if (age > FOOTPRINT_DURATION || abs(wp.y - c.b) > 0.4) continue;
        vec2 dir = vec2(cos(b.a), sin(b.a));
        vec2 q = vec2(dot(rel, dir), dot(rel, vec2(-dir.y, dir.x)));
        float fade = 1.0 - smoothstep(FOOTPRINT_DURATION * 0.45, FOOTPRINT_DURATION, age);
        float s = footShape(q) * fade;
        if (s > imprint) {
            const float e = 0.035;
            vec2 g = vec2(footShape(q + vec2(e, 0.0)) - footShape(q - vec2(e, 0.0)),
                          footShape(q + vec2(0.0, e)) - footShape(q - vec2(0.0, e))) / (2.0 * e) * fade;
            // back to world space; the print is a depression, so its walls face inward
            slope = -(dir * g.x + vec2(-dir.y, dir.x) * g.y) * 0.02;
            imprint = s;
        }
    }
    return imprint;
}

#endif
