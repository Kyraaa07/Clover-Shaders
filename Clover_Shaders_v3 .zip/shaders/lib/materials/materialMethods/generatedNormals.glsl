// Generated normals (IPBR+). Port of Complementary's GenerateNormals, adapted to Clover.
// Lighting bumps come from the colour edges of the texel and its neighbours inside the same atlas tile.
// Inputs (set by gbuffers_solid.glsl): gtexture, tile centre gnMidCoord and texel-to-centre distance gnAbsMid (atlas UV).

const float gnThreshold = 0.05;
const float gnClamp = 0.2;

float gnDif(float lOriginal, vec2 offsetCoord) {
    float lNearby = length(texture(gtexture, offsetCoord).rgb);
    float dif = lOriginal - lNearby;
    if (dif > 0.0) dif = max(dif - gnThreshold, 0.0);
    else           dif = min(dif + gnThreshold, 0.0);
    return clamp(dif, -gnClamp, gnClamp);
}

void GenerateNormalsClover(inout vec3 normalM, vec3 color, mat3 tbn, vec2 texc, vec2 midC, vec2 absMid) {
    vec2 atlasSizeF = vec2(textureSize(gtexture, 0));
    float normalMult = float(GENERATED_NORMAL_MULT) * 0.025;

    float lOriginal = length(color);

    vec2 offsetR = 16.0 / atlasSizeF;
    offsetR /= float(GENERATED_NORMAL_RES);

    vec2 originalOffsetR = offsetR;
    offsetR = max(originalOffsetR, fwidth(texc));

    vec2 maxOffsetCoord = midC + absMid;
    vec2 minOffsetCoord = midC - absMid;

    vec3 normalMap = vec3(0.0, 0.0, 1.0);

    vec2 offsetCoord = texc + vec2(0.0, offsetR.y);
    if (offsetCoord.y < maxOffsetCoord.y) normalMap.y += gnDif(lOriginal, offsetCoord);

    offsetCoord = texc + vec2(offsetR.x, 0.0);
    if (offsetCoord.x < maxOffsetCoord.x) normalMap.x += gnDif(lOriginal, offsetCoord);

    offsetCoord = texc + vec2(0.0, -offsetR.y);
    if (offsetCoord.y > minOffsetCoord.y) normalMap.y -= gnDif(lOriginal, offsetCoord);

    offsetCoord = texc + vec2(-offsetR.x, 0.0);
    if (offsetCoord.x > minOffsetCoord.x) normalMap.x -= gnDif(lOriginal, offsetCoord);

    normalMap.xy *= vec2(normalMult * sqrt(float(GENERATED_NORMAL_RES) / 128.0)) * (originalOffsetR / offsetR);
    normalMap.xy = clamp(normalMap.xy, vec2(-1.0), vec2(1.0));

    if (normalMap.xy != vec2(0.0)) {
        // tbn columns are tangent, bitangent, normal (view space), so tbn * v maps tangent space to view space
        normalM = clamp(normalize(tbn * normalMap), vec3(-1.0), vec3(1.0));
    }
}
