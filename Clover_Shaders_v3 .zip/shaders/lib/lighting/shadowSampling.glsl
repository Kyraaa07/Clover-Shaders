#include "/lib/util/shadowDistortion.glsl"
#include "/lib/util/vogelDiscSampling.glsl"

vec3 getShadowSample(vec3 shadowScreen) {
    float shadow0 = shadow2D(shadowtex0, shadowScreen).r;
    if (shadow0 > 0.9999) return vec3(shadow0);

    float shadow1 = shadow2D(shadowtex1, shadowScreen).r;
    if (shadow1 < 0.0001) return vec3(shadow1);

    vec3 colorSample = textureLod(shadowcolor0, shadowScreen.xy, 0).rgb;
	return shadowColorRange * colorSample * (1.0 - shadow0) + shadow0;
}

vec3 getShadow(vec3 shadowNdc, float offset) {
    float shadowScreenZ = shadowNdc.z * 
                          SHADOW_Z_MULT * 0.5 + 0.5; 
    
    vec3 sum = vec3(0.0);
    vec3 first = vec3(0.0);
    const int samplecount = 4; 

    for (int i = 0; i < samplecount; i++) {
        vec2 sampleOffset   = offset * vogelDisc(i, samplecount, dither_ign);
        vec2 shadowScreenXY = getShadowScreenXY(shadowNdc.xy + sampleOffset);

        vec3 s = getShadowSample(vec3(shadowScreenXY, shadowScreenZ));
        sum += s;
        if (i == 0) first = s;

        // Not in a penumbra: the first two taps agree, so the other two would too. Skip them.
        if (i == 1 && maxOf(abs(first - s)) < 0.02) return sum * 0.5;
    }
    return sum / samplecount;
}

vec3 getSSS(vec3 shadowNdc, out vec3 shadow, vec3 albedo, float lumaAlbedo, float geoNdotL, bool isCrossModel) {
    float offsetMixer = min1(max0(geoNdotL * 0.9 + 0.1) * 10.0);
    float finalOffset = mix(shadowOffsetSSS, shadowOffset, offsetMixer);

    shadow = getShadow(shadowNdc, finalOffset);
    float k = min1(maxOf(shadow));

    vec3 factor = (lumaAlbedo + 1e-6) / (albedo + 1e-6);
    vec3 tinter = shadow / (k + 1e-6);

    vec3 sssOut = pow(vec3(k), 3.0 * factor) * tinter;

    if (!isCrossModel) {
        sssOut *= mix(1.0, max0(geoNdotL), 0.6666 - abs(geoNdotL) * 0.6666);
    }

    return sssOut * (isCamInWater ? 0.4 : 0.9);
}