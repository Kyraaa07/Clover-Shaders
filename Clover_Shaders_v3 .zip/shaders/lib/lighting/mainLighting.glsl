#include "/lib/settings/lightingSettings.glsl"
#ifdef END
    #include "/lib/settings/atmosphereSettings.glsl"
#endif
#include "/lib/settings/postSettings.glsl"
#include "/lib/colors/lightingColors.glsl"

#include "/lib/lighting/specularHighlight.glsl"
#include "/lib/lighting/phaseFunctions.glsl"
#include "/lib/lighting/shadowSampling.glsl"

#if defined DEFERRED && SSAO == 1 
    #include "/lib/lighting/ambientOcclusion.glsl"
#endif

#if defined GBUFFERS_WATER || defined GBUFFERS_HAND_WATER || (defined DEFERRED && (RAIN_PUDDLES > 0 || GLOSSY_WORLD == 1 || defined OVERWORLD))
    #include "/lib/lighting/reflections.glsl"
#endif

#if defined DEFERRED && WORLD_OUTLINE == 1
    #include "/lib/post/worldOutline.glsl"
#endif

#include "/lib/atmospherics/fog.glsl"

#if defined DEFERRED && !defined NETHER && !defined END
    #include "/lib/lighting/fresnel.glsl"
#endif

#ifdef DEFERRED
    #include "/lib/lighting/lodScreenSpace.glsl"

    #if COLORED_LIGHT == 1
        #include "/lib/lighting/coloredLight.glsl"
    #endif
#endif

vec3 computeMainLighting(Material material, vec3 screenPos, vec3 viewPos, vec3 playerPos, int programID) {
    float wsdist = length(viewPos);
    
    vec3 nViewPos = viewPos / wsdist;
    vec3 wPlayerNormal = mat3(gbufferModelViewInverse) * material.geoNormal;

    #ifdef DEFERRED
        if (programID == GBUFFERS_VOXY_ID && material.roughness < 0.01)
            material.normalM = getLodWaterNormal(playerPos, material.geoNormal, nViewPos, wsdist);
    #endif

    float VdotS = dot(nViewPos, sunVec);

    #ifdef OVERWORLD
        float signY = sign(pSunVec.y);
        float VdotL    = VdotS   * signY;
        vec3 lightVec  = sunVec  * signY;
        vec3 pLightVec = pSunVec * signY;
    #else
        float VdotL    = VdotS;
        vec3 lightVec  = sunVec;
        vec3 pLightVec = pSunVec;
    #endif

    #ifdef DEFERRED
        bool isCrossModel = programID == GBUFFERS_TERRAIN_ID && 
                            dot(abs(wPlayerNormal.xz), vec2(0.707106)) > 0.99;
    #else
        bool isCrossModel = false;
    #endif

    float skylightMult   = pow2(material.skylight);
    float blocklightMult = pow2(material.blocklight);
    
    blocklightMult = mix(
        pow3(pow2(blocklightMult)), 
        blocklightMult, 
        #ifdef OVERWORLD
            0.1 - 0.07 * invNightFactor * material.skylight
            // We let blocklight rule at night time and in indoor scenes
        #elif defined NETHER
            0.06
        #else
            0.03
        #endif
    ); 

    float minLightMult = 1.0 - skylightMult + 16.0 * nightVision; // Either in caves or while having night vision

    #if HANDHELD_LIGHTING == 1
        if (heldLight > 0.0) {
            vec3 vector = playerPos + relativeEyePosition;
            float lenSq = lengthSquared(vector);

            blocklightMult += heldLight / (1.0 + lenSq);
        }
    #endif

    float skyDirShading = 1.0, bloDirShading = 1.0;
    if (!isCrossModel) {
        float dirShadingBase = 1.0 - 0.4 * abs(wPlayerNormal.x);
    
        skyDirShading = dirShadingBase * (dot(material.normalM, upVec) * 0.4 + 0.6);
        bloDirShading = dirShadingBase * (abs(wPlayerNormal.y) * 0.25 + 0.75);
    }

    vec3 minLight   = minLightColor   * (minLightMult   * skyDirShading);
    vec3 skylight   = ambientColor    * (skylightMult   * skyDirShading);
    vec3 blocklightCol = blocklightColor;
    vec3 coloredGlow = vec3(0.0);
    #if defined DEFERRED && COLORED_LIGHT == 1
        // Skip the 16-sample search when this pixel gets (almost) no blocklight: the hue would be invisible anyway
        if (programID != GBUFFERS_HAND_ID && (blocklightMult > 0.002 || COLORED_LIGHT_ORE_GLOW == 1))
            blocklightCol = getColoredBlocklight(blocklightColor, viewPos, material.blocklight, coloredGlow);
    #endif
    vec3 blocklight = blocklightCol * (blocklightMult * bloDirShading) + coloredGlow * bloDirShading;

    float AO = mix(pow3(min1(material.ao + 0.07)), 1.0, 0.1 + 0.5 * float(material.sss > 0.0));
    
    #if defined DEFERRED && SSAO == 1
        if (programID == GBUFFERS_TERRAIN_ID || programID == GBUFFERS_BLOCK_ID) {
            AO *= getAmbientOcclusion(viewPos, nViewPos, material.geoNormal);
        }
    #endif

    #ifdef DEFERRED
        if (programID == GBUFFERS_VOXY_ID)
            AO *= getLodAO(viewPos, material.geoNormal, dither_ign);
    #endif

    #ifndef NETHER
        float lumaAlbedo = getLuminance(material.albedo);

        float NdotLM = dot(material.normalM, lightVec);
        float geoNdotL = dot(material.geoNormal, lightVec);

        float diffuseMixer = min1(2.0 * material.sss) * (0.2 + 0.8 * float(isCrossModel));
        float  diffuseMult = mix(max0(NdotLM), 
                                 max0(NdotLM * 0.6 + 0.4), 0.2) * linearStep(-0.25, -0.125, geoNdotL);
               diffuseMult = mix(diffuseMult, pLightVec.y, diffuseMixer);

        vec3 sunlight  = lightColor * (skylightMult * 0.5 + 0.5);
        vec3 sunlightD = sunlight * diffuseMult;

        vec3 shadow = vec3(0.0);
        vec3 shadow_sss = vec3(0.0);
        if (SHADOWS == 1 && wsdist < SHADOW_DISTANCE) {
            //------- Fix light leaking in caves -------//
            // Cant use the Ao dir method cause .. deferred rendering :(
            vec3 centerPos  = floor(playerPos + cameraPosition + 0.01 * wPlayerNormal) - cameraPosition + 0.5;
                 centerPos += wPlayerNormal * dot(wPlayerNormal, playerPos - centerPos);
            vec3 shadowPlayerPos = mix(playerPos, centerPos, (0.25 - 0.25 * pow4(material.ao)) * (1.0 - pow2(skylightMult)));
            
            //------- Shadow bias method -------//
            vec3 bias = wPlayerNormal * (0.06 + 0.003 * wsdist) * (2.0 - 0.95 * max0(geoNdotL));
            if (material.sss > 0.0) bias = mix(bias, 0.5 * pLightVec, isCrossModel ? 0.4 : abs(geoNdotL));
            shadowPlayerPos += bias;

	        vec3 shadowNdc = playerToShadow(shadowPlayerPos);
            if (material.sss > 0.0) {
                shadow_sss = getSSS(shadowNdc, shadow, material.albedo, lumaAlbedo, geoNdotL, isCrossModel);
                sunlight *= shadow_sss;
            } else {
                shadow = getShadow(shadowNdc, shadowOffset);
                sunlight = shadow * sunlightD;
            }
        }
        vec3 distantShadow = vec3(max0(skylightMult * 5.0 - 4.0));
        #ifdef DEFERRED
            // Voxy LODs have no shadow map: let sun reach every sky-exposed LOD surface
            if (programID == GBUFFERS_VOXY_ID) distantShadow = vec3(linearStep(0.4, 0.8, material.skylight));
        #endif
        float shadowMixer  = clamp01((10.0 / SHADOW_DISTANCE) * wsdist - 9.0);
        #if SHADOWS == 0
            shadowMixer = 1.0; // no shadow map: use the cheap sky-light based sun term everywhere
        #endif
        float LdotUM = pow3(min1(20.0 * pLightVec.y));

        shadow     = mix(shadow,               distantShadow, shadowMixer) * LdotUM;
        sunlight   = mix(sunlight, sunlightD * distantShadow, shadowMixer) * LdotUM; 
        shadow_sss = mix(shadow_sss,               vec3(0.0), shadowMixer) * LdotUM;

        #ifdef DEFERRED
            // Voxy LODs: screen-space sun shadows (the shadow map doesn't reach them)
            if (programID == GBUFFERS_VOXY_ID && LdotUM > 0.0 && geoNdotL > -0.25) { // faces turned away from the light are unlit anyway
                float lodShadow = getLodScreenShadow(viewPos, material.geoNormal, lightVec, dither_ign);
                shadow     *= lodShadow;
                sunlight   *= lodShadow;
                shadow_sss *= lodShadow;
            }
        #endif
    #else
        vec3 sunlight = vec3(0.0);
    #endif

    vec3 finalLight = material.albedo * (AO * (sunlight + skylight + blocklight + minLight) + material.emission * 24.0);

    #if defined END && END_BLACK_HOLE == 1
        // Purple light from the black hole's direction, lit like the sun but tinted to match its glow
        vec3 bhViewDir = normalize(mat3(gbufferModelView) * vec3(-0.62, 0.30, -0.72));
        vec3 bhLightCol = vec3(0.60, 0.25, 1.00) * END_BLACK_HOLE_SURFACE_LIGHT;
        finalLight += material.albedo * AO * bhLightCol * max0(dot(material.normalM, bhViewDir));

        // Glossy purple reflection of the black hole: sharp on smooth ground, soft on rough
        finalLight += getSpecularHighlight(-nViewPos, material.normalM, bhViewDir, material.roughness, vec3(material.f0))
                    * vec3(0.75, 0.30, 1.00) * END_BLACK_HOLE_SURFACE_LIGHT * 2.0;
    #endif

    #if !defined NETHER || (defined GBUFFERS_WATER || defined GBUFFERS_HAND_WATER)
        // Prevent reflection direction from pointing into the surface
        float NdotRM = max0(dot(material.geoNormal, reflect(nViewPos, material.normalM)));
        material.normalM = normalize(mix(material.normalM, material.geoNormal, pow4(pow4(1.0 - NdotRM))));
    #endif

    // ---- Glitter fix (rain puddles / Glossy World) ----
    // On near-mirror wet ground a bumpy PBR normal map (realistic texture packs) turns the sun highlight and the
    // reflection into thousands of tiny white sparkles. For the mirror part ONLY the normal is flattened toward the
    // real surface normal and the highlight can't get needle-sharp. Diffuse light keeps the full texture detail.
    #define GLOSSY_NORMAL_SMOOTH 0.85       // 0 = keep the normal map in reflections, 1 = perfectly flat
    #define GLOSSY_MIN_SPEC_ROUGHNESS 0.07  // lowest roughness the sun highlight may use on puddles / glossy ground
    vec3  nGloss = material.normalM;
    float glossK = 0.0;
    #if defined DEFERRED && (RAIN_PUDDLES > 0 || GLOSSY_WORLD == 1)
        if ((programID == GBUFFERS_TERRAIN_ID || (programID == GBUFFERS_VOXY_ID && material.roughness >= 0.01)) && material.roughness < 0.16) {
            glossK = linearStep(0.16, 0.0, material.roughness);
            nGloss = normalize(mix(material.normalM, material.geoNormal, GLOSSY_NORMAL_SMOOTH * glossK));
        }
    #endif

    #ifndef NETHER
        vec3 f0ip = isMetal(material.f0) ? material.albedo : vec3(material.f0);
        // Sun reflection: widen the lobe on rough surfaces (softer, not a hard white spot).
        // linearStep keeps smooth surfaces such as puddles sharp.
        float sunSpecRoughness = min(material.roughness + SUN_SPECULAR_SPREAD * linearStep(0.05, 0.3, material.roughness), 1.0);
        sunSpecRoughness = max(sunSpecRoughness, GLOSSY_MIN_SPEC_ROUGHNESS * glossK);
        vec3 specularLight  = getSpecularHighlight(-nViewPos, nGloss, lightVec, sunSpecRoughness, f0ip) * SUN_SPECULAR_STRENGTH;
        float sssSheenLight = henyeyGreenstein(VdotL, isCamInWater ? 0.25 : 0.65) * (lumaAlbedo * 0.8 + 0.2) * 4.0;
        finalLight += pow0_75(0.45 * lightColor) * (shadow * specularLight + shadow_sss * sssSheenLight);
    #endif

    #if defined GBUFFERS_WATER || defined GBUFFERS_HAND_WATER
        if (material.roughness < 0.05)
            DoReflection(finalLight, screenPos, viewPos, nViewPos, material.normalM, vec3(material.f0), material.skylight, false);
    #endif

    #if defined DEFERRED && (RAIN_PUDDLES > 0 || GLOSSY_WORLD == 1)
        // Rain puddles (Overworld) / permanent puddles (Nether & End): terrain written with roughness 0 by lib/materials/puddles.glsl
        if ((programID == GBUFFERS_TERRAIN_ID || (programID == GBUFFERS_VOXY_ID && material.roughness >= 0.01)) && material.roughness < 0.16) {
            float puddleAmt = linearStep(0.16, 0.0, material.roughness); // soft puddle edges
            if (puddleAmt > 0.02) { // below this the reflection is invisible: skip the ray trace
            vec3 puddleRef = finalLight;
            #ifdef OVERWORLD
                #if GLOSSY_WORLD == 1
                    float puddleSkylight = max(material.skylight, 0.3); // glossy surfaces indoors still get a faint environment sheen
                #else
                    float puddleSkylight = material.skylight;
                #endif
            #else
                float puddleSkylight = 1.0; // Nether / End have no usable sky light: always show the environment reflection
            #endif
            DoReflection(puddleRef, screenPos, viewPos, nViewPos, nGloss, vec3(material.f0), puddleSkylight, true);
            finalLight = mix(finalLight, puddleRef, puddleAmt);
            }
        }
    #endif

    #if defined DEFERRED && defined OVERWORLD
        // Voxy LOD water (roughness 0): cheap sky reflection so it matches vanilla water at grazing angles
        if (programID == GBUFFERS_VOXY_ID && material.roughness < 0.01) {
            float NdotVn = max0(-dot(nViewPos, material.normalM));
            vec3 rayDir  = 2.0 * NdotVn * material.normalM + nViewPos;
            float lodRdotU = dot(rayDir, upVec);
            // Same sky as vanilla water: stars, Milky Way, aurora, nebula, comets and clouds
            vec3 skyRef  = getReflectedSky(rayDir, lodRdotU, dot(rayDir, sunVec), material.skylight, false);
            skyRef *= pow2(min1(lodRdotU + 1.0) * min1(material.skylight + 0.08)); // same fade as vanilla water
            finalLight = mix(finalLight, skyRef, getFresnel(NdotVn, vec3(material.f0)));
        }
    #endif

    #if defined DEFERRED && WORLD_OUTLINE == 1
        if (programID != GBUFFERS_HAND_ID)
            DoWorldOutline(finalLight, screenPos.z);
    #endif

    DoFog(finalLight, playerPos, wsdist, dot(nViewPos, upVec), VdotS);

    return finalLight;
}