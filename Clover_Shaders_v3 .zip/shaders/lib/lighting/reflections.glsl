#include "/lib/lighting/fresnel.glsl"

#ifdef OVERWORLD
    #include "/lib/atmospherics/sky.glsl"
    #if WATER_REFLECT_STARS == 1 || WATER_REFLECT_COMETS == 1 || WATER_REFLECT_AURORA == 1
        #include "/lib/atmospherics/stars.glsl"
        #include "/lib/atmospherics/nightSky.glsl"
    #endif
#else 
    #include "/lib/colors/altSkyColors.glsl"
#endif

#ifndef NETHER
    #include "/lib/atmospherics/submergedFog.glsl"
#endif

#include "/lib/settings/materialSettings.glsl"
#if REFLECTION_QUALITY > 0
    #include "/lib/util/raytracer.glsl"
#endif

#ifdef OVERWORLD
#if WATER_REFLECT_CLOUDS == 1 && VL_CLOUDS > 0
// The real cloud layer is drawn in the deferred pass, which water shading cannot read,
// so reflected clouds are rebuilt here from noisetex (bound in every stage).
// Water reflections are not a perfect mirror of the sky clouds, but they read as clouds.
void addWaterReflectClouds(inout vec3 skyRef, vec3 worldDir) {
    float cloudH = float(CLOUD_HEIGHT) - cameraPosition.y;
    if (cloudH <= 0.0 || worldDir.y < 0.01) return;

    float t = cloudH / worldDir.y;
    if (t > 4000.0) return;

    float wind = (float(worldTime) + 24000.0 * float(worldDay % 128)) * 0.05 * CLOUD_SPEED;
    vec2 pos = cameraPosition.xz + worldDir.xz * t;
    pos.y -= wind;
    vec2 uv = pos * (0.7 / CLOUD_SCALE) / 256.0;

    float n = textureLod(noisetex, uv, 0.0).r * 0.55
            + textureLod(noisetex, uv * 2.37 + 0.31, 0.0).r * 0.30
            + textureLod(noisetex, uv * 5.13 + 0.67, 0.0).r * 0.15;

    float thresh = 0.52 - 0.10 * rainFactor;
    float cover = smoothstep(thresh, thresh + 0.14, n);
    cover *= smoothstep(0.0, 0.15, worldDir.y);
    cover *= 1.0 - smoothstep(3000.0, 4000.0, t);
    if (cover <= 0.0) return;

    float dayF = smoothstep(-0.1, 0.2, dot(sunVec, upVec));
    vec3 cloudCol = mix(ambientColor * 3.0, lightColor * 1.2, 0.6) * CLOUD_BRIGHTNESS;
    cloudCol *= mix(CLOUD_NIGHT_BRIGHTNESS, 1.0, dayF);
    cloudCol *= 1.0 - 0.4 * rainFactor;
    cloudCol = min(cloudCol, vec3(2.0));

    skyRef = mix(skyRef, cloudCol, cover * 0.85 * CLOUD_OPACITY);
}
#endif
#endif

#ifdef OVERWORLD
// Sky as seen in a mirror: base sky + stars, Milky Way, aurora, nebula, comets and clouds.
// Used by vanilla water, puddles AND Voxy LOD water so all of them reflect the same sky.
// Everything is added at the same brightness as the real sky (WATER_REFLECT_STRENGTH = 1.0 is an exact mirror),
// otherwise the reflection gets a different colour from the sky at night.
// groundMode = true for puddles / glossy world: no stars, aurora, nebula, comets or clouds.
vec3 getReflectedSky(vec3 rayDir, float RdotU, float RdotS, float skylight, bool groundMode) {
    vec3 skyRef = getSky(RdotU, RdotS);
    vec3 celestial = vec3(0.0);

    #if WATER_REFLECT_STARS == 1 || WATER_REFLECT_COMETS == 1 || WATER_REFLECT_AURORA == 1
      if (!groundMode) {
        vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * rayDir);

        #if WATER_REFLECT_STARS == 1
            celestial += getStars(worldDir);
            #if MILKY_WAY == 1
                celestial += getMilkyWay(worldDir);
            #endif
        #endif

        #if WATER_REFLECT_AURORA == 1
            #if AURORA_BOREALIS == 1
                celestial += getAuroraBorealis(rayDir, dither_ign, 10);
            #endif
            #if NIGHT_NEBULA == 1
                celestial += getNightNebula(rayDir, RdotU, RdotS);
            #endif
        #endif

        #if WATER_REFLECT_COMETS == 1 && SHOOTING_STARS == 1
            celestial += getShootingStars(worldDir, RdotU);
        #endif

        float celFade = smoothstep(-0.15, 0.35, RdotU) * min1(skylight + 0.15);
        celestial *= WATER_REFLECT_STRENGTH * celFade;
      }
    #endif

    skyRef += celestial;

    #if WATER_REFLECT_CLOUDS == 1 && VL_CLOUDS > 0
        if (!groundMode) addWaterReflectClouds(skyRef, normalize(mat3(gbufferModelViewInverse) * rayDir));
    #endif

    return skyRef;
}
#endif

void DoReflection(inout vec3 color, vec3 screenPos, vec3 viewPos, vec3 nViewPos, vec3 normalR, vec3 f0, float skylight, bool groundMode) {
    // groundMode = true for puddles / glossy world: no stars, aurora, nebula, comets or clouds in the reflection
    // (sun & moon highlights are added separately via the specular highlight, so they stay)
    float NdotVn = -dot(nViewPos, normalR);

    vec3 rayDir = 2.0 * NdotVn * normalR + nViewPos;

    float RdotU = dot(rayDir, upVec);
    float RdotS = dot(rayDir, sunVec);
    
    // Softer fade so night sky elements stay visible on water
    float skyFade = pow2(min1(RdotU + 1.0) * min1(skylight + 0.08));

    #ifdef OVERWORLD
        vec3 skyRef = getReflectedSky(rayDir, RdotU, RdotS, skylight, groundMode);
    #else
        vec3 skyRef = altSkyColor;
    #endif

    #ifndef NETHER
        if (isCamInWater) skyRef = mix(waterFogColor, skyRef, clamp01(4.0 * RdotU));
    #endif

    vec3 envRef = skyRef * skyFade;

    vec3 finalRef = envRef;

    #if REFLECTION_QUALITY > 0
        int stepcount = int(exp2(float(REFLECTION_QUALITY) + 2.0)); // 8, 16, 32
        if (groundMode) stepcount = max(stepcount / 2, 8);        // puddles / glossy ground: half the steps

        vec3 hitPos;
        int rtHit = raytrace(hitPos, screenPos, viewPos, rayDir, stepcount);
    
        if (rtHit == RT_HIT_GEO) {
            vec2 uv  = viewToPrvScreenXY(screenToView(hitPos));
            finalRef = textureLod(colortex7, uv, 0).rgb;
        } else if (rtHit == RT_HIT_SKY)
            finalRef = skyRef;
    
        // Higher clamp so bright stars/comets don't get crushed
        finalRef = min(finalRef, vec3(max(REFLECTION_CLAMP, 3.5)));

        float dist = maxOf(abs(0.5 - hitPos.xy));
        float edge = linearStep(0.45, 0.5, dist);

        finalRef = mix(finalRef, envRef, edge);
    #endif

    color = mix(color, finalRef, getFresnel(NdotVn, f0));
}