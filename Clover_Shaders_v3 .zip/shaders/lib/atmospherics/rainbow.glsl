#ifndef RAINBOW_GLSL
#define RAINBOW_GLSL

// Rainbows.  
// A single rainbow appears opposite the sun (RAINBOW 1: while the rain is clearing and the sun is low,
// RAINBOW 2: all day except sunset and night):
// the bow sits 40.4-42.6 degrees around the antisolar point (red outside). It also draws
// a fainter secondary bow at about 51-54 degrees; it was removed on purpose.
//
// Needs: common.glsl (pSunVec, wetness, rainFactor, skylightFactor), atmosphereSettings.glsl

#include "/lib/settings/atmosphereSettings.glsl"
#include "/lib/colors/lightingColors.glsl"

vec3 rbHue(float h) {
    return clamp(abs(fract(h + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
}

// rayDir: world space view direction. wsdist: distance to the pixel, 1e30 for the sky.
void DoRainbow(inout vec3 color, vec3 rayDir, float wsdist) {
    if (isEyeInWater != 0) return;

    // point opposite the sun that the bow is centred on
    vec3 anti = -pSunVec;
    float bowAmount;

    #if RAINBOW == 1
        // After rain: wetness is how soaked the world still is, high just after rain, then it dries out
        bowAmount = clamp01(wetness * 1.6 - 0.2) * (1.0 - rainFactor)
                  * smoothstep(-0.02, 0.08, pSunVec.y)            // sun above the horizon
                  * (1.0 - smoothstep(0.55, 0.75, pSunVec.y));    // and low enough for the bow to be above it
    #else
        // Always: morning, midday and afternoon, but not at sunset or at night. When the sun is high the real
        // bow would sit below the horizon, so it is kept on the horizon: you see its upper arc.
        float horizontal = length(pSunVec.xz);
        anti = vec3(-pSunVec.x, max(-pSunVec.y, 0.0), -pSunVec.z);
        anti = normalize(anti);
        bowAmount = smoothstep(0.17, 0.35, pSunVec.y) * (1.0 - rainFactor)
                  * smoothstep(0.03, 0.12, horizontal) * 0.7;    // a little fainter than after rain
    #endif

    bowAmount *= skylightFactor;                                  // not seen from caves
    if (bowAmount < 0.001) return;

    float ang = degrees(acos(clamp(dot(rayDir, anti), -1.0, 1.0)));
    float x1 = (ang - 40.4) / 2.2;
    vec3 bow = rbHue((1.0 - clamp01(x1)) * 0.78) * smoothstep(-0.15, 0.1, x1) * smoothstep(1.15, 0.9, x1);
    if (dot(bow, bow) < 1e-5) return;

    // the sky shows the whole bow; on terrain it only appears in the distance
    float reach = wsdist > 1e20 ? 1.0 : smoothstep(20.0, 120.0, wsdist);

    // white bow, only slightly tinted by the sunlight colour
    float lum = dot(lightColor, vec3(0.3, 0.5, 0.2));
    vec3 tint = mix(vec3(1.0), lightColor / max(lum, 1e-3), 0.3);

    color += bow * tint * (lum * 0.10 * RAINBOW_BRIGHTNESS) * bowAmount * reach * smoothstep(-0.05, 0.05, rayDir.y);
}

#endif
