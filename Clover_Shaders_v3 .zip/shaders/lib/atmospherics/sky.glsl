#ifndef SKY_GLSL
#define SKY_GLSL

#include "/lib/settings/atmosphereSettings.glsl"
#include "/lib/colors/skyColors.glsl"
#include "/lib/colors/goldenHour.glsl"

#if SKY_ENHANCE == 1
// Golden hour sky (only inside the sunset tick window, see goldenHour.glsl).
vec3 enhanceSky(vec3 sky, float VdotU, float VdotS) {
    float gw = getGoldenWeight();
    if (gw < 0.001) return sky;

    float goldW = clamp01(gw * SKY_GOLDEN_HOUR);
    float extra = max(SKY_GOLDEN_HOUR - 1.0, 0.0); // strength above 1.0 pushes the colours richer

    float h = clamp01(VdotU);

    // Orange horizon, rose band, purple dusk above
    vec3 goldS = mix(vec3(1.00, 0.52, 0.18), vec3(0.30, 0.22, 0.58), pow(h, 0.35));
    goldS = mix(goldS, vec3(0.98, 0.32, 0.34), exp(-pow2((h - 0.10) / 0.09)) * 0.8);
    goldS = mix(vec3(getLuminance(goldS)), goldS, 1.0 + 0.35 * extra);

    vec3 result = mix(sky, goldS, goldW);

    // Keep the original sky below the horizon
    result = mix(sky, result, linearStep(-0.05, 0.03, VdotU));

    // Sun glow: wide warm halo plus a tight core
    float sunAmt = max(VdotS, 0.0);
    float halo   = pow(sunAmt, 6.0) * 0.5 + pow(sunAmt, 64.0) * 1.2;
    vec3 glowCol = vec3(1.0, 0.50, 0.18);
    result += halo * glowCol * SKY_SUN_GLOW * gw;

    return result;
}
#endif

vec3 getSky(float VdotU, float VdotS) {
    vec3 sky = VdotU > 0.0 ? topSkyColor : bottomSkyColor;

    float horizonFactor  = bellCurve(abs(VdotU), 0.075);
    float dawnScattering = bellCurve(abs(VdotU), 0.025) * bellCurve(1.0 - VdotS, 0.08) 
                                                        * pow4(1.0 - min1(abs(pSunVec.y - 0.15)));
    sky = mix(sky, middleSkyColor, horizonFactor);
    sky = mix(sky, dawnScattColor, dawnScattering * 0.2);

    #if SKY_ENHANCE == 1
        sky = enhanceSky(sky, VdotU, VdotS);
    #endif

    float sunAppearance  = linearStep(-0.05, 0.2,  pSunVec.y);
    float moonAppearance = linearStep( 0.05, 0.1, -pSunVec.y);

    float glareFactor = (0.075 / (1.0 - 0.925 * pow2(VdotS)) - 0.075) * min1(2.0 * abs(VdotS));
    if (VdotS > 0.0) {            
        sky += glareFactor * sunAppearance * sunGlareColor;
    } else {
        sky += glareFactor * moonAppearance * moonGlareColor;
    }

    return sky + (dither_ign - 0.5) / 127.5;
}

#endif