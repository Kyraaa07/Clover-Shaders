#ifndef REALISTIC_SKY_GLSL
#define REALISTIC_SKY_GLSL

// Realistic night sky: star field, Milky Way and aurora.
//  glsl: getStarField, getMilkyWay, getAurora).
// The original is written for an HDR pipeline with eye adaptation, so the gains below are
// retuned for Clover's sky, which goes straight to the display.
//
// Needs: common.glsl (uniforms, math), atmosphereSettings.glsl, lightingSettings.glsl (SUN_ANGLE)

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/settings/atmosphereSettings.glsl"

// Overall gains (overall). Tweak here if the whole sky is too dim or too bright.
#define RS_STAR_GAIN   10.0
#define RS_MILKY_GAIN  0.350
#define RS_AURORA_GAIN 0.120

// ----------------------------- noise -----------------------------
float rsHash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float rsHash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

float rsNoise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = rsHash12(i);
    float b = rsHash12(i + vec2(1.0, 0.0));
    float c = rsHash12(i + vec2(0.0, 1.0));
    float d = rsHash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float rsNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float n000 = rsHash13(i);
    float n100 = rsHash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = rsHash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = rsHash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = rsHash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = rsHash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = rsHash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = rsHash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
}

float rsTime() {
    return mod(frameTimeCounter, 3600.0);
}

// ----------------------------- sky frame -----------------------------
// A frame that turns with the sun, so the stars and the Milky Way wheel across the
// sky during the night instead of sliding sideways. The turning axis follows the sun path tilt.
mat3 rsCelestialFrame(vec3 sunDir) {
    float r = radians(float(SUN_ANGLE));
    vec3 axis = normalize(vec3(0.0, sin(r), cos(r)));
    axis = normalize(axis - dot(axis, sunDir) * sunDir + vec3(1e-4, 0.0, 0.0));
    vec3 e2 = normalize(cross(axis, sunDir));
    return mat3(sunDir, e2, axis);
}

// How much of the atmosphere the light of a star crosses: reddens and dims low stars.
vec3 rsExtinction(float y) {
    float c = clamp(y, 0.0, 1.0);
    float z = degrees(acos(c));
    float airMass = 1.0 / (c + 0.50572 * pow(96.07995 - z, -1.6364));
    return exp(-vec3(0.0861, 0.1556, 0.2851) * airMass);
}

// 1 at night, fades out with the horizon, with dawn / dusk and in rain.
float rsNightVisibility(float y) {
    return linearStep(-0.06, 0.34, y) * linearStep(0.15, -0.10, pSunVec.y) * invRainFactor;
}

// ----------------------------- stars -----------------------------
vec3 getRealisticStars(vec3 dir) {
    // keep the area around the sun / moon clear, like the classic stars do
    float celestial = linearStep(0.997, 0.995, abs(dot(dir, pSunVec)));
    float visibility = rsNightVisibility(dir.y) * celestial;
    if (visibility < 1e-4) return vec3(0.0);

    vec3 p = transpose(rsCelestialFrame(pSunVec)) * dir;

    // STAR_SCALE = size of the stars (bigger = larger and fewer), STAR_AMOUNT = share of cells with a star
    float freq    = 390.0 / STAR_SCALE;
    float density = STAR_AMOUNT * 0.09;

    vec3 q = p * freq;
    vec3 cell = floor(q);
    float h = rsHash13(cell);
    if (h < 1.0 - density) return vec3(0.0);

    vec3 off = vec3(rsHash13(cell + 1.7), rsHash13(cell + 3.1), rsHash13(cell + 5.9)) - 0.5;
    float d = length(fract(q) - 0.5 - off * 0.5);

    // stars are points: keep them about one pixel wide, and spread the same light over the disc
    float pixelAngle = 2.0 / (max(gbufferProjection[1][1], 0.1) * viewHeight);
    float radius = max(0.07, pixelAngle * freq * 0.75);
    float energy = 0.07 / radius;

    float mag     = pow((h - (1.0 - density)) / density, 4.0);                            // few bright, many faint
    float twinkle = 0.75 + 0.25 * sin(mod(frameTimeCounter, 1000.0) * (2.0 + h * 9.0) + h * 400.0);
    float temp    = rsHash13(cell + 9.3);                                                  // colour temperature
    vec3 col = mix(vec3(1.0, 0.72, 0.52), vec3(0.72, 0.82, 1.0), temp);
    col = mix(col, vec3(1.0), 0.4);

    vec3 star = col * (1.0 - smoothstep(0.0, radius, d)) * energy * (0.15 + mag * 2.5) * twinkle * 0.5;
    return star * rsExtinction(dir.y) * visibility * (RS_STAR_GAIN * STAR_BRIGHTNESS);
}

// ----------------------------- Milky Way -----------------------------
vec3 getMilkyWay(vec3 dir) {
    float visibility = rsNightVisibility(dir.y);
    if (visibility < 1e-4) return vec3(0.0);

    vec3 p = transpose(rsCelestialFrame(pSunVec)) * dir;

    const vec3 galacticPole = vec3(0.42, 0.82, 0.39);
    const vec3 galacticCore = vec3(0.86, -0.25, -0.44);

    float b = dot(p, normalize(galacticPole));
    float band = exp(-b * b * 22.0);
    if (band < 0.01) return vec3(0.0);

    float core   = pow(clamp01(dot(p, normalize(galacticCore)) * 0.5 + 0.5), 4.0);
    float clouds = rsNoise3D(p * 7.0) * 0.6 + rsNoise3D(p * 17.0) * 0.4;
    float dust   = smoothstep(0.35, 0.75, rsNoise3D(p * 11.0 + 4.0) * 0.7 + rsNoise3D(p * 26.0) * 0.3);
    float lane   = exp(-b * b * 300.0) * 0.6;                       // dark rift through the middle

    float i = band * (0.35 + 0.65 * clouds) * (1.0 - dust * 0.65) * (1.0 - lane) * (0.6 + core * 2.5);
    vec3 col = mix(vec3(0.62, 0.70, 1.0), vec3(1.0, 0.86, 0.68), core);

    return col * i * rsExtinction(dir.y) * visibility * (RS_MILKY_GAIN * MILKY_WAY_BRIGHTNESS);
}

// ----------------------------- Aurora -----------------------------
// dir: world space direction. layers: number of curtain layers (more = smoother, slower).
// The caller applies night / rain / underground visibility.
vec3 getRealisticAurora(vec3 dir, int layers, float dither) {
    if (dir.y < 0.02) return vec3(0.0);

    float invLayers = 1.0 / float(layers);
    float t = rsTime() * 0.03;
    vec3 sum = vec3(0.0);

    for (int i = 0; i < layers; i++) {
        float fi = (float(i) + dither) * invLayers;
        float h = 1.0 + fi * 0.9;
        vec2 uv = dir.xz / (dir.y + 0.05) * h * 0.55;

        float warp = rsNoise2D(uv * 0.6 + vec2(t, -t * 0.5)) * 2.0;
        float ribbon = 1.0 - abs(rsNoise2D(vec2(uv.x * 0.9 + warp, uv.y * 0.25) + t) * 2.0 - 1.0);
        ribbon = pow(ribbon, 10.0) * (0.6 + 0.4 * rsNoise2D(uv * 6.0 + t * 4.0));

        vec3 col = mix(vec3(0.15, 1.0, 0.45), vec3(0.55, 0.2, 1.0), fi * fi);
        sum += col * ribbon * (1.0 - fi);
    }

    // normalised by layer count so quality only changes smoothness, not brightness
    return sum * (16.0 * invLayers) * smoothstep(0.02, 0.3, dir.y) * (RS_AURORA_GAIN * AURORA_BRIGHTNESS);
}

#endif
