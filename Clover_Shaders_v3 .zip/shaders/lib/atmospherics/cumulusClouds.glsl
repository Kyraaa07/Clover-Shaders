#ifndef CUMULUS_CLOUDS_GLSL
#define CUMULUS_CLOUDS_GLSL

// Volumetric clouds and cirrus.
//  
//
//  - Volumetric clouds (Cloud Type: Cumulus): real 3D cumulus that are ray marched, with flat bases,
//    rounded billowy tops, self-shadowing toward the sun and multiple scattering (bright, soft interiors).
//    Shares Clover's cloud sliders: Height, Thickness, Scale, Amount, Density, Detail, Speed, Opacity, Brightness.
//  - Cirrus clouds: thin, wind-stretched ice clouds high above, drawn on the sky for every cloud type.
//
// Entry points: DoClouds (same signature as realistClouds.glsl) and DoCirrus (sky pixels only).
// Needs: common.glsl, dither.glsl, lightingColors.glsl (lightColor / ambientColor)

#include "/lib/colors/lightingColors.glsl"
#include "/lib/lighting/phaseFunctions.glsl"
#include "/lib/settings/atmosphereSettings.glsl"

// These light the clouds in HDR; these bring them into Clover's range (tune with Cloud Brightness)
#define HC_LIGHT_GAIN   0.45
#define HC_AMBIENT_GAIN 2.00

// ----------------------------- noise -----------------------------
float hcHash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float hcHash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

float hcNoise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hcHash12(i);
    float b = hcHash12(i + vec2(1.0, 0.0));
    float c = hcHash12(i + vec2(0.0, 1.0));
    float d = hcHash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float hcNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float n000 = hcHash13(i);
    float n100 = hcHash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = hcHash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = hcHash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = hcHash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = hcHash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = hcHash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = hcHash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
}

// ----------------------------- shared -----------------------------
const vec2 hcWindDir = vec2(0.8192, 0.5736); // 35 degrees, one wind for every cloud layer

float hcTime() {
    return mod(frameTimeCounter, 3600.0);
}

// 1 in the day, 0 at night (same ramp as the Realist clouds)
float hcSunVisibility() {
    return clamp(pSunVec.y + 0.15, 0.0, 0.25) * 4.0;
}

// brightness of clouds: slider, darker in rain, lifted at night so they are not near-black
float hcBrightness() {
    float rain = 1.0 - 0.4 * rainFactor;
    float night = mix(CLOUD_NIGHT_BRIGHTNESS * 0.5, 1.0, hcSunVisibility());
    return CLOUD_BRIGHTNESS * rain * night;
}

// ----------------------------- cirrus -----------------------------
// Thin wind-stretched ice clouds on a sky plane far above the cumulus. dir: world space, sky pixels only.
void DoCirrus(inout vec3 color, vec3 dir) {
    if (dir.y < 0.02) return;

    float time = hcTime();
    vec2 p = dir.xz / (dir.y + 0.04) * 3.2 + cameraPosition.xz * 0.0002;
    p += hcWindDir * time * 0.006 * CLOUD_SPEED;
    vec2 q = vec2(p.x * 0.55 + p.y * 0.35, p.y * 1.9 - p.x * 0.2);  // streaks

    float n = hcNoise2D(q * 1.3) * 0.50 + hcNoise2D(q * 3.1 + 2.7) * 0.27
            + hcNoise2D(q * 6.1 + 5.1) * 0.16 + hcNoise2D(q * 13.0 + 1.3) * 0.07;
    float patches = smoothstep(0.42, 0.78, hcNoise2D(p * 0.32 + 11.0) * 0.7 + hcNoise2D(p * 0.8 + 3.0) * 0.3);

    float cov = CIRRUS_COVERAGE + rainFactor * 0.25;
    float d = clamp01((n - (1.0 - cov)) * 2.4) * patches * smoothstep(0.02, 0.25, dir.y);
    if (d < 0.002) return;

    vec3 lightDir = pSunVec * sign(pSunVec.y);
    float lightFade = min1(20.0 * abs(pSunVec.y));
    float mu = dot(dir, lightDir);

    // silver lining toward the light, capped so it does not clip the whole sky
    float glow = min(henyeyGreenstein(mu, 0.75) * 4.0 * pi * 0.3, 1.2);
    vec3 col = lightColor * HC_LIGHT_GAIN * (glow + 0.35) * lightFade + ambientColor * HC_AMBIENT_GAIN;
    col *= hcBrightness();

    float a = d * 0.5;
    color = mix(color, col, a);
}

// ----------------------------- volumetric clouds -----------------------------
#ifdef CUMULUS_CLOUDS_INTERNAL

const float hcThickness = CLOUD_THICKNESS * 50.0;        // blocks (slider 2..16 -> 100..800)
const float hcScale     = CLOUD_SCALE / 20.0;            // slider 4..20 -> 0.2..1.0 (bigger = wider clouds)
const float hcCoverage  = clamp((13.0 - CLOUD_AMOUNT) * 0.15, 0.10, 0.80);
const float hcSigma     = 0.06 * float(CLOUD_DENSITY) / 4.0;

#if CLOUD_QUALITY == 1
    #define HC_STEPS 12
    #define HC_LIGHT_STEPS 3
#elif CLOUD_QUALITY == 2
    #define HC_STEPS 20
    #define HC_LIGHT_STEPS 5
#else
    #define HC_STEPS 32
    #define HC_LIGHT_STEPS 5
#endif

float hcCloudDensity(vec3 p, bool detail) {
    float time = hcTime();
    vec3 wind = vec3(hcWindDir.x, 0.0, hcWindDir.y) * time * 8.0 * CLOUD_SPEED;
    vec3 q = (p + wind) * (0.0016 / hcScale);

    float h = clamp01((p.y - float(CLOUD_HEIGHT)) / hcThickness);
    // flat bases, rounded tops that narrow with height (cumulus)
    float profile = smoothstep(0.0, 0.07, h) * smoothstep(1.0, 0.55, h);
    if (profile <= 0.0) return 0.0;

    float base = hcNoise3D(q) * 0.60 + hcNoise3D(q * 2.4 + 13.1) * 0.28 + hcNoise3D(q * 5.3 + 3.3) * 0.12;
    float cov = clamp01(hcCoverage + rainFactor * 0.55);                 // rain closes the sky
    float thr = 1.0 - cov * 0.92 + h * 0.18;
    float d = (base - thr) / max(1.0 - thr, 0.05);
    if (d <= -0.15) return 0.0;

    if (detail) {
        // billowy erosion: puffs and cauliflower edges, only eats into thin parts
        vec3 dq = q * 8.5 + vec3(0.0, -time * 0.0015, 0.0);
        float e = hcNoise3D(dq) * 0.62 + hcNoise3D(dq * 2.3 + 7.0) * 0.38;
        float billow = 1.0 - abs(e * 2.0 - 1.0);
        d -= (1.0 - billow) * 0.32 * (CLOUD_DETAIL / 0.7) * (1.0 - clamp01(d));
    } else {
        d -= 0.12;
    }
    return clamp01(d * 1.8) * profile;
}

float hcPhase(float mu, float g) {
    return henyeyGreenstein(mu, g) * 4.0 * pi;
}

void DoClouds(inout vec3 color, vec3 rayOrigin, vec3 rayDir, float wsdist, inout float cloudDepth) {
    if (isEyeInWater > 1) return;

    bool isSky = wsdist > 1e20;

    vec3 dir = rayDir;
    if (abs(dir.y) < 1e-4) dir.y = dir.y < 0.0 ? -1e-4 : 1e-4;

    float lowerY = float(CLOUD_HEIGHT);
    float upperY = lowerY + hcThickness;

    // where the ray enters and leaves the cloud layer (works from below, inside and above it)
    float t0 = (lowerY - rayOrigin.y) / dir.y;
    float t1 = (upperY - rayOrigin.y) / dir.y;
    float tStart = max(min(t0, t1), 0.0);
    float tEnd   = max(t0, t1);
    if (tEnd <= 0.0) return;

    // terrain in front of the layer hides every cloud sample: skip the whole march
    if (!isSky && wsdist < tStart) return;

    tEnd = min(tEnd, tStart + 3500.0);
    if (!isSky) tEnd = min(tEnd, wsdist);
    if (tEnd <= tStart) return;

    int nSteps = int(mix(float(HC_STEPS) * 0.45, float(HC_STEPS), clamp01((tEnd - tStart) / (hcThickness * 3.0))));
    nSteps = max(nSteps, 1);
    float stepLen = (tEnd - tStart) / float(nSteps);

    vec3 lightDir = pSunVec * sign(pSunVec.y);
    float lightFade = min1(20.0 * abs(pSunVec.y));
    float mu = dot(dir, lightDir);

    float lightStepBase = 14.0 * hcThickness / 300.0;

    vec3 scatter = vec3(0.0);
    float T = 1.0;
    float tHit = -1.0;

    for (int i = 0; i < HC_STEPS; i++) {
        if (i >= nSteps) break;

        float t = tStart + stepLen * (float(i) + dither_ign);
        vec3 p = rayOrigin + dir * t;
        float d = hcCloudDensity(p, true);
        if (d < 0.003) continue;

        // optical depth toward the light, steps grow with distance
        float od = 0.0;
        float lt = 0.0;
        int lightSteps = T > 0.3 ? HC_LIGHT_STEPS : min(3, HC_LIGHT_STEPS); // deep inside, little of this light reaches you
        for (int j = 0; j < HC_LIGHT_STEPS; j++) {
            if (j >= lightSteps) break;
            float ls = lightStepBase * pow(1.8, float(j));
            od += hcCloudDensity(p + lightDir * (lt + ls * 0.5), false) * ls;
            lt += ls;
        }
        od *= hcSigma * 1.35;   // a little more self-shadowing: rounder, more solid clouds

        // multiple scattering approximation: each octave is light that bounced again,
        // less attenuated and less forward peaked -> bright, soft cloud interiors
        float lightE = 0.0;
        float a = 1.0;
        float b = 1.0;
        float c = 1.0;
        for (int o = 0; o < 3; o++) {
            float ph = mix(hcPhase(mu, 0.8 * c), hcPhase(mu, -0.3 * c), 0.3);
            lightE += a * exp(-od * b) * ph;
            a *= 0.55;
            b *= 0.4;
            c *= 0.5;
        }
        // "powder": the sunlit side of thick clouds has darker edges
        float powder = 1.0 - exp(-d * 2.0 * stepLen * hcSigma);
        lightE *= mix(1.0, mix(0.55, 1.0, powder), clamp01(mu * 0.5 + 0.5));

        float h = clamp01((p.y - lowerY) / hcThickness);
        vec3 amb = ambientColor * HC_AMBIENT_GAIN * mix(0.22, 1.2, h * h * (3.0 - 2.0 * h)); // sky above, darker flat bases
        vec3 S = lightColor * (lightE * 0.9 * HC_LIGHT_GAIN * lightFade) + amb;

        float stepT = exp(-d * hcSigma * stepLen);
        scatter += T * S * (1.0 - stepT);
        T *= stepT;

        if (tHit < 0.0 && T < 0.5) tHit = t;
        if (T < 0.02) break;
    }

    // far clouds melt into the haze
    float tMid = (tStart + tEnd) * 0.5;
    float fade = exp(-tMid * 0.00018) * smoothstep(0.015, 0.08, abs(dir.y));

    // Fade out when far below the world
    fade *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);

    float coverage = (1.0 - T) * fade * CLOUD_OPACITY;
    float Tfinal = 1.0 - min1(coverage);
    color = color * Tfinal + scatter * (fade * CLOUD_OPACITY * hcBrightness());

    // Depth used to cull translucents behind the clouds (view-space z distance, same encoding as the other clouds)
    if (tHit >= 0.0 && coverage >= dither_ign) {
        float viewZScale = -(gbufferModelView * vec4(rayDir, 0.0)).z;
        float zDist = tHit * viewZScale;
        cloudDepth = min1(floor(zDist * 191.25 / far + dither_ign) / 255.0);
    }
}

#endif // CUMULUS_CLOUDS_INTERNAL

#endif
