// "blocky cloud" clouds.
// Blocky clouds
//   (lib/atmospherics/clouds/mainClouds.glsl, reimaginedClouds.glsl, cloudCoord.glsl, lib/colors/cloudColors.glsl)
// Replaces the old Blocky voxel clouds. Same entry point as the Realist clouds (realistClouds.glsl) so
// deferred.glsl / translucent depth culling work unchanged.
// Noise texture (the original cloud-water.png, 256x256, noise in the blue channel) is bound to colortex2
// in the deferred stage (see shaders.properties).

#include "/lib/atmospherics/sky.glsl"
#include "/lib/colors/lightingColors.glsl"
#include "/lib/lighting/phaseFunctions.glsl"

// blocky cloud uses cloudNarrowness = 0.07 -> 1 noise cell ~ 14.3 blocks. CLOUD_SCALE 10 (default) reproduces that exactly.
const float cmCloudNarrowness = 0.7 / CLOUD_SCALE;
// blocky cloud uses a half-thickness (cloudStretch) of 4.2. CLOUD_THICKNESS 4.0 (default) -> 4.2
const float cmCloudStretch    = CLOUD_THICKNESS * 1.05;
const float cmCloudTallness   = cmCloudStretch * 2.0;
const float cmCloudRoundness  = 0.125;
const float cmDistanceThreshold = 4000.0;

// the original light / ambient colours are on a different scale than Clover's.
// Light is already ~1.6x brighter in Clover, so it is used as-is. Clover's ambient is far dimmer and much bluer,
// so for clouds it is desaturated a bit and lifted to match the original ambient-to-light ratio.
// If the clouds look too bright / dark overall, use the Cloud Brightness slider.
const float cmAmbientDesat = 0.5;
const float cmAmbientGain  = 3.8;
const float cmRainGain     = 1.6;

float cmCloudIGN() {
    float n = 52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y);
    return fract(n + 1.61803398875 * mod(float(frameCounter), 3600.0));
}

// 
vec2 cmRoundedCloudCoord(vec2 pos, float cloudRoundness) {
    vec2 coord = pos.yx + 0.5;
    vec2 signCoord = sign(coord);
    coord = abs(coord) + 1.0;
    vec2 i, f = modf(coord, i);
    f = smoothstep(0.5 - cloudRoundness, 0.5 + cloudRoundness, f);
    coord = i + f;
    return (coord - 0.5) * signCoord / 256.0;
}

vec3 cmModifyTracePos(vec3 tracePos, int cloudAltitude, float wind) {
    tracePos.z -= wind;
    tracePos.x += float(cloudAltitude) * 64.0;
    tracePos.xz *= cmCloudNarrowness;
    return tracePos;
}

float cmCloudSample(vec2 pos) {
    return textureLod(colortex2, cmRoundedCloudCoord(pos, cmCloudRoundness), 0.0).b;
}

bool cmGetCloudNoise(vec3 tracePos, inout vec3 tracePosM, int cloudAltitude, float wind) {
    tracePosM = cmModifyTracePos(tracePos, cloudAltitude, wind);
    float noise = cmCloudSample(tracePosM.xz);

    float threshold = clamp(abs(float(cloudAltitude) - tracePos.y) / cmCloudStretch, 0.001, 0.999);
    threshold = pow2(pow2(pow2(threshold)));
    return noise > threshold * 0.5 + 0.25;
}

void DoClouds(inout vec3 color, vec3 rayOrigin, vec3 rayDir, float wsdist, inout float cloudDepth) {
    if (isEyeInWater > 1) return;

    vec3 nPlayerPos = rayDir;
    if (abs(nPlayerPos.y) < 1e-4) nPlayerPos.y = nPlayerPos.y < 0.0 ? -1e-4 : 1e-4;

    const int cloudAltitude = int(CLOUD_HEIGHT);
    vec3 cameraPos = rayOrigin;

    // -- Sky / terrain handling -- //
    // Sky pixels see the whole cloud layer. Terrain (incl. Voxy LODs) always hides clouds that are behind it;
    // clouds in front of terrain are still drawn.
    bool isSky = wsdist > 1e20;
    float skyFade  = isSky ? 1.0 : 0.0;
    float skyMult0 = pow2(skyFade * 3.333333 - 2.333333);
    float lViewPosM = isSky ? 1e9 : wsdist - 1.0;

    // -- Time of day inputs (blocky cloud names, Clover sources) -- //
    float SdotU = pSunVec.y;
    float sunVisibility  = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
    float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
    float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
    float shadowTime     = shadowTimeVar2 * shadowTimeVar2;

    vec3 pLightVec = pSunVec.y >= 0.0 ? pSunVec : -pSunVec;

    float VdotU = nPlayerPos.y;
    float VdotS = dot(nPlayerPos, pSunVec);
    float rainFactor2 = rainFactor * rainFactor;

    // -- Cloud colours (cloudColors.glsl + the "Reimagined" tweaks of GetClouds) -- //
    vec3 cloudAmbientBase = mix(vec3(getLuminance(ambientColor)), ambientColor, cmAmbientDesat) * cmAmbientGain;
    vec3 cloudRainColor = middleSkyColor * cmRainGain;
    vec3 cloudAmbientColor = mix(
        cloudAmbientBase * (sunVisibility2 * (0.55 + 0.17 * noonFactor) + 0.35),
        cloudRainColor * 0.5,
        rainFactor
    );
    vec3 cloudLightColor = mix(
        lightColor * 1.3,
        cloudRainColor * 0.45,
        noonFactor * rainFactor
    );
    cloudAmbientColor *= 1.0 - 0.25 * rainFactor;
    cloudAmbientColor *= CLOUD_BRIGHTNESS;
    cloudLightColor   *= CLOUD_BRIGHTNESS;
    // Lift clouds at night so they are not near-black (1.0 in daytime)
    float cloudNightLift = mix(CLOUD_NIGHT_BRIGHTNESS, 1.0, sunVisibility);
    cloudAmbientColor *= cloudNightLift;
    cloudLightColor   *= cloudNightLift;

    // -- Ray / slab setup -- //
    float higherPlaneAltitude = float(cloudAltitude) + cmCloudStretch;
    float lowerPlaneAltitude  = float(cloudAltitude) - cmCloudStretch;

    float lowerPlaneDistance  = (lowerPlaneAltitude  - cameraPos.y) / nPlayerPos.y;
    float higherPlaneDistance = (higherPlaneAltitude - cameraPos.y) / nPlayerPos.y;
    float minPlaneDistance = max(min(lowerPlaneDistance, higherPlaneDistance), 0.0);
    float maxPlaneDistance = max(lowerPlaneDistance, higherPlaneDistance);
    if (maxPlaneDistance < 0.0) return;
    float planeDistanceDif = maxPlaneDistance - minPlaneDistance;

    float aboveClouds = clamp((cameraPos.y - lowerPlaneAltitude) * 0.05, 0.0, 1.0);
    float skyFadeM = mix(skyFade, 1.0, 0.4 * max(aboveClouds, rainFactor2));

    #if CLOUD_QUALITY == 1
        int sampleCount = max(int(planeDistanceDif) / 16, 6);
    #elif CLOUD_QUALITY == 2
        int sampleCount = max(int(planeDistanceDif) / 8, 12);
    #else
        int sampleCount = max(int(planeDistanceDif), 12);
    #endif
    sampleCount = min(sampleCount, 256); // safety cap, only reached when looking almost exactly at the horizon

    float dither = dither_ign;

    float stepMult = planeDistanceDif / float(sampleCount);
    vec3 traceAdd = nPlayerPos * stepMult;
    vec3 tracePos = cameraPos + minPlaneDistance * nPlayerPos;
    tracePos += traceAdd * dither;
    tracePos.y -= traceAdd.y;

    // Same drift speed as blocky cloud (1 block / second at speed 1.0), synced to the world clock
    float wind = (float(worldTime) + 24000.0 * float(worldDay % 128)) * 0.05 * CLOUD_SPEED;

    vec4 cloudResult = vec4(0.0);
    float cloudHitDist = 0.0;

    for (int i = 0; i < sampleCount; i++) {
        tracePos += traceAdd;

        vec3 cloudPlayerPos = tracePos - cameraPos;
        float lTracePos = length(cloudPlayerPos);
        float lTracePosXZ = length(cloudPlayerPos.xz);
        float cloudMult = 1.0;
        if (lTracePosXZ > cmDistanceThreshold) break;
        if (lTracePos > lViewPosM) {
            if (skyFade < 0.7) continue;
            else cloudMult = skyMult0;
        }

        vec3 tracePosM;
        if (cmGetCloudNoise(tracePos, tracePosM, cloudAltitude, wind)) {
            float cloudShading = 1.0 - (higherPlaneAltitude - tracePos.y) / cmCloudTallness;
                  cloudShading = pow(max(cloudShading, 0.0), 0.8);
            float VdotSM1 = max(sunVisibility > 0.5 ? VdotS : -VdotS, 0.0);

            #if CLOUD_QUALITY >= 2
                float cloudShadingM = 1.0 - pow2(cloudShading);

                float gradientNoise = cmCloudIGN();

                vec3 cLightPos = tracePosM;
                vec3 cLightPosAdd = pLightVec * 0.08 * shadowTime;

                float light = 2.0;
                cLightPos += (1.0 + gradientNoise) * cLightPosAdd;
                    light -= cmCloudSample(cLightPos.xz) * cloudShadingM;
                cLightPos += gradientNoise * cLightPosAdd;
                    light -= cmCloudSample(cLightPos.xz) * cloudShadingM;

                float VdotSM2 = VdotSM1 * shadowTime * 0.25;
                      VdotSM2 += 0.5 * cloudShading + 0.08;
                cloudShading = VdotSM2 * light;
            #endif

            vec3 colorSample = cloudAmbientColor * 0.95 * (1.0 - 0.35 * cloudShading) + cloudLightColor * 0.9 * (0.1 + cloudShading);
            vec3 cloudSkyColor = getSky(VdotU, VdotS);

            float distanceRatio = (cmDistanceThreshold - lTracePosXZ) / cmDistanceThreshold;
            float cloudFogFactor = pow2(clamp(distanceRatio, 0.0, 1.0)) * 0.707;
            cloudFogFactor = mix(1.0, cloudFogFactor, skyFadeM);
            colorSample *= 1.0 - 0.2 * (1.0 - skyFadeM) * max(sunVisibility2, nightFactor);
            colorSample = mix(cloudSkyColor, colorSample, cloudFogFactor * 0.707);

            float cloudDistanceFactor = clamp(distanceRatio, 0.0, 0.75);

            cloudResult.a = sqrt(cloudDistanceFactor * 1.33333) * cloudMult;
            cloudResult.rgb = colorSample;
            cloudHitDist = lTracePos;
            break;
        }
    }

    cloudResult.a *= 0.5 + 0.5 * skyFadeM;
    cloudResult.a *= CLOUD_OPACITY;
    cloudResult.a = min(cloudResult.a, 1.0);

    if (cloudResult.a <= 0.0) return;

    color = mix(color, cloudResult.rgb, cloudResult.a);

    // Depth used to cull translucents behind the clouds (view-space z distance, same encoding as the Realist clouds)
    if (cloudResult.a >= dither) {
        float viewZScale = -(gbufferModelView * vec4(nPlayerPos, 0.0)).z;
        float zDist = cloudHitDist * viewZScale;
        cloudDepth = min(floor(zDist * 191.25 / far + dither_ign) / 255.0, 1.0);
    }
}
