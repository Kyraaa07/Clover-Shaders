#include "/lib/util/packing.glsl"
#include "/lib/colors/lightingColors.glsl"
#include "/lib/lighting/phaseFunctions.glsl"

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/settings/atmosphereSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"

vec3 getShadowSample(vec3 shadowScreen) {
    if (isOutOfBounds(shadowScreen.xy)) return vec3(1.0);

    uvec3 data = texelFetch(colortex1, ivec2(shadowScreen * 1024.0), 0).rgb;

    uint compare = uint(shadowScreen.z * 65535.0);

    if (data.r > compare) return vec3(1.0);
    if (data.g < compare) return vec3(0.0);

    return shadowColorRange * unpack1_2x5b_6b(data.b);
}

// Sample count at full length: 1 = 8, 2 = 12, 3 = 16, 4 = 24. Short rays use fewer.
#if LIGHTSHAFT_QUALITY == 1
    #define LS_STEPS 8
#elif LIGHTSHAFT_QUALITY == 2
    #define LS_STEPS 12
#elif LIGHTSHAFT_QUALITY == 3
    #define LS_STEPS 16
#else
    #define LS_STEPS 24
#endif

// Does the ray from p toward the light pass through the player's own body (a capsule from
// the feet to just above the eye)? Rays in the haze should not carry the camera's own shadow:
// seen from inside, it turns into a dark beam pointing at the view.
bool lsBehindOwnBody(vec3 p, vec3 L, vec3 feet, vec3 axis) {
    vec3 w0 = p - feet;
    float b = dot(L, axis);
    float axis2 = dot(axis, axis);
    float den = axis2 - b * b;                         // |L| = 1
    float s = den > 1e-5 ? (b * dot(axis, w0) - axis2 * dot(L, w0)) / den : 0.0;
    s = max(s, 0.0);                                   // only toward the light
    float k = clamp01(dot(w0 + L * s, axis) / axis2);
    vec3 c = feet + axis * k;
    s = max(dot(c - p, L), 0.0);
    return length(p + L * s - c) < 0.75;
}

// Volumetric light shafts, volumetric light shafts:
//  - ground-hugging mist that drifts in patches, so shafts break up instead of being a flat haze
//  - two-lobe phase function: a tight glare toward the light plus a soft wide glow
//  - shafts at every time of day (LIGHTSHAFT_DAY_STRENGTH), much stronger when the sun is low
//  - adaptive sample count and no self-shadow beam from the player's own body
void DoLightshafts(inout vec3 color, vec3 rayDir, float wsdist) {
    // vl strength is computed first so we can exit early
    float vlStrength = pow3(min1(20.0 * abs(pSunVec.y)));

    if (!isCamInWater) {
        float caveFactor   = 0.5 - 0.5 * skylightFactor;
        float sunsetFactor = pow2(invNoonFactor - nightFactor);

        float base   = LIGHTSHAFT_DAY_STRENGTH * mix(1.0, 0.45, nightFactor); // moon shafts are weaker
        float sunset = min1(1.0 - rayDir.y) * sunsetFactor;                     // low sun: dense, glowing shafts

        vlStrength *= max(caveFactor, base + (1.0 - base) * sunset);
    }

    if (vlStrength < 0.02) return;
    vlStrength *= linearStep(0.02, 0.04, vlStrength);
    vlStrength *= LIGHTSHAFT_STRENGTH;

    float maxLen = min(wsdist, far);
    maxLen = isCamInWater ? min(maxLen, min(96.0, float(SHADOW_DISTANCE)))
                          : min(maxLen, float(SHADOW_DISTANCE) * 0.9);   // beyond the shadow map there are no shafts to see

    int   samplecount = int(clamp(maxLen / 2.5, min(6.0, float(LS_STEPS)), float(LS_STEPS)));
    float stepLength  = maxLen / float(samplecount);

    vec3 shadowDir = diag(shadowProjection) * (mat3(shadowModelView) * rayDir);
    vec3 shadowCam = diag(shadowProjection) * shadowModelView[3].xyz + shadowProjection[3].xyz;

    vec3 rayStep = shadowDir * stepLength;
    vec3 rtPos = shadowCam + rayStep * dither_ign;

    // Clover's Atmosphere is composed of some very special substance..
    vec3 scCoeff = isCamInWater ? vec3(1.5, 5.0, 8.0) * 1e-2 : vec3(5.6, 6.0, 8.0) * 1e-3;

    // direction toward the light that is up (sun by day, moon by night)
    vec3 lightDir = pSunVec * sign(pSunVec.y);
    float VdotL = dot(rayDir, lightDir);
    float phase = isCamInWater ? henyeyGreenstein(VdotL, 0.3)
                               : 0.7 * henyeyGreenstein(VdotL, 0.65) + 0.3 * henyeyGreenstein(VdotL, 0.2);

    vec3 stepScatter = (phase * stepLength * vlStrength) * scCoeff * lightColor;

    // the player's body, in player space (camera sits at the eye)
    vec3 eye  = dot(relativeEyePosition, relativeEyePosition) > 100.0 ? vec3(0.0) : -relativeEyePosition;
    vec3 feet = eye - vec3(0.0, 1.62, 0.0);
    const vec3 bodyAxis = vec3(0.0, 1.85, 0.0);

    float mist = 1.0 + rainFactor;
    vec2 drift = vec2(frameTimeCounter * 0.0006, frameTimeCounter * 0.0003);

    vec3 transmit = vec3(1.0);
    vec3 scatter  = vec3(0.0);

    for (int i = 0; i < LS_STEPS; i++) {
        if (i >= samplecount) break;

        float t  = stepLength * (float(i) + dither_ign);
        vec3 pos = rayDir * t;

        float density = 1.0;
        if (!isCamInWater) {
            vec3 wp = pos + cameraPosition;
            // mist collects near the ground and drifts in patches
            float height = 0.3 + 0.9 * exp(-max(wp.y - 62.0, 0.0) * 0.02);
            float patches = 0.5 + textureLod(noisetex, wp.xz * 0.0006 + wp.y * 0.0003 + drift, 0.0).r;
            density = height * patches * mist;
        }

        vec3 shadow = lsBehindOwnBody(pos, lightDir, feet, bodyAxis)
                    ? vec3(1.0)
                    : getShadowSample(getDistortedPos(rtPos) * 0.5 + 0.5);

        scatter  += transmit * shadow * density;
        transmit *= exp(-scCoeff * (stepLength * density));

        rtPos += rayStep;
    }
    scatter *= stepScatter;

    color += scatter;
}
