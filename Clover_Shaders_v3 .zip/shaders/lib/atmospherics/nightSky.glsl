#ifndef NIGHT_SKY_GLSL
#define NIGHT_SKY_GLSL

// Aurora Borealis and Night Nebula,  
// Only the "Reimagined" aurora style and the default nebula colours are ported.

#define NS_PI 3.14159265358

// 1 during the day, 0 at night (same ramp as the star code)
float nsSunVisibility() {
    return linearStep(-0.10, 0.15, pSunVec.y);
}

// 1 at night, 0 during the day
float nsNightVisibility() {
    return 1.0 - nsSunVisibility();
}

float nsTime() {
    return mod(frameTimeCounter, 3600.0);
}

// ----------------------------- Aurora -----------------------------

// ----------------------------- Aurora -----------------------------
//  

#ifndef AURORA_LR
    #define AURORA_LR 80
    #define AURORA_LG 255
    #define AURORA_LB 180
    #define AURORA_LI 1.00
    #define AURORA_HR 80
    #define AURORA_HG 80
    #define AURORA_HB 255
    #define AURORA_HI 1.00
#endif

vec3 auroraLowColSqrt  = vec3(AURORA_LR, AURORA_LG, AURORA_LB) * AURORA_LI / 255.0;
vec3 auroraLowCol      = auroraLowColSqrt * auroraLowColSqrt;
vec3 auroraHighColSqrt = vec3(AURORA_HR, AURORA_HG, AURORA_HB) * AURORA_HI / 255.0;
vec3 auroraHighCol     = auroraHighColSqrt * auroraHighColSqrt;

float nsAuroraSample(vec2 coord, vec2 wind, float VoU) {
    float noise = texture(noisetex, coord * 0.0625  + wind * 0.25).b * 3.0;
          noise += texture(noisetex, coord * 0.03125 + wind * 0.15).b * 3.0;

    noise = max(1.0 - 4.0 * (0.5 * VoU + 0.5) * abs(noise - 3.0), 0.0);

    return noise;
}

vec3 getAuroraClassic(vec3 nViewPos, float dither, int samples) {
    float sampleStep = 1.0 / float(samples);
    float currentStep = dither * sampleStep;

    float VoU = dot(nViewPos, upVec);

    // visibility = moonVisibility * (1 - rain)^2. Here rain is invRainFactor (= 1 - min(1, 2 * rain)).
    float visibility = nsNightVisibility() * invRainFactor * invRainFactor;

    float t = nsTime();
    vec2 wind = vec2(t * 0.000125, sin(t * 0.05) * 0.00025);

    vec3 aurora = vec3(0.0);

    if (VoU > 0.0 && visibility > 0.0) {
        vec3 wpos = normalize(mat3(gbufferModelViewInverse) * nViewPos);

        for (int i = 0; i < samples; i++) {
            vec3 planeCoord = wpos * ((8.0 + currentStep * 7.0) / max(wpos.y, 1e-3)) * 0.004;

            vec2 coord = cameraPosition.xz * 0.00004 + planeCoord.xz;
            coord += vec2(coord.y, -coord.x) * 0.3;

            float noise = nsAuroraSample(coord, wind, VoU);

            if (noise > 0.0) {
                noise *= texture(noisetex, coord * 0.125 + wind * 0.25).b;
                noise *= 0.5 * texture(noisetex, coord + wind * 16.0).b + 0.75;
                noise = noise * noise * 3.0 * sampleStep;
                noise *= max(sqrt(1.0 - length(planeCoord.xz) * 3.75), 0.0);

                vec3 auroraColor = mix(auroraLowCol, auroraHighCol, pow(currentStep, 0.4));
                aurora += noise * auroraColor * exp2(-6.0 * float(i) * sampleStep);
            }
            currentStep += sampleStep;
        }
    }

    // Fade out when the camera is deep underground
    visibility *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);

    return min(aurora * visibility, vec3(2.0));
}

// AURORA_STYLE 1 = Layered curtains, 0 = Classic style.
vec3 getAuroraBorealis(vec3 nViewPos, float dither, int samples) {
    #if AURORA_STYLE == 1
        float visibility = nsNightVisibility() * invRainFactor * invRainFactor;
        // Fade out when the camera is deep underground
        visibility *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
        if (visibility <= 0.0) return vec3(0.0);

        vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * nViewPos);
        return min(getRealisticAurora(worldDir, samples, dither) * visibility, vec3(2.0));
    #else
        return getAuroraClassic(nViewPos, dither, samples);
    #endif
}

// ----------------------------- Nebula -----------------------------

const vec4 NS_CLOUD1_COL = vec4(0.0, 0.4, 0.7, 0.5);
const vec4 NS_CLOUD2_COL = vec4(0.2, 0.5, 0.8, 0.3);
const vec4 NS_CLOUD3_COL = vec4(0.4, 0.6, 1.0, 0.8);
const float NS_TIMESCALE = 5.0;
const float NS_ZOOM      = 3.5;
const int   NS_OCTAVE    = 5;

float nsSinM(float x) { return sin(mod(x, 2.0 * NS_PI)); }
float nsCosM(float x) { return cos(mod(x, 2.0 * NS_PI)); }

float nsRand(vec2 c) {
    return fract(nsSinM(dot(c, vec2(23.53, 44.0))) * 42350.45);
}

float nsPerlin(vec2 c) {
    vec2 i = floor(c);
    vec2 j = fract(c);
    vec2 k = smoothstep(0.0, 1.0, j);

    float a = nsRand(i);
    float b = nsRand(i + vec2(1.0, 0.0));
    float c2 = nsRand(i + vec2(0.0, 1.0));
    float d = nsRand(i + vec2(1.0, 1.0));

    return mix(mix(a, b, k.x), mix(c2, d, k.x), k.y);
}

float nsFbmCloud(vec2 c, float minimum) {
    float value = 0.0;
    float scale = 0.5;
    for (int i = 0; i < NS_OCTAVE; i++) {
        value += nsPerlin(c) * scale;
        c *= 2.0;
        scale *= 0.5;
    }
    return smoothstep(0.0, 1.0, (smoothstep(minimum, 1.0, value) - minimum) / (1.0 - minimum));
}

float nsFbmCloud2(vec2 c, float minimum) {
    float value = 0.0;
    float scale = 0.5;
    for (int i = 0; i < NS_OCTAVE; i++) {
        value += nsPerlin(c) * scale;
        c *= 2.0;
        scale *= 0.5;
    }
    return (smoothstep(minimum, 1.0, value) - minimum) / (1.0 - minimum);
}

float nsStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec2 nsStarCoord(vec3 nViewPos, float sphereness) {
    vec3 wpos = normalize(mat3(gbufferModelViewInverse) * nViewPos);
    vec3 starCoord = wpos / (wpos.y + length(wpos.xz) * sphereness);
    starCoord.x += 0.006 * nsTime();
    return starCoord.xz;
}

vec3 getNightNebula(vec3 nViewPos, float VdotU, float VdotS) {
    float blindDark = max(blindness, darknessFactor);
    float nebulaFactor = pow2(max0(VdotU) * min1(nsNightVisibility() * 2.0)) * invRainFactor - blindDark;
    if (nebulaFactor < 0.001) return vec3(0.0);

    vec2 UV = nsStarCoord(nViewPos, 0.75);
    float TIME = nsTime() * 0.003 + 15.0;

    float timescaled = TIME * NS_TIMESCALE;
    vec2 zoomUV2 = vec2(NS_ZOOM * UV.x + 0.03  * timescaled * nsSinM(0.07 * timescaled),
                        NS_ZOOM * UV.y + 0.03  * timescaled * nsCosM(0.06 * timescaled));
    vec2 zoomUV3 = vec2(NS_ZOOM * UV.x + 0.027 * timescaled * nsSinM(0.07 * timescaled),
                        NS_ZOOM * UV.y + 0.025 * timescaled * nsCosM(0.06 * timescaled));
    vec2 zoomUV4 = vec2(NS_ZOOM * UV.x + 0.021 * timescaled * nsSinM(0.07 * timescaled),
                        NS_ZOOM * UV.y + 0.021 * timescaled * nsCosM(0.07 * timescaled));
    float tide  = 0.05 * nsSinM(TIME);
    float tide2 = 0.06 * nsCosM(0.3 * TIME);

    vec4 nebulaTexture = vec4(vec3(0.0), 0.5 + 0.2 * nsSinM(0.23 * TIME + UV.x - UV.y));
    nebulaTexture += nsFbmCloud2(zoomUV3, 0.24 + tide) * NS_CLOUD1_COL;
    nebulaTexture += nsFbmCloud(zoomUV2 * 0.9, 0.33 - tide) * NS_CLOUD2_COL;
    nebulaTexture = mix(nebulaTexture, NS_CLOUD3_COL,
                        nsFbmCloud(vec2(0.9 * zoomUV4.x, 0.9 * zoomUV4.y), 0.25 + tide2));

    nebulaFactor *= 1.0 - pow2(pow2(pow2(abs(VdotS))));
    nebulaTexture.a *= min1(pow2(pow2(nebulaTexture.a))) * nebulaFactor;

    float starFactor = 1024.0;
    vec2 starCoord = floor(UV * 0.25 * starFactor) / starFactor;
    nebulaTexture.rgb *= 1.5 + 10.0 * pow2(max0(nsStarNoise(starCoord) * nsStarNoise(starCoord + 0.1) - 0.6));

    vec3 blueNebula = mix(NS_CLOUD1_COL.rgb, NS_CLOUD3_COL.rgb, 0.5 + 0.3 * nsSinM(TIME * 0.5));
    nebulaTexture.rgb = mix(nebulaTexture.rgb, blueNebula, 0.3);

    return max(nebulaTexture.rgb * nebulaTexture.a, vec3(0.0));
}

// Comets show at dusk and golden hour too, but not in the bright day
float nsDuskVisibility() {
    return 1.0 - linearStep(0.0, 0.25, pSunVec.y);
}


// ----------------------------- Shooting stars / comets -----------------------------
// Frequency: 1 = rare, 2 = normal, 3 = busy. Each comet flies across, leaves a tail
// that stays for COMET_LINGER seconds after the head arrives, then fades out.

#if COMET_FREQUENCY == 1
    #define NS_SHOOT_SLOT 20.0
#elif COMET_FREQUENCY == 2
    #define NS_SHOOT_SLOT 10.0
#else
    #define NS_SHOOT_SLOT 6.5
#endif
#define NS_SHOOT_JITTER (NS_SHOOT_SLOT * 0.6)

float nsHash11(float n) {
    return fract(sin(n * 12.9898) * 43758.5453);
}

// Point on the curved path. u = 0 is the start of the path, larger u is further along
vec3 nsStarPath(vec3 dir0, vec3 move, vec3 bend, float u) {
    return normalize(dir0 + move * u + bend * (u * u));
}

float nsSegDist(vec3 p, vec3 a, vec3 b) {
    vec3 ab = b - a;
    float k = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-8), 0.0, 1.0);
    return length(p - (a + ab * k));
}

vec3 nsShootingStar(vec3 worldDir, float k) {
    float h1 = nsHash11(k * 1.3 + 0.1);   // spawn offset inside the slot
    float h2 = nsHash11(k * 2.7 + 0.2);   // start direction x
    float h3 = nsHash11(k * 3.9 + 0.3);   // start direction y
    float h4 = nsHash11(k * 4.1 + 0.4);   // start direction z
    float h5 = nsHash11(k * 5.1 + 0.5);   // travel direction x
    float h6 = nsHash11(k * 6.7 + 0.6);   // colour
    float h7 = nsHash11(k * 7.3 + 0.7);   // curve direction and amount
    float h8 = nsHash11(k * 8.9 + 0.8);   // duration variation

    float h9  = nsHash11(k * 9.7 + 0.9);    // size pick
    float h10 = nsHash11(k * 11.3 + 0.11);  // does this slot spawn a comet at all

    // Some slots stay empty, so comets do not arrive on a fixed beat
    if (h10 < 0.2) return vec3(0.0);

    // Size: 1x (normal) 50%, 2x 30%, 3x 20%
    float sizeMul = 1.0;
    #if COMET_SIZE_VARIETY == 1
        sizeMul = h9 < 0.5 ? 1.0 : (h9 < 0.8 ? 2.0 : 3.0);
    #endif

    float spawn  = k * NS_SHOOT_SLOT + h1 * NS_SHOOT_JITTER;
    float dur    = COMET_DURATION * (0.85 + 0.3 * h8);
    float linger = COMET_LINGER / dur;    // extra time in s units the tail stays after the head arrives
    float s = (nsTime() - spawn) / dur;   // 0 at spawn, 1 when the head arrives
    if (s < 0.0 || s > 1.0 + linger) return vec3(0.0);

    vec3 dir0 = normalize(vec3(h2 * 2.0 - 1.0, 0.45 + 0.4 * h3, h4 * 2.0 - 1.0));
    vec3 move = normalize(vec3(h5 * 2.0 - 1.0, -0.15, 0.3)) * 0.9;
    vec3 bend = normalize(cross(dir0, move)) * (h7 * 2.0 - 1.0) * 0.25;

    float uHead = min(s, 1.0);
    float u0 = max(uHead - COMET_TAIL_LENGTH * (1.0 + 0.25 * (sizeMul - 1.0)), 0.0);

    // Streak: 8 segments from the tail to the head, getting thicker towards the head
    vec3 prev = nsStarPath(dir0, move, bend, u0);
    float best = 0.0;
    for (int i = 1; i <= 8; i++) {
        float w = float(i) / 8.0;
        float u = mix(u0, uHead, w);
        vec3 cur = nsStarPath(dir0, move, bend, u);
        float r = mix(0.0006, 0.0022, w) * sizeMul;
        float d = nsSegDist(worldDir, prev, cur);
        best = max(best, exp(-pow2(d / r)) * w);
        prev = cur;
    }

    vec3 headPos = nsStarPath(dir0, move, bend, uHead);
    float headFade = 1.0 - smoothstep(0.0, 0.25, s - 1.0);
    float headGlow = exp(-pow2(length(worldDir - headPos) / (0.004 * sizeMul))) * headFade;

    // Random colour from red / blue / yellow / green
    vec3 c;
    if (h6 < 0.25)      c = vec3(1.00, 0.25, 0.20); // red
    else if (h6 < 0.50) c = vec3(0.30, 0.55, 1.00); // blue
    else if (h6 < 0.75) c = vec3(1.00, 0.90, 0.35); // yellow
    else                c = vec3(0.35, 1.00, 0.45); // green

    float fadeIn  = smoothstep(0.0, 0.08, s);
    float fadeOut = 1.0 - smoothstep(1.0, 1.0 + max(linger, 0.001), s);
    float fade = fadeIn * fadeOut;
    // Fade out near and below the horizon so the comet never lays a line on it
    fade *= smoothstep(-0.02, 0.1, headPos.y);

    vec3 col = c * best + mix(c, vec3(1.0), 0.3) * headGlow * 0.5;
    return min(col * fade * 1.4, vec3(1.0));
}

vec3 getShootingStars(vec3 worldDir, float VdotU) {
    #if COMET_FREQUENCY == 0
        return vec3(0.0);
    #endif
    if (VdotU < 0.0) return vec3(0.0);

    float vis = max(nsNightVisibility(), nsDuskVisibility()) * invRainFactor * linearStep(0.0, 0.2, VdotU);
    if (vis <= 0.0) return vec3(0.0);

    float k = floor(nsTime() / NS_SHOOT_SLOT);
    vec3 col = nsShootingStar(worldDir, k) + nsShootingStar(worldDir, k - 1.0) + nsShootingStar(worldDir, k - 2.0) + nsShootingStar(worldDir, k - 3.0);

    return col * vis;
}

#endif
