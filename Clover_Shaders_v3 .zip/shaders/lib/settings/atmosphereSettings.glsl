#define SUN_STYLE 0 //[0 1]
#define MOON_STYLE 0 //[0 1]
#define AURORA_BOREALIS 1 //[0 1]
#define AURORA_STYLE 1 //[0 1]
#define AURORA_BRIGHTNESS 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define NIGHT_NEBULA 0 //[0 1]
#define MILKY_WAY 1 //[0 1]
#define MILKY_WAY_BRIGHTNESS 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define SHOOTING_STARS 1 //[0 1]
#define COMET_FREQUENCY 2 //[0 1 2 3]
#define COMET_DURATION 2.0 //[1.0 1.5 2.0 2.5 3.0 4.0]
#define COMET_TAIL_LENGTH 0.5 //[0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
#define COMET_LINGER 3.0 //[0.0 1.0 2.0 3.0 5.0 8.0]
#define COMET_SIZE_VARIETY 1 //[0 1] Random comet sizes: normal, 2x and 3x
#define CLOUD_NIGHT_BRIGHTNESS 3.5 //[1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0] Cloud brightness at night (1.0 = original)

#define STAR_STYLE 1 //[0 1]
#define STAR_SCALE 1.50 //[0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
#define STAR_AMOUNT 0.20 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70]
#define STAR_BRIGHTNESS 1.00 //[0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.05 2.10 2.15 2.20 2.25 2.30 2.35 2.40 2.45 2.50 2.55 2.60 2.65 2.70 2.75 2.80 2.85 2.90 2.95 3.00 3.05 3.10 3.15 3.20 3.25 3.30 3.35 3.40 3.45 3.50 3.55 3.60 3.65 3.70 3.75 3.80 3.85 3.90 3.95 4.00]

// Clouds: 0 = Off, 1 = Blocky, 2 = Realist
#define VL_CLOUDS 2 //[3 2 1 0]
#define CLOUD_SCALE 10.0 //[4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define CLOUD_HEIGHT 192 //[-64 -60 -56 -52 -48 -44 -40 -36 -32 -28 -24 -20 -16 -12 -8 -4 0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80 84 88 92 96 100 104 108 112 116 120 124 128 132 136 140 144 148 152 156 160 164 168 172 176 180 184 188 192 196 200 204 208 212 216 220 224 228 232 236 240 244 248 252 256 260 264 268 272 276 280 284 288 292 296 300 304 308 312 316 320 324 328 332 336 340 344 348 352 356 360 364 368 372 376 380 384 388 392 396 400 404 408 412 416 420 424 428 432 436 440 444 448 452 456 460 464 468 472 476 480 484 488 492 496 500 504 508 512]
#define CLOUD_THICKNESS 4.0 //[2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0 10.5 11.0 11.5 12.0 12.5 13.0 13.5 14.0 14.5 15.0 15.5 16.0]

// Blocky clouds only: sampling quality (1 = fast, 2 = default w/ self-shadowing, 3 = highest)
#define CLOUD_QUALITY 2 //[1 2 3]

// Realist-only options
#define CLOUD_DENSITY 4 //[1 2 4 6 8]
#define CLOUD_AMOUNT 10.0 //[12.0 11.0 10.0 9.0 8.0]
#define CLOUD_DETAIL 0.7 //[0.3 0.7 1.0 1.3 1.7]
#define CIRRUS_CLOUDS 0 //[0 1]
#define RAINBOW 1 //[0 1 2]
#define RAINBOW_BRIGHTNESS 1.00 //[0.50 0.75 1.00 1.50 2.00 3.00]
#define CIRRUS_COVERAGE 0.42 //[0.20 0.30 0.42 0.55 0.70]
#define CLOUD_SPEED 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 3.50 4.00]
#define CLOUD_OPACITY 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_BRIGHTNESS 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

// End dimension
#define END_BLACK_HOLE 1 //[0 1]
#define END_BLACK_HOLE_SIZE 1.00 //[0.50 0.75 1.00 1.25 1.50 2.00]
#define END_BLACK_HOLE_BRIGHTNESS 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 2.00]
#define END_BLACK_HOLE_SURFACE_LIGHT 1.0 //[0.0 0.25 0.5 0.75 1.0 1.5 2.0] Purple light the black hole casts on blocks
#define END_BLACK_HOLE_LIGHT 6.0 //[1.0 2.0 3.0 4.0 6.0 8.0 12.0 16.0] Purple light strength of the black hole (sun is ~16)

#define LIGHTSHAFTS 1 //[0 1]
#define LIGHTSHAFT_QUALITY 1 //[1 2 3 4]
#define LIGHTSHAFT_STRENGTH 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define LIGHTSHAFT_DAY_STRENGTH 0.50 //[0.00 0.25 0.50 0.75 1.00]

// ==================== WATER SKY REFLECTIONS ====================
// Toggle what appears in water / glossy surface reflections
#define WATER_REFLECT_STARS   1 //[0 1] Stars in water reflections
#define WATER_REFLECT_COMETS  1 //[0 1] Shooting stars & comets in water reflections
#define WATER_REFLECT_AURORA  1 //[0 1] Aurora & night nebula in water reflections
#define WATER_REFLECT_CLOUDS  1 //[0 1] Clouds in water reflections
#define WATER_REFLECT_STRENGTH 1.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0] How bright the reflected stars/comets/aurora are on water (1.0 = same as the real sky)

// ==================== ENHANCED SKY ====================
#define SKY_ENHANCE 1 //[0 1] Golden hour sky colours at sunset (ticks 12000-12800 only)
#define SKY_GOLDEN_HOUR 2.0 //[0.0 0.5 1.0 1.5 2.0] Strength of the golden hour sky
#define SKY_SUN_GLOW 3.0 //[0.0 0.5 1.0 1.5 2.0 3.0] Brightness of the warm glow around the sun
#define NETHER_SMOKE 1 //[0 1]

#if VL_CLOUDS >= 1 && defined OVERWORLD
    #define VL_CLOUDS_INTERNAL
    #if VL_CLOUDS == 1
        #define BLOCKY_CLOUDS_INTERNAL
    #elif VL_CLOUDS == 2
        #define REALIST_CLOUDS_INTERNAL
    #else
        #define CUMULUS_CLOUDS_INTERNAL
    #endif
#endif

#if NETHER_SMOKE == 1 && defined NETHER
    #define NETHER_SMOKE_INTERNAL
#endif