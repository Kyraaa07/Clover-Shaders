#include "/lib/settings/natureSettings.glsl"

/*
    PBR Mode (High profile sets 0 / LabPBR, Low & Medium set 1 / IPBR)
        0: LabPBR
        1: IPBR
        2: Basic
*/

#define PBR_MODE 1 //[0 1 2]
#define LABPBR_EMISSION_STRENGTH 0.4 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PARTICLE_EMISSION_STRENGTH 0.3 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define GLOWING_ORES 1 //[0 1]
#define GLOWING_GEM_BLOCKS 1 //[0 1]
#define PARTICLE_MATERIALS 1 //[0 1]
#define GLOWING_ARMOR 0 //[0 1]
#define ARMOR_GLOW_STRENGTH 0.1 //[0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0] Brightness of glowing armor (trims, diamond and gold, incl. horse and nautilus armor)

#define SELECTION_OUTLINE 0 //[0 1 2]
#define REFLECTION_QUALITY 2 //[0 1 2 3]
#define BIOME_COLORED_NETHER_PORTALS 1 //[0 1]

// Glossy World: every terrain surface (all faces, indoors and outdoors) gets the wet, mirror-like look of a puddle
#define GLOSSY_WORLD 0 //[0 1]
#define GLOSSY_STRENGTH_OVERWORLD 0.5 //[0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0]
#define GLOSSY_STRENGTH_NETHER_END 0.3 //[0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0]
#define REFLECTION_CLAMP 1.2 // max brightness of reflections (stops blown-out white blobs)

#define RAIN_PUDDLES 1 //[0 1 2]
#define PUDDLE_COVERAGE 0.60 //[0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]
#define PUDDLE_SCALE 1.00 //[0.50 0.75 1.00 1.25 1.50 2.00]
#define PUDDLE_RIPPLES 1 //[0 1]
#define PUDDLE_PERMANENT_AMOUNT 0.6 //[0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// ==================== PARALLAX OCCLUSION MAPPING ====================
/*
    POM requires a resource pack with _n.png (normal/height) textures.
    The alpha channel of the normal map is used as the height map.
    Compatible with common PBR resource packs.
*/

//#define POM                            // Enable Parallax Occlusion Mapping
#define POM_DEPTH 0.60                   //[0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00] Depth/strength of the parallax effect
#define POM_QUALITY 64                   //[16 32 64 128 256] Ray march steps — higher = sharper edges, more GPU cost
#define POM_DISTANCE 32                  //[16 24 32 48 64 96 128] Max distance (blocks) to apply POM
//#define POM_SHADOW                     // Self-shadowing: surfaces cast parallax shadows on themselves
//#define POM_SLOPE_NORMALS              // Improved normals at steep height transitions (costs ~1 extra sample)
// Off: POM height comes from the _n.png alpha (LabPBR). On: height comes from albedo brightness (non-PBR packs)
//#define POM_NON_PBR_HEIGHT
// Only with POM_NON_PBR_HEIGHT on: flips the height so dark areas are raised instead of bright ones
//#define POM_ALBEDO_INVERT

// ==================== GENERATED NORMALS (IPBR+) ====================
// Non-PBR textures get bumpy lighting from the colour edges of each texel. No _n.png needed.
// Only applies when PBR_MODE is 1 or 2. Same algorithm as Complementary's GENERATED_NORMALS.
// Comment the line out to turn it off.
#define GENERATED_NORMALS
#define GENERATED_NORMAL_MULT 100 //[25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 250 300 400] Strength
#define GENERATED_NORMAL_RES 128 //[16 32 64 80 96 112 128 144 160 176 192 208 224 240 256 320 384 448 512] Detail resolution
// ==================== PORTAL ENHANCE ====================
#define PORTAL_ENHANCE 1 //[0 1]
#define NETHER_PORTAL_FLAMES 1 //[0 1]
#define NETHER_PORTAL_FLAME_SPEED 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define END_PORTAL_SKY 1 //[0 1]
#define END_PORTAL_SKY_BRIGHTNESS 1.5 //[0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define END_PORTAL_SHOOTING_STARS 1 //[0 1]
#define END_PORTAL_SHOOTING_STARS_BRIGHTNESS 1.0 //[0.5 0.75 1.0 1.5 2.0 3.0]
#define PORTAL_LIGHT 1 //[0 1]
#define PORTAL_LIGHT_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define PORTAL_LIGHT_RADIUS 8.0 //[4.0 6.0 8.0 10.0 12.0 16.0]
#define NETHER_PORTAL_LIGHT_COLOR vec3(0.55, 0.14, 1.00)
#define END_PORTAL_LIGHT_COLOR vec3(0.30, 0.95, 0.80) // fixed portal colour, independent of Eye Color

// ==================== END PORTAL FRAME EYES ====================
#define END_PORTAL_EMITS_LIGHT 1 //[0 1]
#define END_PORTAL_GLOW_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define END_EYE_GLOW 1 //[0 1]
#define END_EYE_GLOW_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define END_EYE_COLOR 0 //[0 1 2 3 4 5 6]

#if   END_EYE_COLOR == 0
    #define END_EYE_COLOR_RGB vec3(0.20, 1.00, 0.35)   // Green
#elif END_EYE_COLOR == 1
    #define END_EYE_COLOR_RGB vec3(0.15, 0.85, 1.00)   // Cyan
#elif END_EYE_COLOR == 2
    #define END_EYE_COLOR_RGB vec3(0.20, 0.35, 1.00)   // Blue
#elif END_EYE_COLOR == 3
    #define END_EYE_COLOR_RGB vec3(0.65, 0.20, 1.00)   // Purple
#elif END_EYE_COLOR == 4
    #define END_EYE_COLOR_RGB vec3(1.00, 0.20, 0.55)   // Pink
#elif END_EYE_COLOR == 5
    #define END_EYE_COLOR_RGB vec3(1.00, 0.18, 0.12)   // Red
#else
    #define END_EYE_COLOR_RGB vec3(1.00, 0.85, 0.40)   // Gold
#endif

// ==================== END CRYSTAL VORTEX ====================
#define END_CRYSTAL_VORTEX 0 //[0 1]
#define END_CRYSTAL_VORTEX_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define END_CRYSTAL_VORTEX_RADIUS 6.0 //[3.0 4.0 5.0 6.0 8.0 10.0 12.0]
#define END_CRYSTAL_BEAM 1 //[0 1]
#define END_CRYSTAL_BEAM_HEIGHT 0.70 //[0.25 0.35 0.45 0.55 0.70 0.85]
#define END_CRYSTAL_SLOTS 24          // crystals tracked at once
#define END_CRYSTAL_FADE_START_MS 1250   // ms after last seen before the vortex starts to fade
#define END_CRYSTAL_FADE_END_MS 6000    // ms after last seen when the vortex is fully gone
#define END_CRYSTAL_GROW_MS 4750           // ms for a newly seen crystal's vortex to grow in from the base
#define END_CRYSTAL_STALE_MS END_CRYSTAL_FADE_END_MS
