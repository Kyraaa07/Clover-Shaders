#ifndef EFFECTS_SETTINGS_GLSL
#define EFFECTS_SETTINGS_GLSL

// ==================== MOTION BLUR ====================
#define MOTION_BLUR 0 //[0 1]
#define MOTION_BLUR_STRENGTH 50 //[10 20 30 40 50 60 70 80 90 100] Length of the blur trail (%)

// ==================== LENS FLARE ====================
#define LENS_FLARE 1 //[0 1]
#define LENS_FLARE_STRENGTH 50 //[10 20 30 40 50 60 70 80 90 100] Brightness of the flare (%)

// ==================== VIGNETTE ====================
#define VIGNETTE 1 //[0 1]
#define VIGNETTE_STRENGTH 40 //[0 10 20 30 40 50 60 70 80 90 100] How dark the screen corners get (%)
#define VIGNETTE_RADIUS 70 //[30 40 50 60 70 80 90] Distance from the centre where darkening starts (%)

// ==================== DEPTH OF FIELD ====================
#define DOF 0 //[0 1]
#define DOF_SAMPLES 48 //[8 16 24 32 36 48 56 64 128] Number of blur samples. More is smoother but slower
#define DOF_INTENSITY 0.02 //[0.001 0.003 0.005 0.007 0.01 0.015 0.02 0.03 0.05 0.07 0.1] Overall blur amount
#define DOF_ANAMORPHIC_RATIO 1.0 //[0.5 0.6 0.8 0.9 1.0 1.1 1.2 1.3 1.5] Horizontal vs vertical blur ratio
#define DOF_CHROMA_DISPERSION 1 //[0 1] Splits colour channels slightly for a lens-like fringe
#define FOCUS_MODE 0 //[0 1] 0 = autofocus on screen centre, 1 = fixed distance
#define MANUAL_FOCUS 5.0 //[1.0 2.0 3.0 5.0 8.0 10.0 15.0 20.0 30.0 50.0 100.0] Fixed focus distance in blocks (FOCUS_MODE 1)
#define CAMERA_APERTURE 2.8 //[0.8 1.0 1.2 1.4 1.8 2.8 4.0 5.6 8.0 11.0 16.0 22.0] Lens f-stop. Lower = more blur

// ==================== PLANKTON (Ambience) ====================
#define PLANKTON 1 //[0 1] Glowing plankton inside the water
#define PLANKTON_COLOR 0 //[0 1 2] 0 = cyan, 1 = green, 2 = blue
#define PLANKTON_DENSITY 0.75 //[0.25 0.5 0.75 1.0 1.5 2.0] How many plankton are visible
#define PLANKTON_BRIGHTNESS 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0] Strength of the glow
#define PLANKTON_REACTIVE 1 //[0 1] Plankton flare up when moving quickly through the water
#define PLANKTON_NIGHT_ONLY 1 //[0 1] Keep plankton almost invisible during the day
#define PLANKTON_SURFACE_GLOW 0 //[0 1] Faint glow on the water surface at night

// ==================== ENCHANT GLOW ====================
#define ENCHANT_GLOW 0 //[0 1] Outline and glow around the outside of every enchanted item
#define ENCHANT_COLOR_THEME 0 //[0 1 2 3 4] Enchant glow colours: 0 Cyber Purple, 1 Cyber Blue, 2 Cyber Green, 3 Cyber Red, 4 Golden
#define ENCHANT_GLOW_INTENSITY 150 //[25 50 75 100 125 150 200 250 300] Overall strength of the enchant glow (%)
#define ENCHANT_GLOW_RADIUS 12 //[0 4 6 8 12 16 24 32] Glow around the outline (pixels at 1080p). 0 = outline only
#define ENCHANT_OUTLINE_THICKNESS 3 //[1 2 3 4 5 6] Thickness of the purple outline (pixels at 1080p)
#define ENCHANT_GLOW_QUALITY 16 //[8 16 24 32] Halo samples. Higher is smoother but slower

// ==================== GLOWING MOB EYES ====================
#define MOB_EYE_GLOW 0 //[0 1] Mob eyes (spider, cave spider, enderman...) glow in the enchant glow colour
#define MOB_EYE_STRENGTH 2.5 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0] Brightness of the glowing mob eyes

// ==================== GAMEPLAY EFFECTS ====================
#define WATER_ON_CAMERA_EFFECT 1 //[0 1] Water drops and distortion when you enter or leave water
#define DAMAGE_TAKEN_EFFECT 1 //[0 1] Red tint and distortion when you take damage
#define LOW_HEALTH_EFFECT 1 //[0 1] Red edges and heartbeat distortion at low health
#define MOTION_AMOUNT 0.25 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] How strong the damage distortion is

// ==================== WATER WAKE ====================
#define WATER_WAKE 0 //[0 1] Ripples trail behind you when you walk, swim or ride a boat on water
#define WATER_WAKE_STRENGTH 3.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0] How tall the wake ripples are and how much foam they make
#define WATER_WAKE_RADIUS 6.0 //[3.0 4.0 5.0 6.0 8.0 10.0] How far (blocks) the wake reaches
#define WATER_WAKE_COLOR 0 //[0 1 2 3 4] Wake colour: 0 Foam, 1 White, 2 Gold, 3 Pink, 4 Aqua
#define WATER_WAKE_SPLASH 1.0 //[0.0 0.5 1.0 1.5 2.0] Amount of splash sparkles on the wake
#define WATER_WAKE_ENTITIES 1 //[0 1] Mobs, items, boats and other entities also ripple the water (swimming, landing, thrown items)
#define WATER_WAKE_ENTITY_STRENGTH 1.0 //[0.5 0.75 1.0 1.5 2.0 3.0] How strongly entities push the water
#define WATER_WAKE_SMALL_ENTITY 0.3 //[0.1 0.2 0.3 0.5 0.75 1.0] Ripple size of small entities (dropped items) compared to big ones (1.0 = same as big)
#define WATER_WAKE_SWIM 0.6 //[0.3 0.4 0.5 0.6 0.8 1.0] Size of the ripple you make while swimming (boats and wading are not affected)

// ==================== FOOTPRINTS ====================
#define FOOTPRINTS 0 //[0 1] Walking on dirt, grass, sand, snow or mud leaves leg prints that fade away 
#define FOOTPRINT_DURATION 4.0 //[2.0 4.0 8.0 15.0 30.0] How many seconds a footprint stays before it fades away
#define FOOTPRINT_DEPTH 1.0 //[0.5 1.0 1.5 2.0] How deep the prints are pressed into the ground

#endif
