float wo_linearDepth(float d) {
    return (near * far) / (d * (near - far) + far);
}

void DoWorldOutline(inout vec3 color, float z) {
    // No outline underwater: the fog already separates the scene there
    if (isCamInWater) return;

    ivec2 texelCoord = ivec2(gl_FragCoord.xy);

    // Sample program IDs so we can skip water / Voxy-water edges (common false silhouettes with Voxy LODs)
    int pidC = int(texelFetch(colortex4, texelCoord, 0).r * 255.1);
    if (pidC == GBUFFERS_WATER_ID) return; // never outline the water surface itself

    float d0 = texelFetch(depthtex0, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2( 1,  1), 0).r;
    float d1 = texelFetch(depthtex0, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2( 1, -1), 0).r;
    float d2 = texelFetch(depthtex0, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2(-1,  1), 0).r;
    float d3 = texelFetch(depthtex0, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2(-1, -1), 0).r;

    int pid0 = int(texelFetch(colortex4, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2( 1,  1), 0).r * 255.1);
    int pid1 = int(texelFetch(colortex4, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2( 1, -1), 0).r * 255.1);
    int pid2 = int(texelFetch(colortex4, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2(-1,  1), 0).r * 255.1);
    int pid3 = int(texelFetch(colortex4, texelCoord + WORLD_OUTLINE_THICKNESS * ivec2(-1, -1), 0).r * 255.1);

    // Skip if any neighbour is water — kills the false outline that appears on land/water and Voxy LOD water borders
    if (pid0 == GBUFFERS_WATER_ID || pid1 == GBUFFERS_WATER_ID || pid2 == GBUFFERS_WATER_ID || pid3 == GBUFFERS_WATER_ID)
        return;

    // Only outline real silhouettes: the neighbours must be clearly farther away (relative to distance)
    float c = wo_linearDepth(z);
    float farAvg = 0.25 * (wo_linearDepth(d0) + wo_linearDepth(d1) + wo_linearDepth(d2) + wo_linearDepth(d3));
    if (farAvg - c > 0.02 * c) {
        color *= 1.0 + WORLD_OUTLINE_BRIGHTNESS;
    }
}
