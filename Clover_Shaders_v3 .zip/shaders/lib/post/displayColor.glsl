#include "/lib/settings/postSettings.glsl"

vec3 lottesTonemap(vec3 color) {
    // Lottes 2016, "Advanced Techniques and Optimization of HDR Color Pipelines"
    // http://32ipi028l5q82yhj72224m8j.wpengine.netdna-cdn.com/wp-content/uploads/2016/03/GdcVdrLottes.pdf
    const vec3 a      = vec3(COLOR_CONTRAST);
    const vec3 d      = vec3(1.0);
    const vec3 hdrMax = vec3(10.0);
    const vec3 midIn  = vec3(0.23);
    const vec3 midOut = vec3(0.3);

    const vec3 a_d = a * d;
    const vec3 hdrMaxA = pow(hdrMax, a);
    const vec3 hdrMaxAD = pow(hdrMax, a_d);
    const vec3 midInA = pow(midIn, a);
    const vec3 midInAD = pow(midIn, a_d);
    const vec3 HM1 = hdrMaxA * midOut;
    const vec3 HM2 = hdrMaxAD - midInAD;

    const vec3 b = (-midInA + HM1) / (HM2 * midOut);
    const vec3 c = (hdrMaxAD * midInA - HM1 * midInAD) / (HM2 * midOut);

    vec3 colorOut = pow(color, a) / (pow(color, a_d) * b + c);

    return linearToSRGB(colorOut);
}

#include "/lib/colors/goldenHour.glsl"

// Cinematic golden hour grade: amber highlights, cool teal shadows, a little extra colour.
// Works on the final display colour, so it affects everything in the scene at sunrise/sunset.
vec3 applyGoldenGrade(vec3 color) {
    float goldW = getGoldenWeight() * GOLDEN_GRADE;
    if (goldW < 0.001) return color;

    float luma       = getLuminance(color);
    float highlights = linearStep(0.35, 0.95, luma);
    float shadows    = 1.0 - linearStep(0.05, 0.45, luma);

    // Sun-lit surfaces turn amber
    color *= mix(vec3(1.0), vec3(1.10, 0.96, 0.78), goldW * highlights);
    // Shadows drift cool teal-blue (classic cinematic split tone)
    color *= mix(vec3(1.0), vec3(0.88, 1.00, 1.10), goldW * shadows);

    // Extra saturation for the warm mood
    float lumaOut = getLuminance(color);
    color = mix(vec3(lumaOut), color, 1.0 + 0.25 * goldW);

    return clamp01(color);
}

vec3 getDisplayColor(vec3 color) {
    color *= COLOR_BRIGHTNESS;

    // Highlight desaturation
    float lumaColor = getLuminance(color);
    float satAmount = exp2(-0.01 * lumaColor);

    color = mix(vec3(lumaColor), color, satAmount);
    
    // Tonemap
    color = lottesTonemap(color);

    // Saturation
    float lumaColorOut = getLuminance(color);
    color = mix(vec3(lumaColorOut), color, COLOR_SATURATION);
    
    return clamp01(color);
}