#ifndef ENCHANT_GLOW_GLSL
#define ENCHANT_GLOW_GLSL

// ------------------------------------------------------------------ //
//  Enchant Glow
//  Every enchanted item (held, worn, dropped, in item frames, on mobs)
//  keeps its original texture colours; a crisp outline and a bright glow
//  (colour theme selectable: purple / blue / green / red / gold) shine
//  around the OUTSIDE of the item.
//
//  gbuffers_armor_glint writes into colortex8 (overlay buffer):
//      rgb = glint texture colour, a = depth * 0.5   (0 < a <= 0.5)
//  Block damage overlay uses a > 0.5, so it is never mistaken for glint.
//  The glint is drawn over the full item silhouette, so the overlay
//  alpha doubles as a silhouette mask for the outline / halo.
// ------------------------------------------------------------------ //

#include "/lib/util/vogelDiscSampling.glsl"

const vec3 ENCHANT_COLOR = vec3(0.60, 0.16, 1.00);
const vec3 ENCHANT_HOT   = vec3(0.90, 0.60, 1.00); // lighter violet for the outline core

bool enchantIsGlint(vec4 o) {
    return o.a > 1e-4 && o.a <= 0.5;
}

// Glint pixel that is not hidden behind something closer than z
bool enchantVisible(vec4 o, float z) {
    return enchantIsGlint(o) && 2.0 * o.a < z + 2.0 / 65535.0;
}

#include "/lib/util/enchantPalette.glsl"

void DoEnchantGlow(inout vec3 color, vec4 overlay, float z, float ditherVal) {
    float s         = viewHeight / 1080.0; // same look at any resolution
    float intensity = ENCHANT_GLOW_INTENSITY * 0.01;

    // Gentle breathing pulse + slow shimmer travelling along the outline
    float pulse   = 0.88 + 0.12 * sin(frameTimeCounter * 2.4);
    float sweep   = 0.5 + 0.5 * sin((gl_FragCoord.x + 0.6 * gl_FragCoord.y) / viewHeight * 9.0 - frameTimeCounter * 2.8);
    float shimmer = 0.85 + 0.3 * sweep * sweep;
    float anim    = pulse * shimmer;

    // Item body keeps its original texture colours: only the outside of the item glows.
    if (enchantVisible(overlay, z)) return;

    ivec2 px    = ivec2(gl_FragCoord.xy);
    ivec2 maxPx = ivec2(viewWidth, viewHeight) - 1;
    float z0    = z;

    // Outline follows the real silhouette of the item (sword, armor, tool...):
    // a pixel is outline when item pixels sit within T pixels of it.
    // Fixed sample directions (no jitter) keep the line crisp and thin parts closed.
    float T    = max(1.0, ENCHANT_OUTLINE_THICKNESS * s);
    float ring = 0.0;
    for (int i = 0; i < 16; i++) {
        float a = float(i) * (tau / 16.0);
        vec2  d = vec2(cos(a), sin(a));
        ivec2 q = clamp(px + ivec2(round(d * T)), ivec2(0), maxPx);
        if (enchantVisible(texelFetch(colortex8, q, 0), z0)) ring += 1.0;
    }
    for (int i = 0; i < 8; i++) {
        float a = (float(i) + 0.5) * (tau / 8.0);
        vec2  d = vec2(cos(a), sin(a));
        ivec2 q = clamp(px + ivec2(round(d * T * 0.5)), ivec2(0), maxPx);
        if (enchantVisible(texelFetch(colortex8, q, 0), z0)) ring += 1.0;
    }
    ring = clamp(ring / 8.0, 0.0, 1.0); // saturates quickly -> solid line, soft AA at the edge

    // Optional very tight glow hugging the outline (radius 0 = off)
    float halo = 0.0;
    #if ENCHANT_GLOW_RADIUS > 0
        if (ring < 1.0) {
            float R = ENCHANT_GLOW_RADIUS * s;
            for (int i = 0; i < ENCHANT_GLOW_QUALITY; i++) {
                vec2  v = vogelDisc(float(i), float(ENCHANT_GLOW_QUALITY), ditherVal);
                ivec2 q = clamp(px + ivec2(round(v * R)), ivec2(0), maxPx);
                if (enchantVisible(texelFetch(colortex8, q, 0), z0)) {
                    float w = 1.0 - length(v);
                    halo += w * w * w; // steeper falloff: thin, light-like glow
                }
            }
            halo /= float(ENCHANT_GLOW_QUALITY);
        }
    #endif

    // Keep the line purple in bright daylight instead of washing out
    color = mix(color, color * 0.35, ring * 0.55);
    // Outline and glow alternate between several purples, drifting along the shape and over time
    float hueT   = (gl_FragCoord.x + 0.6 * gl_FragCoord.y) / viewHeight * 2.5 - frameTimeCounter * 0.3;
    vec3  lineC  = enchantPalette(hueT);
    vec3  haloC  = mix(enchantPalette(0.25), vec3(1.0), 0.2); // selected theme colour, lifted a bit like real light
    color += lineC * ring * 3.2 * intensity * anim;
    color += haloC * halo * 14.0 * intensity * anim;
}

#endif
