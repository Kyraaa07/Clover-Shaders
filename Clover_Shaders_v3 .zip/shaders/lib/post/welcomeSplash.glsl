// Welcome greeting: a short "Good morning / Selamat pagi" style splash with the pack name.
// The greeting follows the real clock (Iris currentTime), the text is drawn with a tiny built-in 5x7 pixel font.
// Shown a few seconds after the shader loads (frameTimeCounter restarts when the pack is loaded or reloaded).

uniform ivec3 currentTime; // hour, minute, second (local time)
uniform bool hideGUI;

const int WC_S0[12] = int[12](71,111,111,100,32,109,111,114,110,105,110,103);
const int WC_S1[14] = int[14](71,111,111,100,32,97,102,116,101,114,110,111,111,110);
const int WC_S2[12] = int[12](71,111,111,100,32,101,118,101,110,105,110,103);
const int WC_S3[10] = int[10](71,111,111,100,32,110,105,103,104,116);
const int WC_S4[12] = int[12](83,101,108,97,109,97,116,32,112,97,103,105);
const int WC_S5[13] = int[13](83,101,108,97,109,97,116,32,115,105,97,110,103);
const int WC_S6[12] = int[12](83,101,108,97,109,97,116,32,115,111,114,101);
const int WC_S7[13] = int[13](83,101,108,97,109,97,116,32,109,97,108,97,109);
const int WC_S8[19] = int[19](67,108,111,118,101,114,32,83,104,97,100,101,114,115,32,118,51,46,48);

// 5 columns of 7 bits (bit 0 = top row). Columns 0-3 are packed in x, column 4 is y.
ivec2 wcGlyph(int ch) {
    if (ch == 32) return ivec2(0, 0);
    if (ch == 46) return ivec2(1585152, 0);
    if (ch == 48) return ivec2(145909950, 62);
    if (ch == 51) return ivec2(158425249, 49);
    if (ch == 67) return ivec2(137388222, 34);
    if (ch == 71) return ivec2(154296510, 122);
    if (ch == 83) return ivec2(154297542, 49);
    if (ch == 97) return ivec2(177547808, 120);
    if (ch == 100) return ivec2(152117816, 127);
    if (ch == 101) return ivec2(177547832, 24);
    if (ch == 102) return ivec2(2260744, 2);
    if (ch == 103) return ivec2(173320460, 62);
    if (ch == 104) return ivec2(8455295, 120);
    if (ch == 105) return ivec2(136274432, 0);
    if (ch == 108) return ivec2(136306816, 0);
    if (ch == 109) return ivec2(8782460, 120);
    if (ch == 110) return ivec2(8455292, 120);
    if (ch == 111) return ivec2(143729208, 56);
    if (ch == 112) return ivec2(42273404, 8);
    if (ch == 114) return ivec2(8455292, 8);
    if (ch == 115) return ivec2(177547848, 32);
    if (ch == 116) return ivec2(135339908, 32);
    if (ch == 118) return ivec2(68161564, 28);
    return ivec2(0, 0);
}

int wcChar(int id, int i) {
    if (id == 0) return i < 12 ? WC_S0[i] : 0;
    if (id == 1) return i < 14 ? WC_S1[i] : 0;
    if (id == 2) return i < 12 ? WC_S2[i] : 0;
    if (id == 3) return i < 10 ? WC_S3[i] : 0;
    if (id == 4) return i < 12 ? WC_S4[i] : 0;
    if (id == 5) return i < 13 ? WC_S5[i] : 0;
    if (id == 6) return i < 12 ? WC_S6[i] : 0;
    if (id == 7) return i < 13 ? WC_S7[i] : 0;
    if (id == 8) return i < 19 ? WC_S8[i] : 0;
    return 0;
}

int wcLen(int id) {
    if (id == 0) return 12;
    if (id == 1) return 14;
    if (id == 2) return 12;
    if (id == 3) return 10;
    if (id == 4) return 12;
    if (id == 5) return 13;
    if (id == 6) return 12;
    if (id == 7) return 13;
    if (id == 8) return 19;
    return 0;
}

// 1.0 where the string has a lit pixel at text-pixel p. 'origin' is the bottom-left text pixel of the string.
float wcMask(ivec2 p, ivec2 origin, int id) {
    ivec2 q = p - origin;
    if (q.y < 0 || q.y > 6 || q.x < 0) return 0.0;
    int ci = q.x / 6;
    int cx = q.x - ci * 6;
    if (cx > 4 || ci >= wcLen(id)) return 0.0;
    ivec2 glyph = wcGlyph(wcChar(id, ci));
    int col = cx < 4 ? ((glyph.x >> (7 * cx)) & 127) : glyph.y;
    return float((col >> (6 - q.y)) & 1);
}

// text with a 1px drop shadow; x = text, y = shadow
vec2 wcMaskShadow(ivec2 p, ivec2 origin, int id) {
    return vec2(wcMask(p, origin, id), wcMask(p + ivec2(-1, 1), origin, id));
}

vec3 applyWelcomeSplash(vec3 col) {
    float t = frameTimeCounter;
    float fadeIn  = smoothstep(1.0, 2.0, t);
    float opacity = fadeIn * (1.0 - smoothstep(5.5, 7.0, t));
    if (opacity <= 0.0 || hideGUI || frameCounter > 20000) return col;

    int h = currentTime.x;
    #if WELCOME_LANGUAGE == 0
        int period = (h >= 5 && h < 12) ? 0 : ((h >= 12 && h < 18) ? 1 : ((h >= 18 && h < 22) ? 2 : 3));
    #else
        int period = (h >= 5 && h < 11) ? 0 : ((h >= 11 && h < 15) ? 1 : ((h >= 15 && h < 18) ? 2 : 3));
    #endif
    int greetId = period + 4 * WELCOME_LANGUAGE;

    vec3 greetCol = vec3(1.0);                             // greeting: always white
    vec3 titleCol = vec3(0.20, 0.95, 0.30);                // "Clover Shaders": green

    // Big text, block centred on the screen. ui scales with the window and never lets the text overflow the width.
    float ui = min(viewHeight / 1080.0, viewWidth / 1920.0);
    int scG = max(int(floor(10.0 * ui + 0.5)), 1);
    int scT = max(int(floor(5.0 * ui + 0.5)), 1);
    float slide = (1.0 - fadeIn) * 20.0 * ui;

    float greetH = 7.0 * float(scG);
    float titleH = 7.0 * float(scT);
    float gap    = 3.0 * float(scT);
    float blockH = greetH + gap + titleH;
    float titleBottom = (viewHeight - blockH) * 0.5 - slide;
    float greetBottom = titleBottom + titleH + gap;

    ivec2 pG = ivec2(floor(gl_FragCoord.xy / float(scG)));
    ivec2 pT = ivec2(floor(gl_FragCoord.xy / float(scT)));

    int lenG = wcLen(greetId);
    int lenT = wcLen(8);
    ivec2 oG = ivec2(int(viewWidth / float(scG) * 0.5) - (lenG * 6 - 1) / 2, int(floor(greetBottom / float(scG))));
    ivec2 oT = ivec2(int(viewWidth / float(scT) * 0.5) - (lenT * 6 - 1) / 2, int(floor(titleBottom / float(scT))));

    vec2 mG = wcMaskShadow(pG, oG, greetId);
    vec2 mT = wcMaskShadow(pT, oT, 8);

    col *= 1.0 - 0.30 * opacity;                            // gentle dim so the text stays readable on bright skies
    col = mix(col, vec3(0.0), max(mG.y, mT.y) * 0.65 * opacity);
    col = mix(col, greetCol, mG.x * opacity);
    col = mix(col, titleCol, mT.x * opacity);
    return col;
}
