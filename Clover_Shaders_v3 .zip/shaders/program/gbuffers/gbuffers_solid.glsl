#define GBUFFERS_SOLID
//----------------- Gbuffers Solid -----------------//

#include "/lib/common.glsl"
#include "/lib/settings/natureSettings.glsl"
#include "/lib/settings/materialSettings.glsl"

#ifndef GBUFFERS_ENTITIES
	#include "/lib/post/taa.glsl"
#endif

#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform sampler2D normals;
uniform sampler2D specular;
uniform sampler2D gtexture;

flat in vec3 vertexNormal;
flat in vec4 vertexTangent;

#ifdef GB_PIPELINE
	in vec4 bladeInfo; // w: 0 = normal geometry, 1 = grass block blade, 2 = plant blade
#endif

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
	flat in vec3 crystalOriginRel;
#endif 

#ifdef GBUFFERS_ENTITIES
	int matID = currentRenderedItemId > 0 ? currentRenderedItemId : entityId;
#elif defined GBUFFERS_HAND
	int matID = currentRenderedItemId;
#elif defined GBUFFERS_BLOCK
	int matID = blockEntityId;
#else
	flat in int matID;
#endif

in vec2 texcoord;
in vec4 glColor;

#ifdef OVERWORLD
	in vec2 lmcoord;
#else
	in float lmcoordX;
	vec2 lmcoord = vec2(lmcoordX, 1.0);
#endif

#ifdef GENERATED_NORMALS
    flat in vec2 gnMidCoord;   // tile centre in atlas UV
    flat in vec2 gnAbsMid;     // distance from texel to tile centre in atlas UV
#endif

// ---- POM varyings (only used when POM is enabled on terrain/block) ----
#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
	in vec3  viewVector;    // view direction in tangent space
	in vec2  vTexCoord;     // tile-local UV (0..1)
	in vec4  vTexCoordAM;   // .st = atlas tile origin, .pq = atlas tile size
	in vec2  signMidCoordPos;

	// dFdx/dFdy of atlas UV for textureGrad (keeps mip level stable under POM shift)
	vec2 dcdx = dFdx(texcoord);
	vec2 dcdy = dFdy(texcoord);

	// Coord that normals/specular are read at (set in main(), shifted by POM)
	vec2 materialCoord;

	#include "/lib/materials/materialMethods/pomEffects.glsl"
#endif

#if defined GENERATED_NORMALS && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
    #include "/lib/materials/materialMethods/generatedNormals.glsl"
#endif

#include "/lib/materials/materialsCommon.glsl"
#include "/lib/util/gbuffersScreenPos.glsl"
#include "/lib/util/programIDs.glsl"

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
	#include "/lib/util/endCrystalCapture.glsl"
#endif

#ifdef GBUFFERS_ENTITIES
	#include "/lib/util/waterWakeEntities.glsl"
#endif

/* DRAWBUFFERS:34 */
layout (location = 0) out uvec4 buffer0; // Material attributes
layout (location = 1) out float buffer1; // Program ID

void main() {
	vec2 pomCoord = texcoord; // atlas-space coord, shifted by POM when it kicks in
	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
		materialCoord = texcoord;
	#endif

	#ifdef GB_PIPELINE
		bool isBlade = bladeInfo.w > 0.5;
	#else
		const bool isBlade = false;
	#endif

	// ----------------------------------------------------------------
	// POM (Complementary flow): fade -> trace -> sample colour at the shifted coord.
	// Normals/specular are read at the same coord through MATERIAL_TEX.
	// ----------------------------------------------------------------
	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
		float parallaxFade = 1.0;
		float parallaxTexDepth = 1.0;
		vec2  parallaxLocalCoord = vTexCoord;
		vec3  parallaxTraceCoordDepth = vec3(vTexCoord, 1.0);

		if (!isBlade) {
			parallaxFade  = pow2(length(viewVector) / float(POM_DISTANCE));
			parallaxFade += pow(ReadHeight(vTexCoord.st), 64.0); // fade out on near-full-height texels
		}

		vec4 color;
		if (parallaxFade < 1.0) {
			parallaxLocalCoord = GetParallaxCoord(parallaxFade, dither_ign, pomCoord, parallaxTexDepth, parallaxTraceCoordDepth);
			materialCoord = pomCoord;
			color = textureGrad(gtexture, pomCoord, dcdx, dcdy);
		} else {
			color = texture(gtexture, texcoord);
		}
	#else
		vec4 color = texture(gtexture, texcoord);
	#endif
	#ifdef GB_PIPELINE
		if (isBlade) {
			// Generated blades take the colour of the sprite they replace; transparent texels fall back to a neutral grey
			if (color.a < 0.5) color.rgb = vec3(0.62);
			color.a = 1.0;
		}
	#endif
	vec3 colorP = color.rgb;

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		// Healing beam (matID 6): its shape comes from procedural shading, not from the pixel texture
		if (matID == 6) { color = vec4(1.0); colorP = vec3(1.0); }
	#endif
	color.rgb  *= glColor.rgb;

	#ifdef GBUFFERS_ENTITIES
		color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
	#endif
	
	#ifndef NO_CUTOUT
		if (color.a < alphaTestRef) discard;
	#endif

	vec3 screenPos = getGbuffersScreenPos();
	vec3 viewPos   = screenToView(screenPos);
	vec3 playerPos = viewToPlayer(viewPos);

	mat3 tbnMatrix = getTbnMatrix(vertexNormal, vertexTangent);

	// getMaterial reads normals/specular — pass pomCoord so it stays in sync
	// We temporarily remap texcoord via a local override pattern:
	// labpbrMaterials.glsl / defaultMaterial.glsl both read "texcoord" directly,
	// but since we can't easily reroute that include, we do the normal read here
	// for LabPBR mode and patch it into the material.
	Material material = getMaterial(tbnMatrix, color.rgb);
	#if defined GENERATED_NORMALS && PBR_MODE != 0 && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
		if (!isBlade) GenerateNormalsClover(material.normalM, colorP, tbnMatrix, texcoord, gnMidCoord, gnAbsMid);
	#endif
	#ifdef GB_PIPELINE
		if (isBlade) material.normalM = normalize(vertexNormal); // blades are lit like the grass top (no normal-map noise)
	#endif

	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
		if (parallaxFade < 1.0 && !isBlade) {
			#ifdef POM_SLOPE_NORMALS
				float slopeThreshold = max(1.0 / float(POM_QUALITY), 1.0 / 255.0);
				if (parallaxTexDepth - parallaxTraceCoordDepth.z > slopeThreshold) {
					vec3 slopeNormal = GetParallaxSlopeNormal(parallaxLocalCoord, parallaxTraceCoordDepth.z, viewVector);
					vec3 normalTS = material.normalM * tbnMatrix; // view -> tangent
					normalTS = mix(normalTS, slopeNormal, 0.5 * pow2(max(1.0 - parallaxFade * 2.0, 0.0)));
					material.normalM = normalize(tbnMatrix * normalize(normalTS));
				}
			#endif

			#ifdef POM_SHADOW
				// Clover shades in a later pass, so the self-shadow is baked into albedo instead of shadowMult
				vec3  pomLightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
				float pomHeight   = HeightAtAtlas(pomCoord);
				float pomShadow   = GetParallaxShadow(parallaxFade, dither_ign, pomHeight, parallaxLocalCoord, pomLightVec, transpose(tbnMatrix));
				material.albedo  *= mix(1.0, pomShadow, 0.6);
			#endif
		}
	#endif

	applyHardcodedMaterials(material, color.a, colorP, tbnMatrix, screenPos, viewPos, playerPos, matID);

	packMaterialData(material, buffer0);
	storeProgramID(buffer1);

	#if defined GBUFFERS_BLOCK && PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1
		if (matID == 3) buffer1 = float(GBUFFERS_END_PORTAL_ID) / 255.0;
	#endif

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		if (matID == 4002) buffer1 = float(GBUFFERS_END_CRYSTAL_ID) / 255.0;
	#endif

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		if (matID == 4002) CaptureEndCrystal(playerPos + cameraPosition);
	#endif

	#if defined GBUFFERS_ENTITIES && WATER_WAKE == 1 && WATER_WAKE_ENTITIES == 1
		CaptureEntityForWake(playerPos + cameraPosition);
	#endif
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#include "/lib/util/vertexTransform.glsl"

// With the grass-blade geometry shader the vertex stage hands everything to the GS under a vs_ prefix;
// the GS then outputs the original names that the fragment shader reads.
#ifdef GB_PIPELINE
	#define vertexNormal  vs_vertexNormal
	#define vertexTangent vs_vertexTangent
	#define matID         vs_matID
	#define texcoord      vs_texcoord
	#define glColor       vs_glColor
	#define lmcoord       vs_lmcoord
	#define viewVector    vs_viewVector
	#define vTexCoord     vs_vTexCoord
	#define vTexCoordAM   vs_vTexCoordAM
	#define signMidCoordPos vs_signMidCoordPos
#ifdef GENERATED_NORMALS
    #define gnMidCoord vs_gnMidCoord
    #define gnAbsMid   vs_gnAbsMid
#endif
	flat out int  vs_kind;       // 0 none, 1 grass block top, 2 short grass/fern, 3 tall grass (lower), 4 tall grass (upper)
	out vec3 vs_playerPos;       // un-waved player-space position
	out vec3 vs_midBlock;        // at_midBlock / 64
#endif

flat out vec3 vertexNormal;
flat out vec4 vertexTangent;

#if !defined GBUFFERS_ENTITIES && !defined GBUFFERS_BLOCK && !defined GBUFFERS_HAND
	flat out int matID;
#endif

out vec2 texcoord;
out vec4 glColor;

#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
	flat out vec3 crystalOriginRel;
#endif

#ifdef OVERWORLD
	out vec2 lmcoord;
#else
	out float lmcoordX;
#endif

#ifdef GENERATED_NORMALS
    flat out vec2 gnMidCoord;
    flat out vec2 gnAbsMid;
#endif

// ---- POM varyings out ----
#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
	out vec3 viewVector;
	out vec2 vTexCoord;
	out vec4 vTexCoordAM;
	out vec2 signMidCoordPos;
#endif

#if defined GB_PIPELINE && !(WAVING_TEXTURES == 1 && defined GBUFFERS_TERRAIN && !defined VT_COMPATIBILITY_MODE)
	attribute vec3 at_midBlock;
#endif

attribute vec4  at_tangent;
attribute float mc_Entity;
attribute vec2 mc_midTexCoord; // centre of the tile in atlas UV (waving + POM)

#if WAVING_TEXTURES == 1 && defined GBUFFERS_TERRAIN && !defined VT_COMPATIBILITY_MODE
    attribute vec3 at_midBlock;

    // Waving blocks
    float lmCoord = 1.0;
    #define WAVING_I (WAVING_STRENGTH * 0.1)
    #define WAVING_SPEED_M (WAVING_SPEED * 0.1)

    vec3 GetRawWave(in vec3 pos, float wind) {
        float magnitude = sin(wind * 0.0027 + pos.x + pos.y) * 0.04 + 0.04;
        float d0 = sin(wind * 0.0127);
        float d1 = sin(wind * 0.0089);
        float d2 = sin(wind * 0.0114);
        vec3 wave;
        wave.x = magnitude * sin(wind*0.0224 + d1 + d2 + pos.x - pos.z + pos.y);
        wave.y = magnitude * sin(wind*0.0015 + d2 + d0 + pos.x);
        wave.z = magnitude * sin(wind*0.0063 + d0 + d1 - pos.x + pos.z + pos.y);

        return wave;
    }

    vec3 GetWave(in vec3 pos, float waveSpeed) {
        float wind = frameTimeCounter * waveSpeed * WAVING_SPEED_M;
        vec3 wave = GetRawWave(pos, wind);

        return wave * WAVING_I;
    }

    void DoWave_Foliage(inout vec3 playerPos, vec3 worldPos, float waveMult) {
        worldPos.y *= 0.5;

        vec3 wave = GetWave(worldPos, 170.0);
        wave.x = wave.x * 3.0;
        wave.y = 0.0;
        wave.z = wave.z * 8.0 + wave.y * 4.0;

        wave *= clamp(lmCoord - 0.87, 0.0, 0.1);

        #if PLAYER_GRASS_BEND == 1
            // Plants lean away from the player and press down, (interactive foliage).
            // Player space is centred on the camera; the real eye is camera MINUS relativeEyePosition (Iris),
            // so this is right in first and third person. The feet are 1.62 blocks under the eye.
            vec3 eye = dot(relativeEyePosition, relativeEyePosition) > 100.0 ? vec3(0.0) : -relativeEyePosition;
            vec3 rel = playerPos - (eye - vec3(0.0, 1.62, 0.0));
            if (rel.y > -0.6 && rel.y < 2.2) { // only plants around the player's body, not far above or below
                float d = length(rel.xz);
                float push = (1.0 - smoothstep(0.0, PLAYER_GRASS_RADIUS, d)) * PLAYER_GRASS_STRENGTH;
                vec2 away = d > 1e-3 ? rel.xz / d : vec2(0.0);
                wave += vec3(away.x * 0.45, -0.25, away.y * 0.45) * push;
            }
        #endif

        playerPos.xyz += wave * waveMult;
    }

    void DoWave_Leaves(inout vec3 playerPos, vec3 worldPos, float waveMult) {
        worldPos *= vec3(0.75, 0.375, 0.75);

        vec3 wave = GetWave(worldPos, 170.0);
        wave *= vec3(4.0, 3.0, 8.0);

        wave *= clamp(lmCoord - 0.87, 0.0, 0.1);

        playerPos.xyz += wave * waveMult;
    }

    void DoWave(inout vec3 playerPos, int mat) {
        vec3 worldPos = playerPos.xyz + cameraPosition.xyz;

        if (mat == 2) { // Foliage (block.2)
            if (gl_MultiTexCoord0.t < mc_midTexCoord.t || fract(worldPos.y + 0.21) > 0.26)
                DoWave_Foliage(playerPos.xyz, worldPos, 1.0);
        } else if (mat == 1) { // Leaves (block.1)
            DoWave_Leaves(playerPos.xyz, worldPos, 1.0);
        }
    }

    void applyWavingVertex() {
        vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

        lmCoord = clamp((gl_TextureMatrix[1] * gl_MultiTexCoord1).y - 0.03125, 0.0, 1.0) * 1.06667;
        int mat = int(mc_Entity + 0.5);
        if (mat >= 6 && mat <= 8) mat = 2; // grass plants share the foliage waving

        DoWave(position.xyz, mat);

        gl_Position = gl_ProjectionMatrix * gbufferModelView * position;
    }
#endif


void main() {
	#if defined GBUFFERS_ENTITIES && MC_VERSION < 260100 
		// Name tag background, Entity shadows
		if (
			// Entity Ids for name tags and entity shadows seem to be broken on Iris 1.21.9+
			#if MC_VERSION >= 12109
				gl_Color.a < 0.38
			#else
				(entityId == 4000 && gl_Color.a < 0.5) || entityId == 4001
			#endif
		) {
			gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
			return;
		}
	#endif

#if WAVING_TEXTURES == 1 && defined GBUFFERS_TERRAIN && !defined VT_COMPATIBILITY_MODE
		applyWavingVertex();
	#else
		applyVertexTransform();

	#if defined GBUFFERS_ENTITIES && defined END && END_CRYSTAL_VORTEX == 1
		crystalOriginRel = (gbufferModelViewInverse * vec4(gl_ModelViewMatrix[3].xyz, 1.0)).xyz;
	#endif
	#endif
	
	#ifndef GBUFFERS_ENTITIES
		gl_Position.xy = taaJitter(gl_Position.xy, gl_Position.w);
	#endif

	#ifdef GBUFFERS_ENTITIES
		gl_Position.z -= 0.001; // Fixes Z fighting with certain entities
	#endif

	vertexNormal  = normalize(gl_NormalMatrix * gl_Normal);
	vertexTangent = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);

	// Pre 1.20.6 End Portal normal & tangent precision issues workaround
	#if defined GBUFFERS_BLOCK && MC_VERSION < 12006
		if (blockEntityId == 3) {
			float NdotU = dot(vertexNormal, upVec);
			float NdotE = dot(vertexNormal, eastVec);
			float NdotS = dot(vertexNormal, southVec);

			if (abs(NdotU) > 0.9) {
				vertexNormal = sign(NdotU) * upVec;
				vertexTangent = vec4(-southVec, 1.0);
			} else if (abs(NdotE) > 0.9) {
				vertexNormal = sign(NdotE) * eastVec;
				vertexTangent = vec4(-upVec, 1.0);
			} else if (abs(NdotS) > 0.9) {
				vertexNormal = sign(NdotS) * southVec;
				vertexTangent = vec4(-upVec, 1.0);
			}
		}
	#endif

	// Post 26.1 End Portal non existent tangent workaround
	#if defined GBUFFERS_BLOCK && MC_VERSION >= 260100
        if (at_tangent.xyz == vec3(0.0)) {
			if (abs(dot(vertexNormal, upVec)) > 0.99)
				vertexTangent = vec4(-southVec, 1.0);
			else
				vertexTangent = vec4(-upVec, 1.0);
        }
    #endif

	#if !defined GBUFFERS_ENTITIES && !defined GBUFFERS_BLOCK && !defined GBUFFERS_HAND
		matID = int(mc_Entity);
		#ifdef GB_PIPELINE
		{
			int rawID = matID;
			vs_kind = 0;
			if (rawID == 1101 && (mat3(gbufferModelViewInverse) * vertexNormal).y > 0.9) vs_kind = 1;
			else if (rawID == 6) vs_kind = 2;
			else if (rawID == 7) vs_kind = 3;
			else if (rawID == 8) vs_kind = 4;
			if (rawID >= 6 && rawID <= 8) matID = 2; // plants shade as foliage
			vs_playerPos = (gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
			vs_midBlock  = at_midBlock.xyz * (1.0 / 64.0);
		}
		#endif
	#endif
	
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	#ifdef OVERWORLD
		lmcoord = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
	#else
		lmcoordX = clamp01(((gl_TextureMatrix[1] * gl_MultiTexCoord1).x - 0.03125) * 1.06667);
	#endif

	glColor = gl_Color;

	#ifdef GENERATED_NORMALS
	{
		vec2 gnRaw = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		gnMidCoord = (gl_TextureMatrix[0] * vec4(mc_midTexCoord, 0.0, 1.0)).xy;
		gnAbsMid   = abs(gnRaw - gnMidCoord);
	}
#endif

// ---- POM vertex data ----
	#if defined POM && (defined GBUFFERS_TERRAIN || defined GBUFFERS_BLOCK)
	{
		// Build TBN in view space to transform view direction into tangent space
		vec3 vNorm = vertexNormal;
		vec3 vTang = vertexTangent.xyz;
		vec3 vBino = cross(vTang, vNorm) * sign(vertexTangent.w); // same convention as getTbnMatrix (T x N) * w
		// tbnMatrix: transforms view-space vectors into tangent space
		// (transpose of the TBN columns = inverse for orthonormal bases)
		mat3 tbnT = mat3(vTang.x, vBino.x, vNorm.x,
		                 vTang.y, vBino.y, vNorm.y,
		                 vTang.z, vBino.z, vNorm.z);

		vec3 viewPos = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;
		viewVector   = tbnT * viewPos; // tangent-space view direction (not normalised on purpose)

		// Atlas tile extents: mc_midTexCoord is the texel centre of the tile
		vec2 rawTexcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
		vec2 midCoord    = (gl_TextureMatrix[0] * vec4(mc_midTexCoord, 0.0, 1.0)).xy;
		vec2 texMinMid   = rawTexcoord - midCoord;

		signMidCoordPos = sign(texMinMid);
		vTexCoordAM.st  = min(rawTexcoord, midCoord - texMinMid); // tile min corner
		vTexCoordAM.pq  = abs(texMinMid) * 2.0;                   // tile size in atlas UV
		vTexCoord       = signMidCoordPos * 0.5 + 0.5;            // local 0..1 UV
	}
	#endif
}

#elif defined GEOMETRY_SHADER
//--- GEOMETRY SHADER (grass blades) ---//

#include "/lib/util/grassBlades.glsl"

layout(triangles, invocations = GB_INV) in;
layout(triangle_strip, max_vertices = GB_MAXV) out;

flat in vec3 vs_vertexNormal[];
flat in vec4 vs_vertexTangent[];
flat in int  vs_matID[];
flat in int  vs_kind[];
in vec2 vs_texcoord[];
in vec4 vs_glColor[];
in vec2 vs_lmcoord[];
in vec3 vs_playerPos[];
in vec3 vs_midBlock[];
#ifdef GENERATED_NORMALS
in vec2 vs_gnMidCoord[];
in vec2 vs_gnAbsMid[];
#endif
#ifdef POM
	in vec3 vs_viewVector[];
	in vec2 vs_vTexCoord[];
	in vec4 vs_vTexCoordAM[];
	in vec2 vs_signMidCoordPos[];
#endif

flat out vec3 vertexNormal;
flat out vec4 vertexTangent;
flat out int  matID;
out vec2 texcoord;
out vec4 glColor;
out vec2 lmcoord;
out vec4 bladeInfo;
#ifdef GENERATED_NORMALS
flat out vec2 gnMidCoord;
flat out vec2 gnAbsMid;
#endif
#ifdef POM
	out vec3 viewVector;
	out vec2 vTexCoord;
	out vec4 vTexCoordAM;
	out vec2 signMidCoordPos;
#endif

#include "/lib/util/grassBladesEmit.glsl"

#endif
