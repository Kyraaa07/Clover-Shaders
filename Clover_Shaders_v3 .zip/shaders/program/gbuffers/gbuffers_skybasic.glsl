#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/atmospherics/sky.glsl"
#include "/lib/atmospherics/stars.glsl"
#include "/lib/atmospherics/nightSky.glsl"

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Sky color

void main() {
	vec3 screenPos = vec3(gl_FragCoord.xy / view, 1.0);
	
	vec3 nViewPos = normalize(screenToView(screenPos));
	vec3 worldDir = mat3(gbufferModelViewInverse) * nViewPos;

	float VdotU = worldDir.y;
	float VdotS = dot(worldDir, pSunVec);

	color  = getSky(VdotU, VdotS);
	color += getStars(worldDir);
	#if MILKY_WAY == 1
		color += getMilkyWay(worldDir);
	#endif

	#if AURORA_BOREALIS == 1
		color += getAuroraBorealis(nViewPos, dither_ign, 16);
	#endif
	#if NIGHT_NEBULA == 1
		color += getNightNebula(nViewPos, VdotU, VdotS);
	#endif
	#if SHOOTING_STARS == 1
		color += getShootingStars(worldDir, VdotU);
	#endif

	#if SUN_STYLE == 0 || MOON_STYLE == 0		
		float celestial = linearStep(0.9985, 0.999, abs(VdotS)) * clamp01(pow3(3.0 * VdotU + 0.57));

		if (celestial < 1e-6) return;

		if (VdotS > 0.0) {            
			#if SUN_STYLE == 0 
				color = mix(color, 30.0 * sunColor, celestial);
			#endif
		} else {
			#if MOON_STYLE == 0
				color = mix(color, 5.0 * moonCol, pow2(celestial));
			#endif
		}
    #endif
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/util/vertexTransform.glsl"

void main() {
	applyVertexTransform();
}

#endif