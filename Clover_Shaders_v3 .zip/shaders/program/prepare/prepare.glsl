#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"
#include "/lib/settings/effectsSettings.glsl"
#include "/lib/materials/helpers/waterSim.glsl"
#include "/lib/materials/helpers/footprintState.glsl"

#if WATER_WAKE == 1
layout(r32i) coherent uniform iimage2D wk_ent_min_img;
layout(r32i) coherent uniform iimage2D wk_ent_max_img;
layout(r32i) coherent uniform iimage2D wk_hit_img;
#endif

in vec2 texcoord;

/* RENDERTARGETS: 10 */
layout (location = 0) out vec4 outSim;

vec2 fetchSim(ivec2 p) {
    if (p.x < 0 || p.y < 0 || p.x >= int(SIM_RES) || p.y >= int(SIM_RES)) return vec2(0.0);
    return texelFetch(colortex10, p, 0).rg;
}

// Distance from point p to the segment a-b (the path the player swept this frame)
float segDist(vec2 p, vec2 a, vec2 b) {
    vec2 ab = b - a;
    float t = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-6), 0.0, 1.0);
    return distance(p, a + ab * t);
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);

    vec3 move = cameraPosition - previousCameraPosition;
    bool teleport = dot(move, move) > 16.0;
    float dt = (frameTime > 0.0 && frameTime < 1.0) ? clamp(frameTime, 1.0 / 240.0, 1.0 / 20.0) : 1.0 / 60.0;

    // ---- Player position (NOT the camera) ----
    // Iris: relativeEyePosition = cameraPosition - eyePosition, so the player's eye is camera MINUS it.
    // (It used to be PLUS, which mirrored the wake across the camera in third person.)
    vec3 eye = cameraPosition - relativeEyePosition;
    if (dot(relativeEyePosition, relativeEyePosition) > 100.0) eye = cameraPosition;

    // Last frame's eye position is kept in the state pixels (stored relative to that frame's camera).
    vec4 st0 = texelFetch(colortex10, ivec2(0, 0), 0);
    vec4 st1 = texelFetch(colortex10, ivec2(1, 0), 0);
    vec4 st2 = texelFetch(colortex10, ivec2(2, 0), 0);
    bool stateValid = st2.a > 0.5 && !teleport;
    vec3 prevEye = stateValid ? previousCameraPosition + vec3(st0.a, st1.b, st1.a) : eye;

    // Player (eye / boat) movement, so orbiting the camera in third person doesn't make fake wakes
    vec3 eyeMove = eye - prevEye;
    if (dot(eyeMove, eyeMove) > 9.0) { eyeMove = vec3(0.0); prevEye = eye; }

    float speed = length(eyeMove.xz) / dt;
    vec4 result = vec4(0.0);

    // Water Physics: is the player touching water? (flag written by gbuffers_water last frame into
    // wk_hit_img texel (0,0)). Rises at once, fades out over ~0.5 s so a glance away doesn't cut the wake.
    float wet = 0.0;
#if WATER_WAKE == 1
    {
        int expectP = (frameCounter == 0 ? 720719 : frameCounter - 1) + 1;
        bool touching = imageLoad(wk_hit_img, ivec2(0, 0)).r == expectP;
        float wetPrev = stateValid ? clamp(st2.b, 0.0, 1.0) : 0.0;
        wet = touching ? 1.0 : wetPrev * exp(-dt * 2.0);
        if (wet < 0.02) wet = 0.0;
    }
#endif
    float edge = float(min(min(px.x, px.y), min(int(SIM_RES) - 1 - px.x, int(SIM_RES) - 1 - px.y)));

#if WATER_WAKE == 1
    // Scroll the grid when the camera crosses cell boundaries
    ivec2 shift = ivec2(simCameraCell(cameraPosition) - simCameraCell(previousCameraPosition));
    ivec2 src = px + shift;

    vec2 state = teleport ? vec2(0.0) : fetchSim(src);
    float h     = state.r;
    float hPrev = state.g;
    vec2 n0 = fetchSim(src + ivec2(1, 0));
    vec2 n1 = fetchSim(src - ivec2(1, 0));
    vec2 n2 = fetchSim(src + ivec2(0, 1));
    vec2 n3 = fetchSim(src - ivec2(0, 1));
    float hN = n0.r + n1.r + n2.r + n3.r;
    float vN = hN - (n0.g + n1.g + n2.g + n3.g);   // neighbours' velocities
    float lap = teleport ? 0.0 : hN - 4.0 * h;

    // 2D wave equation. Wave speed is frame-rate independent and stays inside the stable range.
    float c2 = min(pow(28.0 * dt, 2.0), 0.25);
    float velocity = h - hPrev;
    // Viscous damping: the finest cell-by-cell motion dies instantly so rounding noise can't pile up
    velocity -= 0.2 * (velocity - vN * 0.25);
    velocity *= exp(-dt * 0.9);
    float hNew = (h + velocity + c2 * lap) * exp(-dt * 0.25);
    hNew = mix(hNew, hN * 0.25, 0.01);

    vec2 cellWorld = (simCameraCell(cameraPosition) + vec2(px) - SIM_RES * 0.5 + 0.5) * SIM_CELL;

    // Wake reacts at much lower speeds than before so it shows up the moment you start moving
    float fast   = clamp((speed - 1.5) / 4.0, 0.0, 1.0);
    float moving = clamp(speed / 3.0, 0.0, 1.0);
    float hull   = (0.2 + WATER_WAKE_RADIUS * 0.05) + 0.35 * fast;

    // Swimming = full push. Wading / riding a boat only pushes while moving AND touching the water.
    // Walking next to the water (shore, bridge) does nothing.
    float inWater = (isEyeInWater == 1) ? 1.0 : wet * smoothstep(0.15, 0.8, speed);
    float flying = smoothstep(2.0, 5.0, abs(eyeMove.y) / dt);
    inWater *= 1.0 - flying;

    // The hull sweeps the whole path travelled this frame (+ a stern that stretches with speed),
    // so the wake is a continuous trail that follows the player / boat exactly, with no gaps.
    vec2 dir = length(eyeMove.xz) > 1e-5 ? normalize(eyeMove.xz) : vec2(0.0);
    vec2 segA = prevEye.xz - dir * (0.9 * fast);
    vec2 segB = eye.xz;
    float d = segDist(cellWorld, segA, segB);

    // Swimming (head under water) makes a smaller ripple than riding a boat
    float swimK = (isEyeInWater == 1) ? WATER_WAKE_SWIM : 1.0;
    hull *= mix(1.0, 0.7, 1.0 - swimK);

    float body = (1.0 - smoothstep(0.0, hull, d)) * inWater;
    vec2 aheadPos = eye.xz + dir * (0.5 + 0.4 * fast);
    float ahead = (1.0 - smoothstep(0.0, 0.45 + 0.2 * fast, distance(cellWorld, aheadPos))) * inWater;

    float bob = 0.12 * sin(frameTimeCounter * 2.2);
    float dip = -(0.14 + 0.14 * moving + 0.10 * fast) + bob * 0.03;
    dip *= swimK;
    float k = 1.0 - exp(-dt * 22.0);                 // push is applied almost instantly
    hNew = mix(hNew, min(hNew, dip), body * k);
    hNew = mix(hNew, max(hNew, 0.12 * moving + 0.10 * fast), ahead * k * 0.8);

    // Splash: falling into water punches a crater that rings outward
    float wasUnder = st0.b;
    float fallSpeed = stateValid ? -eyeMove.y / dt : 0.0;
    if (isEyeInWater == 1 && wasUnder < 0.5 && fallSpeed > 2.5) {
        float r = 0.7 + min(fallSpeed, 30.0) * 0.03;
        float depth = min(0.15 + fallSpeed * 0.025, 0.55) * WATER_WAKE_SPLASH;
        float x = distance(cellWorld, eye.xz) / r;
        hNew -= depth * clamp(1.0 - x * x, 0.0, 1.0);                  // crater
        hNew += depth * 0.45 * exp(-pow((x - 1.15) * 3.0, 2.0));        // thrown-up rim
    }

    // ---- Entities (mobs, items, boats...) ----
    // gbuffers_water marked the cells that entities touched last frame (wk_hit_img, tagged with that
    // frame's number). A soft 5x5 average gives a smooth "how much entity is here" mask. The wave is
    // driven by the CHANGE of that mask: something entering pushes the water down (it rings outward),
    // something leaving lets it spring back, and something that moves leaves a wake. Standing still = calm.
    float entMask = 0.0;
#if WATER_WAKE_ENTITIES == 1
    {
        int expect = (frameCounter == 0 ? 720719 : frameCounter - 1) + 1;
        float sum = 0.0;
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                ivec2 q = src + ivec2(dx, dy);
                if (q.x < 0 || q.y < 0 || q.x >= int(SIM_RES) || q.y >= int(SIM_RES)) continue;
                if (imageLoad(wk_hit_img, q).r == expect) sum += 1.0;
            }
        }
        // Size of the thing: a coarse 3x3 probe (4 cells apart, ~0.8 block). Small entities (items) only
        // hit a tap or two, big ones (boats, cows) hit most of them, so items get a much smaller ripple.
        float big = 0.0;
        for (int cy = -1; cy <= 1; cy++) {
            for (int cx = -1; cx <= 1; cx++) {
                ivec2 q = src + ivec2(cx, cy) * 4;
                if (q.x < 0 || q.y < 0 || q.x >= int(SIM_RES) || q.y >= int(SIM_RES)) continue;
                if (imageLoad(wk_hit_img, q).r == expect) big += 1.0;
            }
        }
        float sizeK = mix(WATER_WAKE_SMALL_ENTITY, 1.0, smoothstep(0.2, 0.6, big / 9.0));
        entMask = (edge >= 24.0 && !teleport) ? clamp(sum / 6.0, 0.0, 1.0) * sizeK : 0.0;

        float prevMask = 0.0;
        if (!teleport && !(src.x < FP_STATE_END && src.y < 1) && src.x >= 0 && src.y >= 0 && src.x < int(SIM_RES) && src.y < int(SIM_RES))
            prevMask = clamp(texelFetch(colortex10, src, 0).b, 0.0, 1.0);

        hNew -= (entMask - prevMask) * 1.2 * WATER_WAKE_ENTITY_STRENGTH;

        // Reset this frame's entity buffers (each pixel only touches its own texel, so no race)
        imageStore(wk_ent_min_img, px, ivec4(WK_EMPTY_MIN));
        imageStore(wk_ent_max_img, px, ivec4(WK_EMPTY_MAX));
    }
#endif

    // Fade out at the borders of the simulated area
    hNew *= smoothstep(0.0, 24.0, edge);
    result = vec4(clamp(hNew, -0.6, 0.6), h, entMask, 0.0);
#endif

#if WATER_WAKE == 1 || FOOTPRINTS == 1
    // State pixels live in the (faded-out) border, in channels the simulation never reads:
    //   .b elsewhere = entity mask of this frame (water entities)
    //   (0,0).b = eye was under water   (0,0).a = eye.x - camera.x
    //   (1,0).b = eye.y - camera.y      (1,0).a = eye.z - camera.z      (2,0).a = state valid
    //   (3,0).b = distance walked, (4..27,0) = footprints (see footprintState.glsl)
    vec3 eyeRel = eye - cameraPosition;
    if (px == ivec2(0, 0)) { result.b = float(isEyeInWater == 1); result.a = eyeRel.x; }
    if (px == ivec2(1, 0)) { result.b = eyeRel.y; result.a = eyeRel.z; }
    if (px == ivec2(2, 0)) { result.a = 1.0; result.b = wet; }
#endif

#if FOOTPRINTS == 1
    // ---- Footprints ----
    // Every FP_STEP_LENGTH blocks walked on the ground, the next of FP_SLOTS slots is overwritten with a
    // new print, alternating left / right of the walking line. Old prints fade out in the material pass.
    if (px.y == 0 && px.x >= FP_ACC_PIXEL && px.x < FP_STATE_END) {
        vec4 accState = texelFetch(colortex10, ivec2(FP_ACC_PIXEL, 0), 0);
        float accPrev = (accState.b >= 0.0 && accState.b < 1000.0) ? accState.b : 0.0;
        bool walking = stateValid && isEyeInWater != 1 && abs(eyeMove.y) / dt < 1.0 && speed > 0.05;
        float accum = accPrev + (walking ? length(eyeMove.xz) : 0.0);
        float stepNow = floor(accum / FP_STEP_LENGTH);
        bool newStep = walking && stepNow != floor(accPrev / FP_STEP_LENGTH);
        float slot = mod(stepNow, float(FP_SLOTS));
        float side = mod(stepNow, 2.0) < 0.5 ? 1.0 : -1.0;
        vec2 dir2 = length(eyeMove.xz) > 1e-5 ? normalize(eyeMove.xz) : vec2(1.0, 0.0);
        vec2 perp = vec2(-dir2.y, dir2.x);
        vec3 feet = eye - vec3(0.0, 1.62, 0.0);

        if (px.x == FP_ACC_PIXEL) {
            result.b = mod(accum, FP_STEP_LENGTH * 64.0);    // 64 steps: a multiple of 8 slots and of 2 sides
            result.a = 1.0;
        } else {
            int i = (px.x - FP_FIRST_PIXEL) / 3;
            int part = (px.x - FP_FIRST_PIXEL) - i * 3;
            vec2 keep = texelFetch(colortex10, px, 0).ba;
            if (newStep && abs(float(i) - slot) < 0.5) {
                if (part == 0)      result.ba = feet.xz + perp * side * 0.15;
                else if (part == 1) result.ba = vec2(frameTimeCounter, atan(dir2.y, dir2.x));
                else                result.ba = vec2(feet.y, 1.0);
            } else {
                result.ba = keep;
            }
        }
    }
#endif

    outSim = result;
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
