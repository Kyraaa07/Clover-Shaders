	
#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

#include "/lib/common.glsl"
#include "/lib/post/taa.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/util/programIDs.glsl"

#include "/lib/materials/materialsCommon.glsl"
#include "/lib/lighting/mainLighting.glsl"

#include "/lib/settings/atmosphereSettings.glsl"
#ifdef BLOCKY_CLOUDS_INTERNAL
    #include "/lib/atmospherics/blockyClouds.glsl"
#elif defined REALIST_CLOUDS_INTERNAL
    #include "/lib/atmospherics/realistClouds.glsl"
#endif
#if defined CUMULUS_CLOUDS_INTERNAL || (CIRRUS_CLOUDS == 1 && defined OVERWORLD)
    #include "/lib/atmospherics/cumulusClouds.glsl"
#endif
#ifdef NETHER_SMOKE_INTERNAL
    #include "/lib/atmospherics/netherSmoke.glsl"
#endif

#ifndef OVERWORLD
    #include "/lib/colors/altSkyColors.glsl"
#endif

#ifdef END
    #include "/lib/atmospherics/endSky.glsl"
#elif PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1
    #include "/lib/atmospherics/endSky.glsl"
#endif

#if PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1 && END_PORTAL_SHOOTING_STARS == 1
    #include "/lib/atmospherics/portalShootingStars.glsl"
#endif

#if PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1
    #include "/lib/atmospherics/portalStarfield.glsl"
#endif

#if defined OVERWORLD && (BEAUTY_NIGHT == 1 || CAVE_FIREFLIES == 1)
    #include "/lib/atmospherics/fireflies.glsl"
#endif

in vec2 texcoord;

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Main scene color

#ifdef VL_CLOUDS_INTERNAL
    /* DRAWBUFFERS:05 */
    layout (location = 1) out float cloudDepth; // VL clouds depth
#endif

void main() {
    int programID = UNKNOWN_PROGRAM_ID;
    float fragDepth = textureLod(depthtex0, texcoord, 0).r;

    // Voxy LOD pixels beyond the vanilla far plane have depth == 1.0, so we detect them
    // through the program ID (colortex4 is cleared every frame) and rebuild their position
    // from the view depth Voxy stored in colortex3.
    bool isFarLod = false;

    if (fragDepth < 1.0) {
        programID = getProgramIDAt(texcoord);

        if (programID == GBUFFERS_HAND_ID)
            fixHandDepth(fragDepth);
    } else if (getProgramIDAt(texcoord) == GBUFFERS_VOXY_ID) {
        programID = GBUFFERS_VOXY_ID;
        isFarLod = true;
    }

    vec3 screenPos = vec3(taaJitter(texcoord, -0.5), fragDepth);
    vec3 viewPos;

    if (isFarLod) {
        vec2 ndc = screenPos.xy * 2.0 - 1.0;
        viewPos = vec3(ndc * diag2(gbufferProjectionInverse), -1.0) * getLodDepth();
    } else {
        viewPos = screenToView(screenPos);
    }

    vec3 playerPos = viewToPlayer(viewPos); 

    vec3 ffAlbedo = vec3(0.0); // surface colour, used by the firefly light
    float ffBlockLight = 0.0;

    if (screenPos.z < 1.0 || isFarLod) {
        #if PORTAL_ENHANCE == 1 && END_PORTAL_SKY == 1
        if (programID == GBUFFERS_END_PORTAL_ID) {
            // End Portal: a dramatic window into the End. Deep void sky, swirling nebula
            // bands in the portal's own colour, and a slow pulse. Eye of Ender colour is not used here.
            vec3 pDir = normalize(playerPos);
            // Dark teal void with a faint deep-sky gradient
            color = getEndSky(pDir) * END_PORTAL_SKY_BRIGHTNESS * 0.6;
            // Dense twinkling starfield
            color += portalStarfield(pDir, frameTimeCounter) * END_PORTAL_SKY_BRIGHTNESS * 3.0;
            #if END_PORTAL_EMITS_LIGHT == 1
                // Slow pulse of the portal colour behind the stars
                float portalPulse = 0.85 + 0.15 * sin(frameTimeCounter * 1.5);
                color += END_PORTAL_LIGHT_COLOR * 0.02 * END_PORTAL_GLOW_STRENGTH * portalPulse;
            #endif
            #if END_PORTAL_SHOOTING_STARS == 1
                color += psShootingStars(pDir, normalize(mat3(gbufferModelViewInverse) * vec3(0.0, 0.0, -1.0)))
                         * END_PORTAL_SHOOTING_STARS_BRIGHTNESS;
            #endif
        } else
        #endif
        if (programID != GBUFFERS_BASIC_ID) {
            Material material = getMaterial(); 

            color = computeMainLighting(material, screenPos, viewPos, playerPos, programID);
            ffAlbedo = material.albedo;
            ffBlockLight = material.blocklight;
        } else // Skip lighting
            color = textureLod(colortex0, texcoord, 0).rgb;
    } else { // Sky
        #ifdef OVERWORLD
            color = textureLod(colortex0, texcoord, 0).rgb;
        #elif defined NETHER
            color = altSkyColor;
        #else
            color = getEndSky(normalize(playerPos));
        #endif
    }

    #if CIRRUS_CLOUDS == 1 && defined OVERWORLD
        // thin ice clouds high above, behind the regular clouds (sky pixels only)
        if (screenPos.z == 1.0 && !isFarLod && !isCamInWater)
            DoCirrus(color, normalize(playerPos));
    #endif

    #ifdef VL_CLOUDS_INTERNAL
        cloudDepth = 1.0;
        if (programID != GBUFFERS_HAND_ID) {
            float wsdistP = length(playerPos);

            vec3 nPlayerPos = playerPos / wsdistP;

            if (screenPos.z == 1.0 && !isFarLod) wsdistP = 1e30;

            DoClouds(color, cameraPosition, nPlayerPos, wsdistP, cloudDepth);
        }
    #endif
    
    #ifdef NETHER_SMOKE_INTERNAL
        if (programID != GBUFFERS_HAND_ID) {
            float wsdistP = length(playerPos);
            vec3 nPlayerPos = playerPos / wsdistP;
            
            DoNetherSmoke(color, nPlayerPos, wsdistP);
        }
    #endif

    #if defined OVERWORLD && (BEAUTY_NIGHT == 1 || CAVE_FIREFLIES == 1)
        if (programID != GBUFFERS_HAND_ID && !isCamInWater) {
            bool isSkyPixel = screenPos.z == 1.0 && !isFarLod;
            #if BEAUTY_NIGHT == 1
                if (nightFactor > 0.01) doFireflies(color, ffAlbedo, ffBlockLight, playerPos, isSkyPixel);
            #endif
            #if CAVE_FIREFLIES == 1
                doCaveFireflies(color, ffAlbedo, ffBlockLight, playerPos, isSkyPixel);
            #endif
        }
    #endif
}

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
