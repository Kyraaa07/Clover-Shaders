#ifdef FRAGMENT_SHADER
//--- FRAGMENT SHADER ---//

uniform float alphaTestRef;
uniform sampler2D gtexture;

in vec2 texcoord;
#ifdef OVERWORLD
    in float bladeFlag; // 1 = generated grass blade (no texture lookup needed for its coverage)
#endif

/* DRAWBUFFERS:0 */
layout (location = 0) out vec3 color; // Shadow color

void main() {
    float alpha = texture(gtexture, texcoord).a;
    #ifdef OVERWORLD
        if (bladeFlag < 0.5 && alpha < alphaTestRef) discard;
    #else
        if (alpha < alphaTestRef) discard;
    #endif
    color = vec3(0.0);
}

#elif defined GEOMETRY_SHADER
//--- GEOMETRY SHADER (grass blade shadows) ---//

#include "/lib/util/grassBladesShadowGS.glsl"

#elif defined VERTEX_SHADER
//--- VERTEX SHADER ---//

#define diag(mat) vec3(mat[0][0], mat[1][1], mat[2][2])

#include "/lib/settings/lightingSettings.glsl"
#include "/lib/util/shadowDistortion.glsl"
#include "/lib/util/vertexTransform.glsl"

#ifdef OVERWORLD
    // the grass blade geometry shader sits between this stage and the fragment shader
    #include "/lib/util/grassBladesShadowVS.glsl"
    #define texcoord vs_texcoord
#endif

out vec2 texcoord;

void main() {
    applyVertexTransform();
    #if SHADOWS == 0
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    #endif
    
    #ifdef OVERWORLD
        gbsVertexData();
    #endif

    gl_Position.xyz = getDistortedPos(gl_Position.xyz);
    
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
