#version 430 compatibility

#define FRAGMENT_SHADER
#define END
#define GBUFFERS_WATER

#include "/program/gbuffers/gbuffers_translucent.glsl"
