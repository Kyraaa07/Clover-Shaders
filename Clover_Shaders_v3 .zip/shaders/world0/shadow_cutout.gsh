#version 400 compatibility

#define GEOMETRY_SHADER
#define OVERWORLD
#define SHADOW_CUTOUT

#include "/program/shadow/shadow_cutout.glsl"
