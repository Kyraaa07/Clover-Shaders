#version 430 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define PREPARE

#include "/program/prepare/prepare.glsl"