#version 400 compatibility

#define GEOMETRY_SHADER
#define OVERWORLD
#define SHADOW_SOLID

#include "/program/shadow/shadow_solid.glsl"
