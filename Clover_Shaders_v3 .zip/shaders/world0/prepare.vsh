#version 330 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define PREPARE

#include "/program/prepare/prepare.glsl"