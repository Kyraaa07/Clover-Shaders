#version 400 compatibility

#define NO_CUTOUT

#define GEOMETRY_SHADER
#define OVERWORLD
#define GBUFFERS_TERRAIN
#define GB_PIPELINE

#include "/program/gbuffers/gbuffers_solid.glsl"
