#version 330 compatibility

#define FRAGMENT_SHADER
#define OVERWORLD
#define GBUFFERS_TERRAIN
#define GB_PIPELINE

#include "/program/gbuffers/gbuffers_solid.glsl"
