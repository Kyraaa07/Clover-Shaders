# Clover Shaders v3

**by Kyraaa**

---

## 🇮🇩 Bahasa Indonesia

Clover Shaders v3 adalah shader pack Minecraft dengan pencahayaan, langit, dan efek yang bisa diatur lewat menu.

### Fitur

- **Awan Blocky** — awan bulat lembut dengan bayangan antar-awan, pemudaran ke warna langit, dan perilaku saat hujan. Opsi: Cloud Quality (Fast / Balanced / High), Scale, Height, Thickness, Speed, Opacity, Brightness.
- **Awan Realist** — awan volumetrik yang lembut dan realistis.
- **Pilihan jenis awan** ada di layar *Clouds* (Realist / Blocky / Off).
- **Profil grafik**: Potato, Low, Medium, High, Very High, Extreme, PC Nasa? (PC Nasa? = semua opsi berat di nilai maksimal, hanya untuk PC super kuat; Extreme diberi tag *Challenging your PC*: shadow 256 blok, rumput 3D, footprints, water physics, dan efek Clover+ aktif; berat, butuh GPU kuat).
- **Portal Enhance** — portal Nether dan End memancarkan cahaya sesuai warnanya. Nether portal dengan api ungu, end portal dengan langit End dan bintang jatuh.
- **Enchant Glow** — semua item enchant (dipegang, dipakai, jatuh, di item frame) punya outline yang mengikuti bentuk aslinya plus cahaya di luar outline dengan warna yang bergantian. Pilihan warna: Cyber Purple, Cyber Blue, Cyber Green, Cyber Red, Golden. Tekstur dan warna item aslinya tidak diubah. Atur di *Materials → Enchant Glow* (opsi Glow Colour).
- **Fireflies (Beauty Night)** — kunang-kunang malam hari yang memberi sedikit cahaya.
- **Bintang Realistis** — bintang titik kecil yang berkedip dengan banyak warna (sedikit yang terang, banyak yang redup) dan berputar di langit sepanjang malam. Pilihan *Star Style*: Realistic / Classic.
- **Milky Way** — pita galaksi Bima Sakti dengan jalur debu gelap, ikut berputar bersama bintang. Opsi: Milky Way, Milky Way Brightness. (Night Nebula sekarang mati secara default supaya Milky Way terlihat jelas.)
- **Aurora** — gaya baru *Layered*: tirai hijau-ungu berlapis yang bergelombang di seluruh langit. Pilihan *Aurora Style*: Layered / Classic, plus Aurora Brightness.
- **God Rays** — berkas cahaya matahari dengan kabut tipis yang bergerak, glare lebih tajam ke arah matahari, tampil juga di siang hari (bukan hanya sunrise/sunset), dan tanpa bayangan aneh dari badan pemain. Opsi: Lightshaft Quality, Strength, Daytime Lightshafts.
- **Volumetric Clouds (Cumulus)** — awan cumulus 3D asli: dasar rata, puncak membulat, bayangan ke arah matahari, dan bagian dalam yang terang. Bisa dilihat dari bawah, di dalam, maupun dari atas lapisan awan. Pilih lewat *Cloud Type: Cumulus* (default di profil High ke atas); memakai slider awan yang sudah ada (Height, Thickness, Scale, Amount, Density, Detail, Speed, Opacity).
- **Cirrus Clouds** — awan tipis es di langit tinggi yang tertarik angin dan berwarna emas saat sunrise/sunset. Opsi: Cirrus Clouds, Cirrus Coverage. Jalan di semua tipe awan.
- **Rainbows** — pelangi muncul di seberang matahari saat hujan baru reda dan matahari masih rendah (satu pelangi). Mode: Off / After Rain / Always (Always = pagi sampai sore, tidak saat sunset atau malam). Opsi lain: Rainbow Brightness.
- **Interactive Foliage** — rumput, bunga, dan tanaman condong menjauh dan tertekan saat pemain lewat. Benar di first dan third person. Opsi tetap di *Player Grass Bend*: Strength dan Radius.
- **Footprints** — jalan di tanah, rumput, pasir, salju, atau lumpur meninggalkan jejak kaki kotak ala Minecraft yang memudar setelah beberapa detik. Hanya di Overworld. Opsi: Footprints, Footprint Lifetime, Footprint Depth (*Clover+ → Footprints*).
- Opsi tambahan: Motion Blur, Wind Movement, pengaturan air, Lens Flare, Vignette, dan lainnya.

### Cara install

1. Taruh file `.zip` ke folder `shaderpacks` Minecraft.
2. Buka *Options → Video Settings → Shader Packs* lalu pilih Clover Shaders v3.
3. Butuh Iris (atau OptiFine). Fitur LOD butuh Voxy.

### Tips

- Kalau awan terlalu terang atau gelap, atur *Cloud Brightness*.
- Kalau FPS turun, turunkan *Cloud Quality* ke Fast atau pakai preset grafik yang lebih rendah.

---

## 🇬🇧 English

Clover Shaders v3 is a Minecraft shader pack with configurable lighting, sky and effects.

### Features

- **Blocky clouds** — soft rounded clouds with cloud self-shadowing, sky fade and rain behaviour. Options: Cloud Quality (Fast / Balanced / High), Scale, Height, Thickness, Speed, Opacity, Brightness.
- **Realist clouds** — soft, realistic volumetric clouds.
- **Cloud type selector** lives in the *Clouds* screen (Realist / Blocky / Off).
- **Portal Enhance** — Nether and End portals emit light matching their colour. Nether portals get purple flames, End portals get the End sky and shooting stars.
- **Fireflies (Beauty Night)** — fireflies drift around at night and give off a little light.
- **Realistic stars** — small twinkling point stars in many colours (few bright, many faint) that wheel across the sky during the night. *Star Style*: Realistic / Classic.
- **Milky Way** — the galaxy band with dark dust lanes, turning with the stars. Options: Milky Way, Milky Way Brightness. (Night Nebula is now off by default so the Milky Way reads clearly.)
- **Aurora** — new *Layered* style: layered green and purple curtains rippling across the sky. *Aurora Style*: Layered / Classic, plus Aurora Brightness.
- **God rays** — sun shafts through drifting mist, with a tighter glare toward the sun, visible during the day as well as at sunrise and sunset, and no odd shadow beam from the player's own body. Options: Lightshaft Quality, Strength, Daytime Lightshafts.
- **Volumetric clouds (Cumulus)** — real 3D cumulus with flat bases, billowy tops, self-shadowing and bright soft interiors, visible from below, inside and above the layer. Pick *Cloud Type: Cumulus* (not the default: the default is Realist); it reuses the existing cloud sliders.
- **Cirrus clouds** — thin wind-stretched ice clouds high in the sky, gold at sunrise and sunset. Options: Cirrus Clouds, Cirrus Coverage. Works with every cloud type.
- **Rainbows** — a rainbow opposite the sun when rain clears and the sun is low. Mode: Off / After Rain / Always (Always = morning to afternoon, not at sunset or night). Also: Rainbow Brightness.
- **Interactive foliage** — grass, flowers and plants lean away and press down as you walk through them, correct in first and third person. Options stay under *Player Grass Bend*: Strength and Radius.
- **Footprints** — walking on dirt, grass, sand, snow or mud leaves blocky Minecraft leg prints that fade away after a few seconds. Overworld only. Options: Footprints, Footprint Lifetime, Footprint Depth (*Clover+ → Footprints*).
- More options: Motion Blur, Wind Movement, water settings, Lens Flare, Vignette and more.

### Installation

1. Put the `.zip` into your Minecraft `shaderpacks` folder.
2. Go to *Options → Video Settings → Shader Packs* and select Clover Shaders v3.
3. Requires Iris (or OptiFine). LOD support requires Voxy.

### Tips

- If the clouds look too bright or too dark, adjust *Cloud Brightness*.
- If your FPS drops, set *Cloud Quality* to Fast or use a lower graphics preset.

---



## Water Wake (v8)
Water Wake now uses an interactive ripple simulation (new prepare pass + colortex10): water ripples outward and forms a V-shaped wake as you swim, wade or ride a boat. Menu: Clover+ > Water Physics.

### Water Wake v9 fixes
- Default Wake Strength is now 3.0.
- New default wake colour "Foam" (pale mint-white) + a light tint over the whole disturbed water, so the wake stands out from the water. Old aqua is option 4.
- Fixed the wake following the camera in Third Person Front/Back, with camera-offset mods and on boats: it now follows the player's real position (Iris `relativeEyePosition` is camera minus eye) and the player's own movement, not the camera's.
- Boats: the hull sweeps the whole path travelled (a trail with a stern), so the wake lines up with the boat's route and heading.
- Foam is thinner (less opaque white).
- Less delay: lower speed thresholds, faster push, and the wake no longer leaves gaps at speed.
- The wake fades out when you are far above the water (bridges, flying).


### Water Wake v10: entity ripples
- Mobs, items, boats and other entities now ripple the water too: a swimming mob leaves a wake, a thrown item or a mob jumping into the water makes a splash ring that spreads out, and items floating on the surface disturb it a little.
- Menu: Clover+ > Water Physics > Entity Ripples (on/off) and Entity Ripple Strength.
- How it works: gbuffers_entities writes the height range each entity covers per cell into an image, gbuffers_water checks whether that touches the water surface, and the prepare pass turns the change of that mask into waves in the existing simulation. Needs Iris with custom images (already required by Clover).

### Water Physics (formerly Water Wake)
- Menu renamed: Clover+ > Water Physics.
- The player now only ripples the water while actually touching it (wading, swimming, in a boat). Walking on the shore or a bridge next to water no longer makes ripples.

### Menu reorganised
- Main menu: Performance, Lighting, Atmosphere, Water, Materials, Camera, Clover+.
- Lighting: new Shadows sub-menu; Ambient Occlusion (SSAO) moved here (still also a quick knob in Performance).
- Atmosphere: Sky (incl. Rainbows), Clouds, Sun/Moon & Night Sky (new: sun, moon, aurora, nebula, shooting stars, stars), Fog & Light Shafts, End Sky, Color Multipliers.
- Water is now its own top-level menu (colour, opacity, foam, distortion, underwater distortion, reflections).
- Camera: World Outline moved here from Clover+.
- Materials: Parallax (POM) moved here from Performance; Wind & Waving stays here.
- Clover+ keeps all its entries except World Outline.

### Profiles updated
- Potato: unchanged (footprints explicitly off).
- Low: + Footprints.
- Medium: + Footprints, Enchant Glow, Glowing Armor, Player Grass Bend.
- High: Medium (Realist clouds, cirrus off to stay light).
- Very High: High + Water Physics + Cirrus Clouds; Realist clouds.
- Extreme: same as Very High plus its extra settings.
- Glossy World is off in every profile (the setting is still there). Very High and Extreme use Rain Puddles: Everything.
- Cloud Type now has: Cumulus, Realist, Blocky, Off. All profiles use Realist (Potato: off); Cumulus is still selectable by hand. Aurora Style now has: Layered, Classic.

### Update: puddles, defaults and performance
- Puddles and Glossy World no longer reflect stars, Milky Way, aurora, nebula, comets or clouds. Sun and moon reflections stay. Water is unchanged.
- The defaults now match the High profile exactly, so the game shows "High" instead of "Custom" on first load (Cloud Type: Realist, Cirrus off, Water Wake off).
- Faster: coloured light is skipped on pixels that get no blocklight (most of the outdoors by day); puddle reflections skip the ray trace on their faint edges and use half the ray steps; puddles no longer evaluate sky effects at all.
- Voxy LODs: grass (top and the grass edge on the sides) was drawn pale grey next to the green vanilla chunks. Grass blocks now have their own block ID (1101) and grey grass pixels on LODs are recoloured. The colour is `ETH_LOD_GRASS_TINT` at the top of `shaders/program/voxy/voxyCommon.glsl`.
- More performance: High profile now uses Shadow Distance 128, Lightshaft Quality 1 and Colored Light Quality 1 (defaults changed to match, so it still shows "High"). Shadow filtering stops after 2 taps outside penumbras, LOD shadows use 14 longer steps instead of 24, LOD AO uses 4 samples instead of 6, and LOD shadows are skipped on faces turned away from the light.
- Voxy grass fix v2: the grey test now also catches slightly coloured grey. `ETH_LOD_DEBUG_GRASS 1` in voxyCommon.glsl paints LOD grass blocks magenta (diagnostic only, leave it at 0).
- Voxy grass fix v3: LOD grass (top + edge on the sides) is rebuilt as texture brightness x grass tint on every non-bottom pixel, no longer guessing from the texture colour. Voxy's own tint is used only when it is really a grass green; otherwise `ETH_LOD_GRASS_TINT`.
- Glitter fix: on rain puddles and Glossy World the reflection and sun highlight use a flattened normal and a minimum highlight roughness, so bumpy PBR normal maps (realistic texture packs) no longer turn the ground into white sparkles. Tunables `GLOSSY_NORMAL_SMOOTH` and `GLOSSY_MIN_SPEC_ROUGHNESS` in lib/lighting/mainLighting.glsl.


## Grassier Blades (new, Clover+ > Grassier Blades)
Real 3D grass inspired by the *Grassier Grass* Fabric mod (v1.4.5), generated by a geometry shader (new file `world0/gbuffers_terrain.gsh`).

- Every grass block top is expanded into thin blades (default 32 per block; 8-64). Short grass, tall grass and ferns can be turned into blades too (new block IDs 6-8 in `block.properties`; the vertex shader remaps them to the foliage material, so lighting is unchanged).
- Ported from the mod's shader: each blade is a strip along a cubic Bezier spine, with regional height noise, per-blade height/width variation, Voronoi clumps (inward resting lean, rim sparsity), scrolling wind noise, wind-curve bow, rest curve, tip flutter, camera-facing width, base-to-tip brightness gradient, per-blade hue jitter and wind shimmer.
- Walking through grass uses the existing Player Grass Bend (strength and radius) and flattens the blades.
- Options: Blades Per Block, Blade Segments, Render Radius, Blade Height, Height Variation, Blade Width, Grass Sparsity, Plants As Blades, Blade Wind Strength, Brightness, Hue Jitter, Gradient Base/Tip/Curve.
- Profiles: Potato/Low off; Medium 16 blades, radius 24; High (default) 32, radius 40; Very High 48, radius 64; Extreme 64, radius 96.
- Not ported from the mod: dense flowers, blade particles, grass through snow, blades on Voxy LODs.
- Needs Iris with geometry shader support. Not supported in VT compatibility mode.

### Grassier Blades: blade shadows (new)
Grass blades now cast their own shadows, so the sun makes a thin patchy shadow across the ground and the other blades instead of only the flat grass block top.

- How it works: the shadow pass (`world0/shadow_solid.gsh` and `world0/shadow_cutout.gsh`, shared code in `lib/util/grassBladesShadowGS.glsl`) rebuilds exactly the same blades as the main pass: same seed, wind, bend and player push. Shadows therefore move with the grass. The ribbons are turned toward the light and drawn wider, because a ribbon seen edge-on or thinner than a shadow texel casts no shadow.
- Menu: Clover+ > Grassier Grass > Blade Shadows (on/off) and Blade Shadow Detail (Fast / Full). Blade Shadows is also in Lighting > Shadows.
- Off: only the flat grass block casts a shadow (the old behaviour) and the shadow pass does no blade work. Blade Shadows needs Shadows on and Grassier Grass on.
- Fast (default): every second blade casts a wider shadow, about half the cost. Full: every blade casts a shadow.
- Profiles: Potato/Low off; Medium and High on (Fast); Very High and Extreme on (Full).
- Plants As Blades also casts shadows when it is on. Needs Iris with geometry shader support (same as the blades).


## Profiles v2 (reorganised)
Profiles now go Potato > Low > Medium > High (default) > Very High > Extreme, each one a little heavier and nicer than the last, and all of them stay light. Every option can still be changed by hand afterwards.

- **Clover+ extras are manual.** Enchant Glow, Mob Eye Glow, Glowing Armor, Water Wake, Footprints, Grassier Blades, Player Grass Bend, Glossy World and Selection Outline are off in every profile. Turn on what you want in the Clover+ menu. Their quality tiers (blade density/radius, enchant glow quality) are still set per profile, so they match the profile when you switch them on.
- **Clover+ features that profiles do enable:**
  - Low: fireflies (6, no cave fireflies) and plankton (density 0.25) only.
  - Medium: fireflies (10, cave 6), plankton (0.5), gameplay effects, portals (flames and End sky), rare comets.
  - High: fireflies (16, cave 10), plankton (0.75), gameplay effects, all portal effects (except End crystal vortex), normal comets.
  - Very High: fireflies (24, cave 16), plankton (1.0), everything in portals, normal comets.
  - Extreme: fireflies (32, cave 24), plankton (1.5) with surface glow, everything in portals, busy comets.
- **Rain Puddles is now Rain Only** in every profile except Potato (off). Set it to Everything yourself if you want permanent puddles. Ripples start at High.
- **Lighter shadows and clouds:** Medium 1024 at 96, High 1024 at 128, Very High 2048 at 192, Extreme 2048 at 256. Cloud detail goes 0.3 / 0.7 / 0.7 / 1.0 / 1.3 (Low to Extreme).
- Defaults match the new High profile, so the game still shows "High" on first load. This supersedes the older "Profiles updated" notes above.


## Performance Impact flags
Every menu now ends with a **Performance impact** row (hover it for the legend), and each option that costs FPS has a coloured flag in front of its name. These are Clover's own colours:

- grey = None, aqua = Minimal, green = Low, yellow = Medium, gold = High, red = Very high, pink = Varies with its own setting (quality, amount, distance and similar sliders).
- Options with no flag cost nothing (colour and strength sliders).
- The flag shows what turning the option on costs. Defaults still follow the **High** profile.

Menu names now carry symbols too (Performance, Lighting, Atmosphere, Water, Materials, Camera, Clover+, and the Clover+ sub menus).


## Welcome Greeting
A short greeting fades in a few seconds after the shader loads (new world, shader reload, dimension change), with the pack name under it:

```
Good evening
Clover Shaders v3
```

- The greeting follows your real computer clock. English: Good morning (05-11), Good afternoon (12-17), Good evening (18-21), Good night (22-04). Indonesia: Selamat pagi (05-10), siang (11-14), sore (15-17), malam (18-04).
- On by default in every profile, Potato included. Turn it off in *Clover+ > Welcome Greeting*. It is not part of any profile, so switching profiles never changes it and turning it off does not make the profile show "Custom".
- Options: Welcome Greeting (on/off) and Greeting Language (English / Indonesia).
- Hidden when the GUI is hidden (F1). Uses Iris `currentTime`.
